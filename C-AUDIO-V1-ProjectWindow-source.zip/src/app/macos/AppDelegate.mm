#import "AppDelegate.h"
#import "CoreAudioDuplex.h"
#import "AudioFileLoader.h"
#import "ProjectTimelineView.h"
#import "../../engine/MixerEngine.h"
#import "../../engine/ProjectFile.h"

#import <Cocoa/Cocoa.h>

#include <array>
#include <algorithm>
#include <cmath>
#include <memory>
#include <string>
#include <vector>

using namespace caudio;

@interface AppDelegate ()
@property(strong) NSWindow* window;
@property(strong) NSPopUpButton* devicePopup;
@property(strong) NSTextField* statusLabel;
@property(strong) NSTextField* positionLabel;
@property(strong) NSTextField* masterMeter;
@property(strong) NSButton* sslButton;
@property(strong) NSPopUpButton* masterType;
@property(strong) NSPopUpButton* masterOutA;
@property(strong) NSPopUpButton* masterOutB;
@end

@implementation AppDelegate {
    MixerEngine _engine;
    std::unique_ptr<CoreAudioDuplex> _audio;
    std::vector<AudioDeviceInfo> _devices;
    NSInteger _selectedTrack;
    NSTimer* _meterTimer;

    ProjectTimelineView* _timeline;
    NSScrollView* _timelineScroll;

    std::array<NSButton*, MixerEngine::kTrackCount> _trackSelect;
    std::array<NSButton*, MixerEngine::kTrackCount> _trackArm;
    std::array<NSButton*, MixerEngine::kTrackCount> _trackMute;
    std::array<NSButton*, MixerEngine::kTrackCount> _trackSolo;

    NSTextField* _insName;
    NSTextField* _insFileLabel;
    NSPopUpButton* _insType;
    NSPopUpButton* _insSource;
    NSPopUpButton* _insInputA;
    NSPopUpButton* _insInputB;
    NSButton* _insArm;
    NSButton* _insMon;
    NSButton* _insMute;
    NSButton* _insSolo;
    NSSlider* _insTrim;
    NSSlider* _insFader;
    NSSlider* _insPan;

    std::array<NSTextField*, MixerEngine::kTrackCount> _mixNames;
    std::array<NSSlider*, MixerEngine::kTrackCount> _mixFaders;
    std::array<NSButton*, MixerEngine::kTrackCount> _mixMute;
    std::array<NSButton*, MixerEngine::kTrackCount> _mixSolo;
}

- (NSTextField*)label:(NSString*)text frame:(NSRect)frame bold:(BOOL)bold {
    NSTextField* l = [[NSTextField alloc] initWithFrame:frame];
    l.stringValue = text; l.editable = NO; l.selectable = NO; l.bordered = NO; l.drawsBackground = NO;
    l.font = bold ? [NSFont boldSystemFontOfSize:12.0] : [NSFont systemFontOfSize:10.5];
    return l;
}

- (NSButton*)button:(NSString*)text frame:(NSRect)frame action:(SEL)action {
    NSButton* b = [[NSButton alloc] initWithFrame:frame];
    b.title = text; b.bezelStyle = NSBezelStyleRounded; b.target = self; b.action = action;
    return b;
}

- (NSButton*)toggle:(NSString*)text frame:(NSRect)frame action:(SEL)action tag:(NSInteger)tag {
    NSButton* b = [self button:text frame:frame action:action];
    b.buttonType = NSPushOnPushOffButton; b.tag = tag;
    return b;
}

- (NSPopUpButton*)popup:(NSRect)frame action:(SEL)action tag:(NSInteger)tag {
    NSPopUpButton* p = [[NSPopUpButton alloc] initWithFrame:frame pullsDown:NO];
    p.target = self; p.action = action; p.tag = tag;
    return p;
}

- (NSSlider*)slider:(NSRect)frame min:(double)min max:(double)max value:(double)value action:(SEL)action tag:(NSInteger)tag {
    NSSlider* s = [[NSSlider alloc] initWithFrame:frame];
    s.minValue = min; s.maxValue = max; s.doubleValue = value; s.target = self; s.action = action; s.tag = tag;
    return s;
}

- (void)applicationDidFinishLaunching:(NSNotification*)notification {
    (void)notification;
    _selectedTrack = 0;
    _trackSelect.fill(nil); _trackArm.fill(nil); _trackMute.fill(nil); _trackSolo.fill(nil);
    _mixNames.fill(nil); _mixFaders.fill(nil); _mixMute.fill(nil); _mixSolo.fill(nil);
    _audio.reset(new CoreAudioDuplex(_engine));

    self.window = [[NSWindow alloc] initWithContentRect:NSMakeRect(20, 20, 1510, 880)
                                               styleMask:(NSWindowStyleMaskTitled|NSWindowStyleMaskClosable|NSWindowStyleMaskMiniaturizable|NSWindowStyleMaskResizable)
                                                 backing:NSBackingStoreBuffered defer:NO];
    self.window.title = @"C-AUDIO V1 — Project Window";
    [self.window makeKeyAndOrderFront:nil];
    NSView* root = self.window.contentView;

    // Cubase-like organisation only: global toolbar / inspector / track list / project timeline / lower MixConsole.
    [root addSubview:[self label:@"C-AUDIO V1  |  PROJECT WINDOW  |  OUR 64-BIT ENGINE + FROZEN SSL PATH  |  NO JUCE" frame:NSMakeRect(16, 842, 900, 24) bold:YES]];
    self.devicePopup = [self popup:NSMakeRect(16, 804, 330, 28) action:@selector(deviceChanged:) tag:0]; [root addSubview:self.devicePopup];
    [root addSubview:[self button:@"|<" frame:NSMakeRect(356, 804, 46, 28) action:@selector(returnToStart:)]];
    [root addSubview:[self button:@"PLAY" frame:NSMakeRect(408, 804, 70, 28) action:@selector(play:)]];
    [root addSubview:[self button:@"STOP" frame:NSMakeRect(484, 804, 70, 28) action:@selector(stop:)]];
    [root addSubview:[self button:@"RECORD" frame:NSMakeRect(560, 804, 82, 28) action:@selector(record:)]];
    self.sslButton = [self button:@"SSL ON" frame:NSMakeRect(648, 804, 82, 28) action:@selector(toggleSSL:)]; [root addSubview:self.sslButton];
    [root addSubview:[self button:@"OPEN" frame:NSMakeRect(736, 804, 64, 28) action:@selector(openProject:)]];
    [root addSubview:[self button:@"SAVE" frame:NSMakeRect(806, 804, 64, 28) action:@selector(saveProject:)]];
    self.positionLabel = [self label:@"00:00.000" frame:NSMakeRect(882, 804, 100, 28) bold:YES]; [root addSubview:self.positionLabel];
    self.statusLabel = [self label:@"Opening CoreAudio..." frame:NSMakeRect(990, 804, 500, 28) bold:NO]; [root addSubview:self.statusLabel];

    // Inspector — context for the selected track.
    NSBox* inspector = [[NSBox alloc] initWithFrame:NSMakeRect(10, 292, 250, 500)]; inspector.title = @"INSPECTOR"; [root addSubview:inspector];
    NSView* iv = inspector.contentView;
    [iv addSubview:[self label:@"TRACK NAME" frame:NSMakeRect(10, 444, 90, 18) bold:NO]];
    _insName = [[NSTextField alloc] initWithFrame:NSMakeRect(102, 439, 128, 24)]; _insName.target=self; _insName.action=@selector(renameTrack:); [iv addSubview:_insName];
    [iv addSubview:[self label:@"FORMAT" frame:NSMakeRect(10, 410, 80, 18) bold:NO]];
    _insType=[self popup:NSMakeRect(102,405,128,25) action:@selector(inspectorTypeChanged:) tag:0]; [_insType addItemsWithTitles:@[@"MONO",@"STEREO"]]; [iv addSubview:_insType];
    [iv addSubview:[self label:@"SOURCE" frame:NSMakeRect(10, 376, 80, 18) bold:NO]];
    _insSource=[self popup:NSMakeRect(102,371,128,25) action:@selector(inspectorSourceChanged:) tag:0]; [_insSource addItemsWithTitles:@[@"FILE",@"INPUT"]]; [iv addSubview:_insSource];
    [iv addSubview:[self label:@"INPUT A" frame:NSMakeRect(10, 342, 80, 18) bold:NO]];
    _insInputA=[self popup:NSMakeRect(102,337,128,25) action:@selector(inspectorInputAChanged:) tag:0]; [iv addSubview:_insInputA];
    [iv addSubview:[self label:@"INPUT B" frame:NSMakeRect(10, 308, 80, 18) bold:NO]];
    _insInputB=[self popup:NSMakeRect(102,303,128,25) action:@selector(inspectorInputBChanged:) tag:0]; [iv addSubview:_insInputB];
    [iv addSubview:[self label:@"OUTPUT" frame:NSMakeRect(10, 274, 80, 18) bold:NO]];
    NSPopUpButton* route=[self popup:NSMakeRect(102,269,128,25) action:NULL tag:0]; [route addItemWithTitle:@"Stereo Out"]; route.enabled=NO; [iv addSubview:route];

    NSButton* imp=[self button:@"IMPORT AUDIO" frame:NSMakeRect(10,232,220,27) action:@selector(importAudio:)]; [iv addSubview:imp];
    _insFileLabel=[self label:@"No event" frame:NSMakeRect(10,210,220,18) bold:NO]; _insFileLabel.lineBreakMode=NSLineBreakByTruncatingMiddle; [iv addSubview:_insFileLabel];

    _insArm=[self toggle:@"ARM" frame:NSMakeRect(10,174,50,27) action:@selector(inspectorArmChanged:) tag:0]; [iv addSubview:_insArm];
    _insMon=[self toggle:@"MON" frame:NSMakeRect(64,174,50,27) action:@selector(inspectorMonitorChanged:) tag:0]; [iv addSubview:_insMon];
    _insMute=[self toggle:@"MUTE" frame:NSMakeRect(118,174,54,27) action:@selector(inspectorMuteChanged:) tag:0]; [iv addSubview:_insMute];
    _insSolo=[self toggle:@"SOLO" frame:NSMakeRect(176,174,54,27) action:@selector(inspectorSoloChanged:) tag:0]; [iv addSubview:_insSolo];

    [iv addSubview:[self label:@"LINE TRIM" frame:NSMakeRect(10,143,72,18) bold:NO]];
    _insTrim=[self slider:NSMakeRect(82,139,148,22) min:-20 max:20 value:0 action:@selector(inspectorTrimChanged:) tag:0]; [iv addSubview:_insTrim];
    [iv addSubview:[self label:@"FADER" frame:NSMakeRect(10,112,72,18) bold:NO]];
    _insFader=[self slider:NSMakeRect(82,108,148,22) min:-60 max:10 value:0 action:@selector(inspectorFaderChanged:) tag:0]; [iv addSubview:_insFader];
    [iv addSubview:[self label:@"PAN/BAL" frame:NSMakeRect(10,81,72,18) bold:NO]];
    _insPan=[self slider:NSMakeRect(82,77,148,22) min:-1 max:1 value:0 action:@selector(inspectorPanChanged:) tag:0]; [iv addSubview:_insPan];
    [iv addSubview:[self label:@"SSL algorithm is frozen at the approved HF-fix stage.\nEQ/Dynamics remain OFF." frame:NSMakeRect(10,24,220,42) bold:NO]];

    // Track list.
    NSBox* trackList = [[NSBox alloc] initWithFrame:NSMakeRect(266, 292, 208, 500)]; trackList.title=@"TRACK LIST"; [root addSubview:trackList];
    NSView* tv=trackList.contentView;
    for (NSUInteger i=0; i<MixerEngine::kTrackCount; ++i) {
        const CGFloat y = 414.0 - static_cast<CGFloat>(i)*68.0;
        _trackSelect[i]=[self button:[NSString stringWithFormat:@"%lu  Audio %lu",(unsigned long)(i+1),(unsigned long)(i+1)] frame:NSMakeRect(8,y+26,188,27) action:@selector(selectTrack:)]; _trackSelect[i].tag=(NSInteger)i; [tv addSubview:_trackSelect[i]];
        _trackArm[i]=[self toggle:@"R" frame:NSMakeRect(8,y,42,23) action:@selector(trackListArmChanged:) tag:(NSInteger)i]; [tv addSubview:_trackArm[i]];
        _trackMute[i]=[self toggle:@"M" frame:NSMakeRect(54,y,42,23) action:@selector(trackListMuteChanged:) tag:(NSInteger)i]; [tv addSubview:_trackMute[i]];
        _trackSolo[i]=[self toggle:@"S" frame:NSMakeRect(100,y,42,23) action:@selector(trackListSoloChanged:) tag:(NSInteger)i]; [tv addSubview:_trackSolo[i]];
    }

    // Project timeline with audio events and project locator.
    NSBox* projectBox=[[NSBox alloc] initWithFrame:NSMakeRect(480,292,1020,500)]; projectBox.title=@"PROJECT / EVENTS"; [root addSubview:projectBox];
    NSView* pv=projectBox.contentView;
    _timelineScroll=[[NSScrollView alloc] initWithFrame:NSMakeRect(6,6,1006,458)];
    _timelineScroll.hasHorizontalScroller=YES; _timelineScroll.hasVerticalScroller=YES; _timelineScroll.autohidesScrollers=YES;
    _timeline=[[ProjectTimelineView alloc] initWithFrame:NSMakeRect(0,0,1600,410) engine:&_engine];
    _timelineScroll.documentView=_timeline; [pv addSubview:_timelineScroll];

    // Lower Zone / MixConsole: same channel order as track list.
    NSBox* lower=[[NSBox alloc] initWithFrame:NSMakeRect(10,10,1490,272)]; lower.title=@"LOWER ZONE — MIXCONSOLE"; [root addSubview:lower];
    NSView* lv=lower.contentView;
    const CGFloat stripW=150.0, gap=6.0, startX=8.0;
    for(NSUInteger i=0;i<MixerEngine::kTrackCount;++i){
        const CGFloat x=startX+static_cast<CGFloat>(i)*(stripW+gap);
        NSBox* strip=[[NSBox alloc] initWithFrame:NSMakeRect(x,8,stripW,224)]; strip.title=[NSString stringWithFormat:@"CH %lu",(unsigned long)(i+1)]; [lv addSubview:strip]; NSView* sv=strip.contentView;
        _mixNames[i]=[self label:[NSString stringWithFormat:@"Audio %lu",(unsigned long)(i+1)] frame:NSMakeRect(8,169,134,18) bold:YES]; _mixNames[i].alignment=NSTextAlignmentCenter; [sv addSubview:_mixNames[i]];
        _mixMute[i]=[self toggle:@"M" frame:NSMakeRect(8,137,56,25) action:@selector(mixMuteChanged:) tag:(NSInteger)i]; [sv addSubview:_mixMute[i]];
        _mixSolo[i]=[self toggle:@"S" frame:NSMakeRect(78,137,56,25) action:@selector(mixSoloChanged:) tag:(NSInteger)i]; [sv addSubview:_mixSolo[i]];
        _mixFaders[i]=[self slider:NSMakeRect(15,34,120,88) min:-60 max:10 value:0 action:@selector(mixFaderChanged:) tag:(NSInteger)i]; [sv addSubview:_mixFaders[i]];
        NSTextField* dbLabel=[self label:@"0.0 dB" frame:NSMakeRect(8,10,134,18) bold:NO]; dbLabel.alignment=NSTextAlignmentCenter; dbLabel.tag=100+(NSInteger)i; [sv addSubview:dbLabel];
    }

    NSBox* master=[[NSBox alloc] initWithFrame:NSMakeRect(950,8,522,224)]; master.title=@"STEREO OUT / CONTROL"; [lv addSubview:master]; NSView* mv=master.contentView;
    [mv addSubview:[self label:@"OUTPUT TYPE" frame:NSMakeRect(10,165,90,18) bold:NO]];
    self.masterType=[self popup:NSMakeRect(105,160,150,25) action:@selector(masterTypeChanged:) tag:0]; [self.masterType addItemsWithTitles:@[@"STEREO",@"MONO"]]; [mv addSubview:self.masterType];
    [mv addSubview:[self label:@"OUT A / LEFT" frame:NSMakeRect(10,131,90,18) bold:NO]];
    self.masterOutA=[self popup:NSMakeRect(105,126,150,25) action:@selector(masterOutChanged:) tag:0]; [mv addSubview:self.masterOutA];
    [mv addSubview:[self label:@"OUT B / RIGHT" frame:NSMakeRect(10,97,90,18) bold:NO]];
    self.masterOutB=[self popup:NSMakeRect(105,92,150,25) action:@selector(masterOutChanged:) tag:1]; [mv addSubview:self.masterOutB];
    [mv addSubview:[self label:@"MASTER" frame:NSMakeRect(276,165,70,18) bold:NO]];
    NSSlider* mf=[self slider:NSMakeRect(342,160,160,22) min:-60 max:10 value:0 action:@selector(masterChanged:) tag:0]; [mv addSubview:mf];
    self.masterMeter=[self label:@"L -∞   R -∞" frame:NSMakeRect(276,126,226,26) bold:YES]; [mv addSubview:self.masterMeter];
    [mv addSubview:[self label:@"Track routing -> Stereo Out -> current C-AUDIO SSL ON/OFF path -> CoreAudio hardware out.\nWorkflow organisation follows the Project/Inspector/MixConsole model; DSP is ours." frame:NSMakeRect(276,49,226,62) bold:NO]];

    [self refreshDevices];
    [self openSelectedDevice];
    [self syncInspector];
    [self syncAllTrackControls];
    [_timeline refreshProjectExtent];
    _meterTimer=[NSTimer scheduledTimerWithTimeInterval:0.05 target:self selector:@selector(updateMeters:) userInfo:nil repeats:YES];
}

- (BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication*)sender { (void)sender; return YES; }
- (void)applicationWillTerminate:(NSNotification*)notification { (void)notification; [_meterTimer invalidate]; _engine.stopRecording(); if(_audio) _audio->close(); }

- (void)refreshDevices {
    _devices=CoreAudioDuplex::devices(); [self.devicePopup removeAllItems]; AudioDeviceID def=CoreAudioDuplex::defaultOutputDevice(); NSInteger sel=0;
    for(NSUInteger i=0;i<_devices.size();++i){ NSString* t=[NSString stringWithFormat:@"%s  [%u in / %u out]",_devices[i].name.c_str(),_devices[i].inputChannels,_devices[i].outputChannels]; [self.devicePopup addItemWithTitle:t]; if(_devices[i].id==def) sel=(NSInteger)i; }
    if(!_devices.empty()) [self.devicePopup selectItemAtIndex:sel];
}

- (void)rebuildIOPopups {
    const NSUInteger ins=_audio?(NSUInteger)_audio->inputChannels():0, outs=_audio?(NSUInteger)_audio->outputChannels():0;
    [_insInputA removeAllItems]; [_insInputB removeAllItems];
    for(NSUInteger i=0;i<ins;++i){ NSString* s=[NSString stringWithFormat:@"Input %lu",(unsigned long)(i+1)]; [_insInputA addItemWithTitle:s]; [_insInputB addItemWithTitle:s]; }
    [self.masterOutA removeAllItems]; [self.masterOutB removeAllItems];
    for(NSUInteger i=0;i<outs;++i){ NSString* s=[NSString stringWithFormat:@"Output %lu",(unsigned long)(i+1)]; [self.masterOutA addItemWithTitle:s]; [self.masterOutB addItemWithTitle:s]; }
    if(outs){ [self.masterOutA selectItemAtIndex:0]; [self.masterOutB selectItemAtIndex:MIN((NSUInteger)1,outs-1)]; _engine.setOutputA(0); _engine.setOutputB((int)MIN((NSUInteger)1,outs-1)); }
    [self syncInspector];
}

- (void)openSelectedDevice {
    NSInteger idx=self.devicePopup.indexOfSelectedItem;
    if(idx<0||(NSUInteger)idx>=_devices.size()){self.statusLabel.stringValue=@"No CoreAudio device";return;}
    std::string err;
    if(_audio->open(_devices[(NSUInteger)idx].id,err)){
        self.statusLabel.stringValue=[NSString stringWithFormat:@"%.0f Hz | %u frames | %u in | %u out | 64-bit engine",_audio->sampleRate(),_audio->bufferFrames(),_audio->inputChannels(),_audio->outputChannels()];
        [self rebuildIOPopups]; [_timeline refreshProjectExtent];
    } else self.statusLabel.stringValue=[NSString stringWithUTF8String:err.c_str()];
}

- (void)syncInspector {
    const std::size_t i=(std::size_t)_selectedTrack; const MixerEngine::Track& t=_engine.track(i);
    _insName.stringValue=[NSString stringWithUTF8String:t.name.c_str()];
    [_insType selectItemAtIndex:t.format.load()==(int)TrackFormat::Stereo?1:0];
    [_insSource selectItemAtIndex:t.source.load()==(int)TrackSource::HardwareInput?1:0];
    const NSInteger ia=t.inputA.load(), ib=t.inputB.load();
    if(_insInputA.numberOfItems>0) [_insInputA selectItemAtIndex:MIN(MAX((NSInteger)0,ia),_insInputA.numberOfItems-1)];
    if(_insInputB.numberOfItems>0) [_insInputB selectItemAtIndex:MIN(MAX((NSInteger)0,ib),_insInputB.numberOfItems-1)];
    _insInputB.enabled=(t.format.load()==(int)TrackFormat::Stereo);
    _insArm.state=t.recordArm.load()?NSControlStateValueOn:NSControlStateValueOff;
    _insMon.state=t.inputMonitor.load()?NSControlStateValueOn:NSControlStateValueOff;
    _insMute.state=t.mute.load()?NSControlStateValueOn:NSControlStateValueOff;
    _insSolo.state=t.solo.load()?NSControlStateValueOn:NSControlStateValueOff;
    _insTrim.doubleValue=t.inputTrimDb.load(); _insFader.doubleValue=t.faderDb.load(); _insPan.doubleValue=t.pan.load();
    _insFileLabel.stringValue=t.clip.name.empty()?@"No event":[NSString stringWithUTF8String:t.clip.name.c_str()];
}

- (void)syncTrackControls:(NSUInteger)i {
    const MixerEngine::Track& t=_engine.track((std::size_t)i);
    NSString* name=[NSString stringWithUTF8String:t.name.c_str()];
    _trackSelect[i].title=[NSString stringWithFormat:@"%lu  %@",(unsigned long)(i+1),name];
    _trackArm[i].state=t.recordArm.load()?NSControlStateValueOn:NSControlStateValueOff;
    _trackMute[i].state=t.mute.load()?NSControlStateValueOn:NSControlStateValueOff;
    _trackSolo[i].state=t.solo.load()?NSControlStateValueOn:NSControlStateValueOff;
    _mixNames[i].stringValue=name; _mixFaders[i].doubleValue=t.faderDb.load();
    _mixMute[i].state=t.mute.load()?NSControlStateValueOn:NSControlStateValueOff;
    _mixSolo[i].state=t.solo.load()?NSControlStateValueOn:NSControlStateValueOff;
    NSTextField* dbLabel=(NSTextField*)[_mixFaders[i].superview viewWithTag:100+(NSInteger)i];
    if(dbLabel) dbLabel.stringValue=[NSString stringWithFormat:@"%.1f dB",t.faderDb.load()];
}

- (void)syncAllTrackControls { for(NSUInteger i=0;i<MixerEngine::kTrackCount;++i)[self syncTrackControls:i]; }

- (void)selectTrack:(NSButton*)sender { _selectedTrack=sender.tag; [_timeline setSelectedTrackIndex:(NSUInteger)_selectedTrack]; [self syncInspector]; }
- (void)renameTrack:(NSTextField*)sender { if(_engine.isPlaying()||_engine.isRecording())return; _engine.track((std::size_t)_selectedTrack).name=sender.stringValue.UTF8String; [self syncTrackControls:(NSUInteger)_selectedTrack]; }

- (void)deviceChanged:(id)sender { (void)sender; _engine.stopRecording(); _engine.stop(); _audio->close(); [self openSelectedDevice]; }
- (void)returnToStart:(id)sender { (void)sender; _engine.returnToStart(); [_timeline setNeedsDisplay:YES]; }
- (void)play:(id)sender { (void)sender; _engine.play(); }
- (void)stop:(id)sender { (void)sender; _engine.stopRecording(); _engine.stop(); self.statusLabel.stringValue=[NSString stringWithFormat:@"Stopped | dropped record frames: %llu",(unsigned long long)_engine.droppedRecordFrames()]; }

- (void)record:(id)sender {
    (void)sender;
    if(!_audio||!_audio->inputChannels()){self.statusLabel.stringValue=@"Selected device has no CoreAudio inputs.";return;}
    NSOpenPanel* p=[NSOpenPanel openPanel]; p.canChooseFiles=NO; p.canChooseDirectories=YES; p.canCreateDirectories=YES; p.allowsMultipleSelection=NO; p.prompt=@"Record Here";
    if([p runModal]!=NSModalResponseOK)return;
    std::string err;
    if(!_engine.startRecording(p.URL.path.UTF8String,err)){NSAlert*a=[[NSAlert alloc]init];a.messageText=@"Record failed";a.informativeText=[NSString stringWithUTF8String:err.c_str()];[a runModal];return;}
    self.statusLabel.stringValue=@"RECORDING — dry hardware inputs to WAV; monitoring follows the selected C-AUDIO path";
}

- (void)toggleSSL:(id)sender { (void)sender; const bool enabled=!_engine.sslEnabled(); _engine.setSSLEnabled(enabled); self.sslButton.title=enabled?@"SSL ON":@"SSL OFF"; }

- (void)saveProject:(id)sender {
    (void)sender;
    if(_engine.isRecording()){self.statusLabel.stringValue=@"Stop recording before saving the project.";return;}
    NSSavePanel* p=[NSSavePanel savePanel]; p.allowedFileTypes=@[@"caudio"]; p.nameFieldStringValue=@"C-AUDIO Project.caudio";
    if([p runModal]!=NSModalResponseOK)return;
    std::string error; const ProjectState state=ProjectFile::capture(_engine);
    if(!ProjectFile::save(p.URL.path.UTF8String,state,error)){NSAlert*a=[[NSAlert alloc]init];a.messageText=@"Save failed";a.informativeText=[NSString stringWithUTF8String:error.c_str()];[a runModal];return;}
    self.statusLabel.stringValue=@"Project saved.";
}

- (void)openProject:(id)sender {
    (void)sender;
    _engine.stopRecording(); _engine.stop();
    NSOpenPanel* p=[NSOpenPanel openPanel]; p.canChooseDirectories=NO; p.allowsMultipleSelection=NO; p.allowedFileTypes=@[@"caudio"];
    if([p runModal]!=NSModalResponseOK)return;
    ProjectState state; std::string error;
    if(!ProjectFile::load(p.URL.path.UTF8String,state,error)){NSAlert*a=[[NSAlert alloc]init];a.messageText=@"Open failed";a.informativeText=[NSString stringWithUTF8String:error.c_str()];[a runModal];return;}
    for(std::size_t i=0;i<MixerEngine::kTrackCount;++i)_engine.clearClip(i);
    std::string missing;
    for(std::size_t i=0;i<MixerEngine::kTrackCount;++i){
        const std::string& path=state.tracks[i].sourcePath; if(path.empty())continue;
        AudioClip clip; std::string loadError;
        if(AudioFileLoader::load(path,_engine.sampleRate(),clip,loadError)){ _engine.setClip(i,std::move(clip)); }
        else { if(!missing.empty())missing += "\n"; missing += path; }
    }
    ProjectFile::applyMetadata(_engine,state);
    self.sslButton.title=_engine.sslEnabled()?@"SSL ON":@"SSL OFF";
    [self.masterType selectItemAtIndex:_engine.outputFormat()==OutputFormat::Mono?1:0]; self.masterOutB.enabled=_engine.outputFormat()!=OutputFormat::Mono;
    if(self.masterOutA.numberOfItems>0)[self.masterOutA selectItemAtIndex:MIN(MAX((NSInteger)0,_engine.outputA()),self.masterOutA.numberOfItems-1)];
    if(self.masterOutB.numberOfItems>0)[self.masterOutB selectItemAtIndex:MIN(MAX((NSInteger)0,_engine.outputB()),self.masterOutB.numberOfItems-1)];
    [self syncAllTrackControls]; [self syncInspector]; [_timeline refreshProjectExtent];
    if(missing.empty()) self.statusLabel.stringValue=@"Project opened.";
    else self.statusLabel.stringValue=@"Project opened; one or more source audio files are missing.";
}

- (void)inspectorTypeChanged:(NSPopUpButton*)s { auto&t=_engine.track((std::size_t)_selectedTrack); t.format.store(s.indexOfSelectedItem==1?(int)TrackFormat::Stereo:(int)TrackFormat::Mono); _insInputB.enabled=(s.indexOfSelectedItem==1); }
- (void)inspectorSourceChanged:(NSPopUpButton*)s { _engine.track((std::size_t)_selectedTrack).source.store(s.indexOfSelectedItem==1?(int)TrackSource::HardwareInput:(int)TrackSource::File); }
- (void)inspectorInputAChanged:(NSPopUpButton*)s { _engine.track((std::size_t)_selectedTrack).inputA.store((int)s.indexOfSelectedItem); }
- (void)inspectorInputBChanged:(NSPopUpButton*)s { _engine.track((std::size_t)_selectedTrack).inputB.store((int)s.indexOfSelectedItem); }
- (void)inspectorArmChanged:(NSButton*)s { auto&t=_engine.track((std::size_t)_selectedTrack); t.recordArm.store(s.state==NSControlStateValueOn); [self syncTrackControls:(NSUInteger)_selectedTrack]; }
- (void)inspectorMonitorChanged:(NSButton*)s { _engine.track((std::size_t)_selectedTrack).inputMonitor.store(s.state==NSControlStateValueOn); }
- (void)inspectorMuteChanged:(NSButton*)s { auto&t=_engine.track((std::size_t)_selectedTrack); t.mute.store(s.state==NSControlStateValueOn); [self syncTrackControls:(NSUInteger)_selectedTrack]; }
- (void)inspectorSoloChanged:(NSButton*)s { auto&t=_engine.track((std::size_t)_selectedTrack); t.solo.store(s.state==NSControlStateValueOn); [self syncTrackControls:(NSUInteger)_selectedTrack]; }
- (void)inspectorTrimChanged:(NSSlider*)s { _engine.track((std::size_t)_selectedTrack).inputTrimDb.store(s.doubleValue); }
- (void)inspectorFaderChanged:(NSSlider*)s { _engine.track((std::size_t)_selectedTrack).faderDb.store(s.doubleValue); [self syncTrackControls:(NSUInteger)_selectedTrack]; }
- (void)inspectorPanChanged:(NSSlider*)s { _engine.track((std::size_t)_selectedTrack).pan.store(s.doubleValue); }

- (void)trackListArmChanged:(NSButton*)s { _engine.track((std::size_t)s.tag).recordArm.store(s.state==NSControlStateValueOn); if(s.tag==_selectedTrack)[self syncInspector]; }
- (void)trackListMuteChanged:(NSButton*)s { _engine.track((std::size_t)s.tag).mute.store(s.state==NSControlStateValueOn); [self syncTrackControls:(NSUInteger)s.tag]; if(s.tag==_selectedTrack)[self syncInspector]; }
- (void)trackListSoloChanged:(NSButton*)s { _engine.track((std::size_t)s.tag).solo.store(s.state==NSControlStateValueOn); [self syncTrackControls:(NSUInteger)s.tag]; if(s.tag==_selectedTrack)[self syncInspector]; }
- (void)mixMuteChanged:(NSButton*)s { _engine.track((std::size_t)s.tag).mute.store(s.state==NSControlStateValueOn); [self syncTrackControls:(NSUInteger)s.tag]; if(s.tag==_selectedTrack)[self syncInspector]; }
- (void)mixSoloChanged:(NSButton*)s { _engine.track((std::size_t)s.tag).solo.store(s.state==NSControlStateValueOn); [self syncTrackControls:(NSUInteger)s.tag]; if(s.tag==_selectedTrack)[self syncInspector]; }
- (void)mixFaderChanged:(NSSlider*)s { _engine.track((std::size_t)s.tag).faderDb.store(s.doubleValue); [self syncTrackControls:(NSUInteger)s.tag]; if(s.tag==_selectedTrack)[self syncInspector]; }

- (void)masterChanged:(NSSlider*)s { _engine.setMasterDb(s.doubleValue); }
- (void)masterTypeChanged:(NSPopUpButton*)s { const bool mono=s.indexOfSelectedItem==1; _engine.setOutputFormat(mono?OutputFormat::Mono:OutputFormat::Stereo); self.masterOutB.enabled=!mono; }
- (void)masterOutChanged:(NSPopUpButton*)s { if(s.tag==0)_engine.setOutputA((int)s.indexOfSelectedItem);else _engine.setOutputB((int)s.indexOfSelectedItem); }

- (void)importAudio:(id)sender {
    (void)sender;
    if(_engine.isPlaying()||_engine.isRecording()){self.statusLabel.stringValue=@"Stop transport before importing audio.";return;}
    NSOpenPanel*p=[NSOpenPanel openPanel]; p.canChooseDirectories=NO; p.allowsMultipleSelection=NO; p.allowedFileTypes=@[@"wav",@"aif",@"aiff",@"caf"];
    if([p runModal]!=NSModalResponseOK)return;
    AudioClip clip; std::string err;
    if(!AudioFileLoader::load(p.URL.path.UTF8String,_engine.sampleRate(),clip,err)){NSAlert*a=[[NSAlert alloc]init];a.messageText=@"Import failed";a.informativeText=[NSString stringWithUTF8String:err.c_str()];[a runModal];return;}
    const std::size_t i=(std::size_t)_selectedTrack; const bool stereo=clip.stereo;
    if(_engine.setClip(i,std::move(clip))){
        _engine.track(i).format.store(stereo?(int)TrackFormat::Stereo:(int)TrackFormat::Mono);
        _engine.track(i).source.store((int)TrackSource::File);
        [self syncInspector]; [self syncTrackControls:(NSUInteger)i]; [_timeline refreshProjectExtent];
        self.statusLabel.stringValue=@"Audio event imported at the current project cursor.";
    }
}

- (void)updateMeters:(NSTimer*)timer {
    (void)timer;
    auto meterDb=[](double p){return p>1e-12?20.0*std::log10(p):-120.0;};
    self.masterMeter.stringValue=[NSString stringWithFormat:@"L %.1f dBFS   R %.1f dBFS",meterDb(_engine.peakLeft()),meterDb(_engine.peakRight())];
    const double seconds=static_cast<double>(_engine.playhead())/std::max(1.0,_engine.sampleRate());
    const NSInteger mins=(NSInteger)(seconds/60.0); const double secs=seconds-(double)mins*60.0;
    self.positionLabel.stringValue=[NSString stringWithFormat:@"%02ld:%06.3f",(long)mins,secs];
    [_timeline setNeedsDisplay:YES];
    if(_engine.isRecording()&&_engine.droppedRecordFrames()>0) self.statusLabel.stringValue=[NSString stringWithFormat:@"RECORDING — WARNING: %llu dropped frames",(unsigned long long)_engine.droppedRecordFrames()];
}

@end
