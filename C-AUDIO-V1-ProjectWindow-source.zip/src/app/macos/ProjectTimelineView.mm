#import "ProjectTimelineView.h"
#import "../../engine/MixerEngine.h"

#include <algorithm>
#include <cmath>

using namespace caudio;

namespace {
constexpr CGFloat kRulerHeight = 26.0;
constexpr CGFloat kLaneHeight = 64.0;
constexpr CGFloat kPixelsPerSecond = 110.0;
constexpr CGFloat kMinimumWidth = 1600.0;
}

@implementation ProjectTimelineView {
    MixerEngine* _engine;
    NSUInteger _selectedTrack;
}

- (instancetype)initWithFrame:(NSRect)frame engine:(MixerEngine*)engine {
    self = [super initWithFrame:frame];
    if (self) {
        _engine = engine;
        _selectedTrack = 0;
        self.wantsLayer = YES;
    }
    return self;
}

- (BOOL)isFlipped { return YES; }

- (void)setSelectedTrackIndex:(NSUInteger)index {
    _selectedTrack = std::min<NSUInteger>(index, MixerEngine::kTrackCount - 1);
    [self setNeedsDisplay:YES];
}

- (void)refreshProjectExtent {
    if (!_engine) return;
    const double fs = std::max(1.0, _engine->sampleRate());
    const double endSeconds = static_cast<double>(_engine->projectEndFrame()) / fs;
    const CGFloat wanted = std::max(kMinimumWidth, static_cast<CGFloat>((endSeconds + 10.0) * kPixelsPerSecond));
    NSSize size = self.frame.size;
    size.width = wanted;
    size.height = kRulerHeight + kLaneHeight * MixerEngine::kTrackCount;
    [self setFrameSize:size];
    [self setNeedsDisplay:YES];
}

- (void)drawRect:(NSRect)dirtyRect {
    [super drawRect:dirtyRect];
    [[NSColor controlBackgroundColor] setFill];
    NSRectFill(dirtyRect);
    if (!_engine) return;

    const double fs = std::max(1.0, _engine->sampleRate());
    NSDictionary* rulerAttrs = @{NSFontAttributeName:[NSFont systemFontOfSize:9.0], NSForegroundColorAttributeName:[NSColor secondaryLabelColor]};
    NSDictionary* eventAttrs = @{NSFontAttributeName:[NSFont boldSystemFontOfSize:10.0], NSForegroundColorAttributeName:[NSColor controlTextColor]};

    // Time ruler in seconds. Audio/MIDI bar ruler can sit on this same project-time model later.
    [[NSColor separatorColor] setStroke];
    NSBezierPath* rulerLine = [NSBezierPath bezierPath];
    [rulerLine moveToPoint:NSMakePoint(0.0, kRulerHeight - 0.5)];
    [rulerLine lineToPoint:NSMakePoint(self.bounds.size.width, kRulerHeight - 0.5)];
    [rulerLine stroke];
    const NSInteger maxSec = static_cast<NSInteger>(std::ceil(self.bounds.size.width / kPixelsPerSecond));
    for (NSInteger sec = 0; sec <= maxSec; ++sec) {
        const CGFloat x = static_cast<CGFloat>(sec) * kPixelsPerSecond;
        NSBezierPath* tick = [NSBezierPath bezierPath];
        [tick moveToPoint:NSMakePoint(x + 0.5, 12.0)];
        [tick lineToPoint:NSMakePoint(x + 0.5, kRulerHeight)];
        [tick stroke];
        [[NSString stringWithFormat:@"%lds", (long)sec] drawAtPoint:NSMakePoint(x + 4.0, 2.0) withAttributes:rulerAttrs];
    }

    for (NSUInteger i = 0; i < MixerEngine::kTrackCount; ++i) {
        const CGFloat y = kRulerHeight + static_cast<CGFloat>(i) * kLaneHeight;
        if (i == _selectedTrack) {
            [[[NSColor selectedControlColor] colorWithAlphaComponent:0.10] setFill];
            NSRectFill(NSMakeRect(0.0, y, self.bounds.size.width, kLaneHeight));
        }
        [[NSColor separatorColor] setStroke];
        NSBezierPath* lane = [NSBezierPath bezierPath];
        [lane moveToPoint:NSMakePoint(0.0, y + kLaneHeight - 0.5)];
        [lane lineToPoint:NSMakePoint(self.bounds.size.width, y + kLaneHeight - 0.5)];
        [lane stroke];

        const MixerEngine::Track& t = _engine->track(i);
        if (t.clip.frames() == 0) continue;
        const double startSec = static_cast<double>(_engine->eventStartFrame(i)) / fs;
        const double lenSec = static_cast<double>(t.clip.frames()) / fs;
        const CGFloat x = static_cast<CGFloat>(startSec * kPixelsPerSecond);
        const CGFloat w = std::max<CGFloat>(8.0, static_cast<CGFloat>(lenSec * kPixelsPerSecond));
        NSRect eventRect = NSMakeRect(x + 1.0, y + 7.0, w - 2.0, kLaneHeight - 14.0);
        [[[NSColor selectedControlColor] colorWithAlphaComponent:(i == _selectedTrack ? 0.34 : 0.22)] setFill];
        NSBezierPath* eventPath = [NSBezierPath bezierPathWithRoundedRect:eventRect xRadius:4.0 yRadius:4.0];
        [eventPath fill];
        NSString* title = t.clip.name.empty() ? @"Audio Event" : [NSString stringWithUTF8String:t.clip.name.c_str()];
        [title drawInRect:NSInsetRect(eventRect, 7.0, 5.0) withAttributes:eventAttrs];
    }

    const double playSeconds = static_cast<double>(_engine->playhead()) / fs;
    const CGFloat px = static_cast<CGFloat>(playSeconds * kPixelsPerSecond);
    [[NSColor keyboardFocusIndicatorColor] setStroke];
    NSBezierPath* cursor = [NSBezierPath bezierPath];
    cursor.lineWidth = 1.5;
    [cursor moveToPoint:NSMakePoint(px, 0.0)];
    [cursor lineToPoint:NSMakePoint(px, self.bounds.size.height)];
    [cursor stroke];
}

- (void)mouseDown:(NSEvent*)event {
    if (!_engine || _engine->isRecording()) return;
    const NSPoint p = [self convertPoint:event.locationInWindow fromView:nil];
    if (p.x < 0.0) return;
    const double seconds = static_cast<double>(p.x / kPixelsPerSecond);
    const std::uint64_t frame = static_cast<std::uint64_t>(std::llround(seconds * _engine->sampleRate()));
    _engine->setPlayhead(frame);
    [self setNeedsDisplay:YES];
}

@end
