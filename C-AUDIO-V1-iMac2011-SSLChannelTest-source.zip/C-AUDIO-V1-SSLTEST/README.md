# C-AUDIO V1 — SSL Channel Test (iMac 2011)

Purpose: a listening/recording test of six SSL 4000 E **line-channel** paths before the mix-bus/output model is added.

## Exactly what is in this build
- 6 tracks, each selectable MONO or STEREO.
- Stereo track = two independent linked SSL channel paths (L/R), not one generic stereo effect.
- FILE or hardware INPUT source.
- Import WAV/AIFF/CAF.
- CoreAudio device selection and visible physical input/output channel counts.
- Per track: input A/B, Record Arm, Input Monitor, Mute, Solo, SSL line trim, VCA fader, Pan/Balance.
- Record armed hardware inputs to 32-bit float WAV via a lock-free ring buffer + disk writer thread.
- Master can route to MONO or STEREO physical outputs.
- 64-bit compensated summing.
- No JUCE or external DSP framework.

## SSL channel scope
The channel model follows the original 82E149 line-channel drawing:
- 2.2 uF / 30.1 k input coupling network.
- line/input-select active stages using the 5534 family and their visible RC poles.
- Channel Fader Select path.
- dbx 202C/gold-can family VCA control in dB, with nonlinear residual bounded to published 202C THD/current data rather than a generic tanh saturator.
- compensated 5534 slew/output limits.
- separate odd/even 82E149 routing-pan buffer paths with their 10 uF/24.9 k and 100 uF/4.7 k coupling networks.
- SSL-style -4.5 dB centre pan law for mono tracks.

EQ and dynamics are **OFF by design**, because this test is specifically the clean console channel/fader/pan path requested before adding those modules.
The master is deliberately transparent in this build; the SSL mix amplifier/output section is a later separately measurable stage.

## Important engineering note
This is a circuit-informed test model, not a claim that the private component model used by SSL/UAD has been reverse engineered. The dbx 202C data constrains gain law, noise and total distortion, but a final spectral fingerprint still needs measurement against a known physical 4000 E channel.

## Build
Requires macOS/Xcode with CMake:

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release -DCMAKE_OSX_DEPLOYMENT_TARGET=10.13 -DCMAKE_OSX_ARCHITECTURES=x86_64
cmake --build build --config Release
ctest --test-dir build --output-on-failure
```
