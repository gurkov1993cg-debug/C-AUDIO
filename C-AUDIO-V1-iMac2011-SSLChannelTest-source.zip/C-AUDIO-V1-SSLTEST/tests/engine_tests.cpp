#include "SSLChannel.h"
#include "MixerEngine.h"

#include <cmath>
#include <iostream>
#include <vector>

using namespace caudio;

static bool isFiniteValue(double x){ return std::isfinite(x); }
#define REQUIRE(x) do { if(!(x)){ std::cerr << "FAIL: " #x " at line " << __LINE__ << "\n"; return 1; } } while(0)

int main(){
    SSLChannel ch; ch.prepare(48000.0, 12345); ch.setInputTrimDb(0); ch.setFaderDb(0); ch.setPan(0);
    double l=0,r=0; double peak=0;
    for(int n=0;n<48000;++n){ const double x=0.1*std::sin(2.0*3.141592653589793*1000.0*n/48000.0); ch.process(x,l,r); REQUIRE(isFiniteValue(l)&&isFiniteValue(r)); peak=std::max(peak,std::max(std::abs(l),std::abs(r))); }
    REQUIRE(peak>0.02 && peak<0.2);

    // SSL-style centre pan should be about -4.5 dB per side for a mono source.
    const double centre = SSLChannel::panGainLeft(0.0);
    const double centreDb = 20.0*std::log10(centre);
    REQUIRE(std::abs(centreDb + 4.5) < 0.02);
    REQUIRE(SSLChannel::panGainLeft(-1.0) > 0.999);
    REQUIRE(SSLChannel::panGainRight(-1.0) < 1e-8);

    MixerEngine e; e.prepare(48000,512);
    AudioClip clip; clip.left.resize(2048,0.05); clip.right=clip.left; clip.stereo=false; clip.name="test";
    REQUIRE(e.setClip(0,std::move(clip))); e.track(0).format.store((int)TrackFormat::Mono); e.track(0).source.store((int)TrackSource::File); e.play();
    std::vector<double> o0(512),o1(512); double* outs[2]={o0.data(),o1.data()};
    e.process(nullptr,0,outs,2,512);
    double sum=0; for(double v:o0){ REQUIRE(isFiniteValue(v)); sum+=std::abs(v); } REQUIRE(sum>0.01);

    // Mute must actually silence a channel contribution.
    e.stop(); for(std::size_t i=0;i<MixerEngine::kTrackCount;++i) e.track(i).mute.store(true); e.play(); std::fill(o0.begin(),o0.end(),1.0); std::fill(o1.begin(),o1.end(),1.0); e.process(nullptr,0,outs,2,512);
    double muted=0; for(double v:o0) muted+=std::abs(v); REQUIRE(muted<1e-9);

    std::cout << "C-AUDIO engine tests passed\n";
    return 0;
}
