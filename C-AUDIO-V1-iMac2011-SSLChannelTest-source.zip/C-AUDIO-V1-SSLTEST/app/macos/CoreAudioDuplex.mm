#include "CoreAudioDuplex.h"

#import <AudioToolbox/AudioToolbox.h>

#include <algorithm>
#include <cctype>
#include <cstdio>
#include <vector>

namespace caudio {
namespace {
std::string osStatusText(OSStatus status) {
    char text[64] = {};
    const UInt32 be = CFSwapInt32HostToBig(static_cast<UInt32>(status));
    if (std::isprint((be >> 24) & 0xff) && std::isprint((be >> 16) & 0xff) &&
        std::isprint((be >> 8) & 0xff) && std::isprint(be & 0xff)) {
        std::snprintf(text, sizeof(text), "'%c%c%c%c'", (be >> 24) & 0xff, (be >> 16) & 0xff, (be >> 8) & 0xff, be & 0xff);
    } else std::snprintf(text, sizeof(text), "%d", static_cast<int>(status));
    return text;
}

bool getDeviceName(AudioDeviceID id, std::string& name) {
    AudioObjectPropertyAddress a = { kAudioObjectPropertyName, kAudioObjectPropertyScopeGlobal, kAudioObjectPropertyElementMaster };
    CFStringRef s = nullptr; UInt32 size = sizeof(s);
    if (AudioObjectGetPropertyData(id, &a, 0, nullptr, &size, &s) != noErr || !s) return false;
    char buf[512] = {};
    const bool ok = CFStringGetCString(s, buf, sizeof(buf), kCFStringEncodingUTF8);
    CFRelease(s); if (ok) name = buf; return ok;
}

std::uint32_t channelCount(AudioDeviceID id, AudioObjectPropertyScope scope) {
    AudioObjectPropertyAddress a = { kAudioDevicePropertyStreamConfiguration, scope, kAudioObjectPropertyElementMaster };
    UInt32 size = 0;
    if (AudioObjectGetPropertyDataSize(id, &a, 0, nullptr, &size) != noErr || !size) return 0;
    std::vector<unsigned char> mem(size);
    auto* abl = reinterpret_cast<AudioBufferList*>(mem.data());
    if (AudioObjectGetPropertyData(id, &a, 0, nullptr, &size, abl) != noErr) return 0;
    std::uint32_t n = 0; for (UInt32 i = 0; i < abl->mNumberBuffers; ++i) n += abl->mBuffers[i].mNumberChannels;
    return n;
}

AudioStreamBasicDescription float64NonInterleaved(double rate, std::uint32_t channels) {
    AudioStreamBasicDescription f = {};
    f.mSampleRate = rate; f.mFormatID = kAudioFormatLinearPCM;
    f.mFormatFlags = kAudioFormatFlagIsFloat | kAudioFormatFlagsNativeEndian | kAudioFormatFlagIsNonInterleaved;
    f.mBytesPerPacket = sizeof(double); f.mFramesPerPacket = 1; f.mBytesPerFrame = sizeof(double);
    f.mChannelsPerFrame = channels; f.mBitsPerChannel = 64; return f;
}
}

CoreAudioDuplex::~CoreAudioDuplex() { close(); }

std::vector<AudioDeviceInfo> CoreAudioDuplex::devices() {
    AudioObjectPropertyAddress a = { kAudioHardwarePropertyDevices, kAudioObjectPropertyScopeGlobal, kAudioObjectPropertyElementMaster };
    UInt32 size = 0; std::vector<AudioDeviceInfo> out;
    if (AudioObjectGetPropertyDataSize(kAudioObjectSystemObject, &a, 0, nullptr, &size) != noErr) return out;
    std::vector<AudioDeviceID> ids(size / sizeof(AudioDeviceID));
    if (AudioObjectGetPropertyData(kAudioObjectSystemObject, &a, 0, nullptr, &size, ids.data()) != noErr) return out;
    for (auto id : ids) {
        const auto ins = channelCount(id, kAudioObjectPropertyScopeInput);
        const auto outs = channelCount(id, kAudioObjectPropertyScopeOutput);
        if (outs == 0) continue;
        std::string name; if (!getDeviceName(id, name)) continue;
        out.push_back({id, name, ins, outs});
    }
    return out;
}

AudioDeviceID CoreAudioDuplex::defaultOutputDevice() {
    AudioDeviceID id = kAudioObjectUnknown; UInt32 size = sizeof(id);
    AudioObjectPropertyAddress a = { kAudioHardwarePropertyDefaultOutputDevice, kAudioObjectPropertyScopeGlobal, kAudioObjectPropertyElementMaster };
    AudioObjectGetPropertyData(kAudioObjectSystemObject, &a, 0, nullptr, &size, &id); return id;
}

bool CoreAudioDuplex::allocateInputABL(std::uint32_t channels, std::uint32_t maxFrames, std::string& error) {
    inputABL_ = nullptr; inputABLStorage_.clear(); inputScratch_.clear();
    if (!channels) return true;
    if (channels > MixerEngine::kMaxHardwareChannels) { error = "Input device has more than 64 channels; V1 limit is 64."; return false; }
    const std::size_t bytes = offsetof(AudioBufferList, mBuffers) + channels * sizeof(AudioBuffer);
    inputABLStorage_.assign(bytes, 0); inputABL_ = reinterpret_cast<AudioBufferList*>(inputABLStorage_.data());
    inputABL_->mNumberBuffers = channels;
    inputScratch_.assign(static_cast<std::size_t>(channels) * maxFrames, 0.0);
    for (std::uint32_t ch = 0; ch < channels; ++ch) {
        inputABL_->mBuffers[ch].mNumberChannels = 1;
        inputABL_->mBuffers[ch].mDataByteSize = maxFrames * sizeof(double);
        inputABL_->mBuffers[ch].mData = inputScratch_.data() + static_cast<std::size_t>(ch) * maxFrames;
        inputPtrs_[ch] = static_cast<const double*>(inputABL_->mBuffers[ch].mData);
    }
    return true;
}

bool CoreAudioDuplex::open(AudioDeviceID device, std::string& error) {
    close(); if (!configure(device, error)) { close(); return false; }
    OSStatus st = AudioUnitInitialize(unit_);
    if (st != noErr) { error = "AudioUnitInitialize failed: " + osStatusText(st); close(); return false; }
    st = AudioOutputUnitStart(unit_);
    if (st != noErr) { error = "AudioOutputUnitStart failed: " + osStatusText(st); close(); return false; }
    return true;
}

bool CoreAudioDuplex::configure(AudioDeviceID device, std::string& error) {
    AudioComponentDescription d = {}; d.componentType = kAudioUnitType_Output; d.componentSubType = kAudioUnitSubType_HALOutput; d.componentManufacturer = kAudioUnitManufacturer_Apple;
    AudioComponent c = AudioComponentFindNext(nullptr, &d);
    if (!c || AudioComponentInstanceNew(c, &unit_) != noErr) { error = "Cannot create HAL Output AudioUnit"; return false; }

    UInt32 one = 1, zero = 0;
    OSStatus st = AudioUnitSetProperty(unit_, kAudioOutputUnitProperty_EnableIO, kAudioUnitScope_Output, 0, &one, sizeof(one));
    if (st != noErr) { error = "Cannot enable output IO"; return false; }
    st = AudioUnitSetProperty(unit_, kAudioOutputUnitProperty_EnableIO, kAudioUnitScope_Input, 1, &one, sizeof(one));
    if (st != noErr) {
        // Output-only devices are still useful for imported-audio listening.
        AudioUnitSetProperty(unit_, kAudioOutputUnitProperty_EnableIO, kAudioUnitScope_Input, 1, &zero, sizeof(zero));
    }

    st = AudioUnitSetProperty(unit_, kAudioOutputUnitProperty_CurrentDevice, kAudioUnitScope_Global, 0, &device, sizeof(device));
    if (st != noErr) { error = "Cannot select CoreAudio device: " + osStatusText(st); return false; }
    device_ = device;

    inputChannels_ = std::min<std::uint32_t>(channelCount(device, kAudioObjectPropertyScopeInput), MixerEngine::kMaxHardwareChannels);
    outputChannels_ = std::min<std::uint32_t>(channelCount(device, kAudioObjectPropertyScopeOutput), MixerEngine::kMaxHardwareChannels);
    if (!outputChannels_) { error = "Selected device has no output channels."; return false; }

    Float64 rate = 48000.0; UInt32 size = sizeof(rate);
    AudioObjectPropertyAddress rateAddr = { kAudioDevicePropertyNominalSampleRate, kAudioObjectPropertyScopeGlobal, kAudioObjectPropertyElementMaster };
    if (AudioObjectGetPropertyData(device, &rateAddr, 0, nullptr, &size, &rate) == noErr) sampleRate_ = rate;
    UInt32 bf = 512; size = sizeof(bf);
    AudioObjectPropertyAddress bfAddr = { kAudioDevicePropertyBufferFrameSize, kAudioObjectPropertyScopeGlobal, kAudioObjectPropertyElementMaster };
    if (AudioObjectGetPropertyData(device, &bfAddr, 0, nullptr, &size, &bf) == noErr) bufferFrames_ = bf;

    UInt32 maxSlice = 4096;
    AudioUnitSetProperty(unit_, kAudioUnitProperty_MaximumFramesPerSlice, kAudioUnitScope_Global, 0, &maxSlice, sizeof(maxSlice));
    size = sizeof(maxSlice);
    if (AudioUnitGetProperty(unit_, kAudioUnitProperty_MaximumFramesPerSlice, kAudioUnitScope_Global, 0, &maxSlice, &size) == noErr) maxFrames_ = maxSlice;
    else maxFrames_ = 4096;

    AudioStreamBasicDescription outFmt = float64NonInterleaved(sampleRate_, outputChannels_);
    st = AudioUnitSetProperty(unit_, kAudioUnitProperty_StreamFormat, kAudioUnitScope_Input, 0, &outFmt, sizeof(outFmt));
    if (st != noErr) { error = "HAL rejected 64-bit output client format: " + osStatusText(st); return false; }

    if (inputChannels_ > 0) {
        AudioStreamBasicDescription inFmt = float64NonInterleaved(sampleRate_, inputChannels_);
        st = AudioUnitSetProperty(unit_, kAudioUnitProperty_StreamFormat, kAudioUnitScope_Output, 1, &inFmt, sizeof(inFmt));
        if (st != noErr) { error = "HAL rejected 64-bit input client format: " + osStatusText(st); return false; }
        if (!allocateInputABL(inputChannels_, maxFrames_, error)) return false;
    }

    AURenderCallbackStruct cb = {}; cb.inputProc = &CoreAudioDuplex::render; cb.inputProcRefCon = this;
    st = AudioUnitSetProperty(unit_, kAudioUnitProperty_SetRenderCallback, kAudioUnitScope_Input, 0, &cb, sizeof(cb));
    if (st != noErr) { error = "Cannot install CoreAudio callback: " + osStatusText(st); return false; }

    engine_.prepare(sampleRate_, maxFrames_);
    return true;
}

void CoreAudioDuplex::close() noexcept {
    if (unit_) { AudioOutputUnitStop(unit_); AudioUnitUninitialize(unit_); AudioComponentInstanceDispose(unit_); unit_ = nullptr; }
    inputABL_ = nullptr; inputABLStorage_.clear(); inputScratch_.clear(); device_ = kAudioObjectUnknown;
    inputChannels_ = outputChannels_ = 0;
}

OSStatus CoreAudioDuplex::render(void* refCon, AudioUnitRenderActionFlags* flags,
                                 const AudioTimeStamp* ts, UInt32, UInt32 frames, AudioBufferList* ioData) {
    auto* self = static_cast<CoreAudioDuplex*>(refCon);
    if (!self || !ioData || frames > self->maxFrames_) return noErr;

    if (self->inputChannels_ && self->inputABL_) {
        for (std::uint32_t ch = 0; ch < self->inputChannels_; ++ch) self->inputABL_->mBuffers[ch].mDataByteSize = frames * sizeof(double);
        const OSStatus st = AudioUnitRender(self->unit_, flags, ts, 1, frames, self->inputABL_);
        if (st != noErr) {
            for (std::uint32_t ch = 0; ch < self->inputChannels_; ++ch) {
                auto* p = static_cast<double*>(self->inputABL_->mBuffers[ch].mData); std::fill(p, p + frames, 0.0);
            }
        }
    }

    for (std::uint32_t ch = 0; ch < self->inputChannels_; ++ch) self->inputPtrs_[ch] = static_cast<const double*>(self->inputABL_->mBuffers[ch].mData);
    const std::uint32_t outCount = std::min<std::uint32_t>(ioData->mNumberBuffers, self->outputChannels_);
    for (std::uint32_t ch = 0; ch < outCount; ++ch) self->outputPtrs_[ch] = static_cast<double*>(ioData->mBuffers[ch].mData);
    for (std::uint32_t ch = outCount; ch < self->outputChannels_; ++ch) self->outputPtrs_[ch] = nullptr;

    self->engine_.process(self->inputChannels_ ? self->inputPtrs_.data() : nullptr, self->inputChannels_,
                          self->outputPtrs_.data(), outCount, frames);
    return noErr;
}

} // namespace caudio
