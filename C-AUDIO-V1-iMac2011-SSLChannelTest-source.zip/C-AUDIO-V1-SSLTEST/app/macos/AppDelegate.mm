#import "AppDelegate.h"
#import "CoreAudioDuplex.h"
#import "AudioFileLoader.h"
#import "../../engine/MixerEngine.h"

#import <Cocoa/Cocoa.h>

#include <array>
#include <cmath>
#include <memory>
#include <string>
#include <vector>

using namespace caudio;

@interface AppDelegate ()
@property(strong) NSWindow* window;
@property(strong) NSPopUpButton* devicePopup;
@property(strong) NSTextField* statusLabel;
@property(strong) NSTextField* masterMeter;
@property(strong) NSPopUpButton* masterType;
@property(strong) NSPopUpButton* masterOutA;
@property(strong) NSPopUpButton* masterOutB;
@end

@implementation AppDelegate {
    MixerEngine _engine;
    std::unique_ptr<CoreAudioDuplex> _audio;
    std::vector<AudioDeviceInfo> _devices;
    std::array<NSTextField*, MixerEngine::kTrackCount> _fileLabels{};
    std::array<NSPopUpButton*, MixerEngine::kTrackCount> _typePopups{};
    std::array<NSPopUpButton*, MixerEngine::kTrackCount> _sourcePopups{};
    std::array<NSPopUpButton*, MixerEngine::kTrackCount> _inputAPopups{};
    std::array<NSPopUpButton*, MixerEngine::kTrackCount> _inputBPopups{};
    NSTimer* _meterTimer;
}

- (NSTextField*)label:(NSString*)text frame:(NSRect)frame bold:(BOOL)bold {
    NSTextField* l = [[NSTextField alloc] initWithFrame:frame];
    l.stringValue = text; l.editable = NO; l.selectable = NO; l.bordered = NO; l.drawsBackground = NO;
    l.font = bold ? [NSFont boldSystemFontOfSize:12.0] : [NSFont systemFontOfSize:10.5]; return l;
}
- (NSButton*)button:(NSString*)text frame:(NSRect)frame action:(SEL)action {
    NSButton* b = [[NSButton alloc] initWithFrame:frame]; b.title = text; b.bezelStyle = NSBezelStyleRounded; b.target = self; b.action = action; return b;
}
- (NSButton*)toggle:(NSString*)text frame:(NSRect)frame action:(SEL)action tag:(NSInteger)tag {
    NSButton* b = [self button:text frame:frame action:action]; b.buttonType = NSPushOnPushOffButton; b.tag = tag; return b;
}
- (NSPopUpButton*)popup:(NSRect)frame action:(SEL)action tag:(NSInteger)tag {
    NSPopUpButton* p = [[NSPopUpButton alloc] initWithFrame:frame pullsDown:NO]; p.target = self; p.action = action; p.tag = tag; return p;
}

- (void)applicationDidFinishLaunching:(NSNotification*)n {
    (void)n; _audio.reset(new CoreAudioDuplex(_engine));
    self.window = [[NSWindow alloc] initWithContentRect:NSMakeRect(30, 30, 1510, 770)
                                               styleMask:(NSWindowStyleMaskTitled|NSWindowStyleMaskClosable|NSWindowStyleMaskMiniaturizable|NSWindowStyleMaskResizable)
                                                 backing:NSBackingStoreBuffered defer:NO];
    self.window.title = @"C-AUDIO V1 SSL Channel Test — iMac 2011";
    [self.window makeKeyAndOrderFront:nil];
    NSView* v = self.window.contentView;

    [v addSubview:[self label:@"C-AUDIO V1  |  6 x SSL 4000 E LINE CHANNEL  |  CoreAudio  |  NO JUCE" frame:NSMakeRect(18, 726, 760, 24) bold:YES]];
    self.devicePopup = [self popup:NSMakeRect(18, 686, 360, 28) action:@selector(deviceChanged:) tag:0]; [v addSubview:self.devicePopup];
    [v addSubview:[self button:@"PLAY" frame:NSMakeRect(392, 686, 76, 28) action:@selector(play:)]];
    [v addSubview:[self button:@"STOP" frame:NSMakeRect(474, 686, 76, 28) action:@selector(stop:)]];
    [v addSubview:[self button:@"RECORD" frame:NSMakeRect(556, 686, 92, 28) action:@selector(record:)]];
    self.statusLabel = [self label:@"Opening CoreAudio..." frame:NSMakeRect(665, 686, 820, 28) bold:NO]; [v addSubview:self.statusLabel];

    const CGFloat stripW = 190.0, gap = 7.0, startX = 18.0;
    for (NSUInteger i = 0; i < MixerEngine::kTrackCount; ++i) {
        const CGFloat x = startX + i * (stripW + gap);
        NSBox* box = [[NSBox alloc] initWithFrame:NSMakeRect(x, 55, stripW, 615)]; box.title = [NSString stringWithFormat:@"SSL CH %lu", (unsigned long)(i+1)]; [v addSubview:box];
        NSView* c = box.contentView;

        [c addSubview:[self label:@"TRACK" frame:NSMakeRect(8, 550, 45, 18) bold:NO]];
        _typePopups[i] = [self popup:NSMakeRect(54, 545, 125, 25) action:@selector(typeChanged:) tag:(NSInteger)i];
        [_typePopups[i] addItemsWithTitles:@[@"MONO", @"STEREO"]]; [c addSubview:_typePopups[i]];

        [c addSubview:[self label:@"SOURCE" frame:NSMakeRect(8, 516, 48, 18) bold:NO]];
        _sourcePopups[i] = [self popup:NSMakeRect(54, 511, 125, 25) action:@selector(sourceChanged:) tag:(NSInteger)i];
        [_sourcePopups[i] addItemsWithTitles:@[@"FILE", @"INPUT"]]; [c addSubview:_sourcePopups[i]];

        [c addSubview:[self label:@"IN A" frame:NSMakeRect(8, 482, 42, 18) bold:NO]];
        _inputAPopups[i] = [self popup:NSMakeRect(54, 477, 125, 25) action:@selector(inputAChanged:) tag:(NSInteger)i]; [c addSubview:_inputAPopups[i]];
        [c addSubview:[self label:@"IN B" frame:NSMakeRect(8, 450, 42, 18) bold:NO]];
        _inputBPopups[i] = [self popup:NSMakeRect(54, 445, 125, 25) action:@selector(inputBChanged:) tag:(NSInteger)i]; _inputBPopups[i].enabled=NO; [c addSubview:_inputBPopups[i]];

        NSButton* imp = [self button:@"IMPORT AUDIO" frame:NSMakeRect(8, 408, 171, 27) action:@selector(importAudio:)]; imp.tag = (NSInteger)i; [c addSubview:imp];
        _fileLabels[i] = [self label:@"empty" frame:NSMakeRect(8, 383, 171, 20) bold:NO]; _fileLabels[i].lineBreakMode = NSLineBreakByTruncatingMiddle; [c addSubview:_fileLabels[i]];

        [c addSubview:[self toggle:@"ARM" frame:NSMakeRect(8, 344, 52, 27) action:@selector(armChanged:) tag:(NSInteger)i]];
        NSButton* mon = [self toggle:@"MON" frame:NSMakeRect(64, 344, 52, 27) action:@selector(monitorChanged:) tag:(NSInteger)i]; mon.state = NSControlStateValueOn; [c addSubview:mon];
        [c addSubview:[self toggle:@"MUTE" frame:NSMakeRect(8, 312, 75, 27) action:@selector(muteChanged:) tag:(NSInteger)i]];
        [c addSubview:[self toggle:@"SOLO" frame:NSMakeRect(104, 312, 75, 27) action:@selector(soloChanged:) tag:(NSInteger)i]];

        [c addSubview:[self label:@"SSL LINE TRIM  -20 .. +20 dB" frame:NSMakeRect(8, 278, 171, 18) bold:NO]];
        NSSlider* trim = [[NSSlider alloc] initWithFrame:NSMakeRect(8, 253, 171, 22)]; trim.minValue=-20; trim.maxValue=20; trim.doubleValue=0; trim.tag=(NSInteger)i; trim.target=self; trim.action=@selector(trimChanged:); [c addSubview:trim];

        [c addSubview:[self label:@"VCA FADER  -∞ .. +10 dB" frame:NSMakeRect(8, 219, 171, 18) bold:NO]];
        NSSlider* f = [[NSSlider alloc] initWithFrame:NSMakeRect(8, 194, 171, 22)]; f.minValue=-60; f.maxValue=10; f.doubleValue=0; f.tag=(NSInteger)i; f.target=self; f.action=@selector(faderChanged:); [c addSubview:f];

        [c addSubview:[self label:@"PAN / STEREO BALANCE" frame:NSMakeRect(8, 160, 171, 18) bold:NO]];
        NSSlider* p = [[NSSlider alloc] initWithFrame:NSMakeRect(8, 135, 171, 22)]; p.minValue=-1; p.maxValue=1; p.doubleValue=0; p.tag=(NSInteger)i; p.target=self; p.action=@selector(panChanged:); [c addSubview:p];

        NSTextField* note = [self label:@"82E149 line/input-select/fader-select\ndbx 202 gold-can VCA model\n5534 stage limits + odd/even pan buffers\nEQ: OFF   DYNAMICS: OFF" frame:NSMakeRect(8, 48, 171, 76) bold:NO]; note.font=[NSFont systemFontOfSize:9.5]; [c addSubview:note];
    }

    NSBox* m = [[NSBox alloc] initWithFrame:NSMakeRect(1200, 55, 290, 615)]; m.title=@"MASTER / HARDWARE OUT"; [v addSubview:m]; NSView* mc=m.contentView;
    [mc addSubview:[self label:@"Master sums the six channel outputs in 64-bit.\nNo SSL mix-bus/output colouring in this CHANNEL test." frame:NSMakeRect(10, 515, 270, 46) bold:NO]];
    [mc addSubview:[self label:@"OUTPUT TYPE" frame:NSMakeRect(10, 476, 95, 18) bold:NO]];
    self.masterType=[self popup:NSMakeRect(112, 471, 160, 25) action:@selector(masterTypeChanged:) tag:0]; [self.masterType addItemsWithTitles:@[@"STEREO",@"MONO"]]; [mc addSubview:self.masterType];
    [mc addSubview:[self label:@"OUT A / LEFT" frame:NSMakeRect(10, 438, 95, 18) bold:NO]];
    self.masterOutA=[self popup:NSMakeRect(112, 433, 160, 25) action:@selector(masterOutChanged:) tag:0]; [mc addSubview:self.masterOutA];
    [mc addSubview:[self label:@"OUT B / RIGHT" frame:NSMakeRect(10, 402, 95, 18) bold:NO]];
    self.masterOutB=[self popup:NSMakeRect(112, 397, 160, 25) action:@selector(masterOutChanged:) tag:1]; [mc addSubview:self.masterOutB];
    [mc addSubview:[self label:@"MASTER LEVEL" frame:NSMakeRect(10, 352, 260, 18) bold:NO]];
    NSSlider* mf=[[NSSlider alloc] initWithFrame:NSMakeRect(10, 323, 260, 24)]; mf.minValue=-60; mf.maxValue=10; mf.doubleValue=0; mf.target=self; mf.action=@selector(masterChanged:); [mc addSubview:mf];
    self.masterMeter=[self label:@"L -∞   R -∞" frame:NSMakeRect(10, 278, 260, 28) bold:YES]; [mc addSubview:self.masterMeter];
    [mc addSubview:[self label:@"Recording stores the selected hardware input dry\nwhile MON lets you hear it through the SSL channel.\nFloat32 WAV, one file per armed channel." frame:NSMakeRect(10, 190, 270, 70) bold:NO]];

    [self refreshDevices]; [self openSelectedDevice];
    _meterTimer=[NSTimer scheduledTimerWithTimeInterval:0.05 target:self selector:@selector(updateMeters:) userInfo:nil repeats:YES];
}

- (BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication*)s { (void)s; return YES; }
- (void)applicationWillTerminate:(NSNotification*)n { (void)n; [_meterTimer invalidate]; _engine.stopRecording(); if(_audio) _audio->close(); }

- (void)refreshDevices {
    _devices=CoreAudioDuplex::devices(); [self.devicePopup removeAllItems]; AudioDeviceID def=CoreAudioDuplex::defaultOutputDevice(); NSInteger sel=0;
    for(NSUInteger i=0;i<_devices.size();++i){ NSString* t=[NSString stringWithFormat:@"%s  [%u in / %u out]",_devices[i].name.c_str(),_devices[i].inputChannels,_devices[i].outputChannels]; [self.devicePopup addItemWithTitle:t]; if(_devices[i].id==def) sel=(NSInteger)i; }
    if(!_devices.empty()) [self.devicePopup selectItemAtIndex:sel];
}
- (void)rebuildIOPopups {
    const NSUInteger ins=_audio?(NSUInteger)_audio->inputChannels():0, outs=_audio?(NSUInteger)_audio->outputChannels():0;
    for(NSUInteger t=0;t<MixerEngine::kTrackCount;++t){ [_inputAPopups[t] removeAllItems]; [_inputBPopups[t] removeAllItems]; for(NSUInteger i=0;i<ins;++i){ NSString* s=[NSString stringWithFormat:@"Input %lu",(unsigned long)(i+1)]; [_inputAPopups[t] addItemWithTitle:s]; [_inputBPopups[t] addItemWithTitle:s]; } if(ins){ [_inputAPopups[t] selectItemAtIndex:MIN(t,ins-1)]; [_inputBPopups[t] selectItemAtIndex:MIN(t+1,ins-1)]; _engine.track(t).inputA.store((int)_inputAPopups[t].indexOfSelectedItem); _engine.track(t).inputB.store((int)_inputBPopups[t].indexOfSelectedItem); } }
    [self.masterOutA removeAllItems]; [self.masterOutB removeAllItems]; for(NSUInteger i=0;i<outs;++i){ NSString* s=[NSString stringWithFormat:@"Output %lu",(unsigned long)(i+1)]; [self.masterOutA addItemWithTitle:s]; [self.masterOutB addItemWithTitle:s]; }
    if(outs){ [self.masterOutA selectItemAtIndex:0]; [self.masterOutB selectItemAtIndex:MIN((NSUInteger)1,outs-1)]; _engine.setOutputA(0); _engine.setOutputB((int)MIN((NSUInteger)1,outs-1)); }
}
- (void)openSelectedDevice {
    NSInteger idx=self.devicePopup.indexOfSelectedItem; if(idx<0||(NSUInteger)idx>=_devices.size()){self.statusLabel.stringValue=@"No CoreAudio device";return;}
    std::string err; if(_audio->open(_devices[(NSUInteger)idx].id,err)){ self.statusLabel.stringValue=[NSString stringWithFormat:@"%.0f Hz | %u frames | %u inputs | %u outputs | 64-bit engine",_audio->sampleRate(),_audio->bufferFrames(),_audio->inputChannels(),_audio->outputChannels()]; [self rebuildIOPopups]; }
    else self.statusLabel.stringValue=[NSString stringWithUTF8String:err.c_str()];
}
- (void)deviceChanged:(id)s { (void)s; _engine.stopRecording(); _engine.stop(); _audio->close(); [self openSelectedDevice]; }
- (void)play:(id)s { (void)s; _engine.play(); }
- (void)stop:(id)s { (void)s; _engine.stopRecording(); _engine.stop(); self.statusLabel.stringValue=[NSString stringWithFormat:@"Stopped | dropped record frames: %llu",(unsigned long long)_engine.droppedRecordFrames()]; }
- (void)record:(id)s { (void)s; if(!_audio||!_audio->inputChannels()){self.statusLabel.stringValue=@"Selected device has no CoreAudio inputs.";return;} NSOpenPanel* p=[NSOpenPanel openPanel]; p.canChooseFiles=NO; p.canChooseDirectories=YES; p.canCreateDirectories=YES; p.allowsMultipleSelection=NO; p.prompt=@"Record Here"; if([p runModal]!=NSModalResponseOK)return; std::string err; if(!_engine.startRecording(p.URL.path.UTF8String,err)){NSAlert*a=[[NSAlert alloc]init];a.messageText=@"Record failed";a.informativeText=[NSString stringWithUTF8String:err.c_str()];[a runModal];return;} self.statusLabel.stringValue=@"RECORDING — dry hardware inputs to WAV; monitoring through SSL channels"; }

- (void)typeChanged:(NSPopUpButton*)s { auto& t=_engine.track((size_t)s.tag); t.format.store(s.indexOfSelectedItem==1?(int)TrackFormat::Stereo:(int)TrackFormat::Mono); _inputBPopups[(size_t)s.tag].enabled=(s.indexOfSelectedItem==1); }
- (void)sourceChanged:(NSPopUpButton*)s { _engine.track((size_t)s.tag).source.store(s.indexOfSelectedItem==1?(int)TrackSource::HardwareInput:(int)TrackSource::File); }
- (void)inputAChanged:(NSPopUpButton*)s { _engine.track((size_t)s.tag).inputA.store((int)s.indexOfSelectedItem); }
- (void)inputBChanged:(NSPopUpButton*)s { _engine.track((size_t)s.tag).inputB.store((int)s.indexOfSelectedItem); }
- (void)armChanged:(NSButton*)s { _engine.track((size_t)s.tag).recordArm.store(s.state==NSControlStateValueOn); }
- (void)monitorChanged:(NSButton*)s { _engine.track((size_t)s.tag).inputMonitor.store(s.state==NSControlStateValueOn); }
- (void)muteChanged:(NSButton*)s { _engine.track((size_t)s.tag).mute.store(s.state==NSControlStateValueOn); }
- (void)soloChanged:(NSButton*)s { _engine.track((size_t)s.tag).solo.store(s.state==NSControlStateValueOn); }
- (void)trimChanged:(NSSlider*)s { _engine.track((size_t)s.tag).inputTrimDb.store(s.doubleValue); }
- (void)faderChanged:(NSSlider*)s { _engine.track((size_t)s.tag).faderDb.store(s.doubleValue); }
- (void)panChanged:(NSSlider*)s { _engine.track((size_t)s.tag).pan.store(s.doubleValue); }
- (void)masterChanged:(NSSlider*)s { _engine.setMasterDb(s.doubleValue); }
- (void)masterTypeChanged:(NSPopUpButton*)s { const bool mono=s.indexOfSelectedItem==1; _engine.setOutputFormat(mono?OutputFormat::Mono:OutputFormat::Stereo); self.masterOutB.enabled=!mono; }
- (void)masterOutChanged:(NSPopUpButton*)s { if(s.tag==0)_engine.setOutputA((int)s.indexOfSelectedItem);else _engine.setOutputB((int)s.indexOfSelectedItem); }

- (void)importAudio:(NSButton*)s {
    _engine.stopRecording(); _engine.stop(); NSOpenPanel*p=[NSOpenPanel openPanel];p.canChooseDirectories=NO;p.allowsMultipleSelection=NO;p.allowedFileTypes=@[@"wav",@"aif",@"aiff",@"caf"];
    if([p runModal]!=NSModalResponseOK)return; AudioClip clip;std::string err;if(!AudioFileLoader::load(p.URL.path.UTF8String,_engine.sampleRate(),clip,err)){NSAlert*a=[[NSAlert alloc]init];a.messageText=@"Import failed";a.informativeText=[NSString stringWithUTF8String:err.c_str()];[a runModal];return;}
    const size_t i=(size_t)s.tag; NSString*name=[NSString stringWithUTF8String:clip.name.c_str()]; const bool st=clip.stereo; if(_engine.setClip(i,std::move(clip))){_fileLabels[i].stringValue=name;[_typePopups[i] selectItemAtIndex:st?1:0];[_sourcePopups[i] selectItemAtIndex:0];_engine.track(i).format.store(st?(int)TrackFormat::Stereo:(int)TrackFormat::Mono);_engine.track(i).source.store((int)TrackSource::File);_inputBPopups[i].enabled=st;}
}

- (void)updateMeters:(NSTimer*)t { (void)t; auto db=[](double p){return p>1e-12?20.0*std::log10(p):-120.0;}; self.masterMeter.stringValue=[NSString stringWithFormat:@"L %.1f dBFS   R %.1f dBFS",db(_engine.peakLeft()),db(_engine.peakRight())]; if(_engine.isRecording()&&_engine.droppedRecordFrames()>0) self.statusLabel.stringValue=[NSString stringWithFormat:@"RECORDING — WARNING: %llu dropped frames",(unsigned long long)_engine.droppedRecordFrames()]; }
@end
