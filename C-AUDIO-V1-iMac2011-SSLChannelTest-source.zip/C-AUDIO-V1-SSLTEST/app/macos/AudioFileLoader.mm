#include "AudioFileLoader.h"

#import <AudioToolbox/AudioToolbox.h>
#import <Foundation/Foundation.h>

#include <algorithm>
#include <cmath>
#include <memory>
#include <cstdio>
#include <cctype>

namespace caudio {
namespace {
std::string osStatusText(OSStatus status) {
    char text[32] = {};
    const UInt32 be = CFSwapInt32HostToBig(static_cast<UInt32>(status));
    if (isprint((be >> 24) & 0xff) && isprint((be >> 16) & 0xff) &&
        isprint((be >> 8) & 0xff) && isprint(be & 0xff)) {
        std::snprintf(text, sizeof(text), "'%c%c%c%c'", (be >> 24) & 0xff,
                      (be >> 16) & 0xff, (be >> 8) & 0xff, be & 0xff);
    } else {
        std::snprintf(text, sizeof(text), "%d", static_cast<int>(status));
    }
    return text;
}
}

bool AudioFileLoader::load(const std::string& path, double targetSampleRate, AudioClip& out, std::string& error) {
    @autoreleasepool {
        NSURL* url = [NSURL fileURLWithPath:[NSString stringWithUTF8String:path.c_str()]];
        ExtAudioFileRef file = nullptr;
        OSStatus st = ExtAudioFileOpenURL((__bridge CFURLRef)url, &file);
        if (st != noErr || !file) {
            error = "ExtAudioFileOpenURL failed: " + osStatusText(st);
            return false;
        }

        AudioStreamBasicDescription source = {};
        UInt32 size = sizeof(source);
        st = ExtAudioFileGetProperty(file, kExtAudioFileProperty_FileDataFormat, &size, &source);
        if (st != noErr || source.mChannelsPerFrame == 0) {
            error = "Cannot read source audio format";
            ExtAudioFileDispose(file);
            return false;
        }

        SInt64 sourceFrames = 0;
        size = sizeof(sourceFrames);
        ExtAudioFileGetProperty(file, kExtAudioFileProperty_FileLengthFrames, &size, &sourceFrames);

        const UInt32 channels = std::min<UInt32>(source.mChannelsPerFrame, 2);
        AudioStreamBasicDescription client = {};
        client.mSampleRate = targetSampleRate;
        client.mFormatID = kAudioFormatLinearPCM;
        client.mFormatFlags = kAudioFormatFlagIsFloat | kAudioFormatFlagsNativeEndian | kAudioFormatFlagIsNonInterleaved;
        client.mBytesPerPacket = sizeof(double);
        client.mFramesPerPacket = 1;
        client.mBytesPerFrame = sizeof(double);
        client.mChannelsPerFrame = channels;
        client.mBitsPerChannel = 64;

        st = ExtAudioFileSetProperty(file, kExtAudioFileProperty_ClientDataFormat, sizeof(client), &client);
        if (st != noErr) {
            error = "Audio converter setup failed: " + osStatusText(st);
            ExtAudioFileDispose(file);
            return false;
        }

        const double ratio = targetSampleRate / source.mSampleRate;
        const std::size_t reserveFrames = static_cast<std::size_t>(std::ceil(sourceFrames * ratio)) + 4096;
        out = AudioClip{};
        out.left.reserve(reserveFrames);
        out.right.reserve(reserveFrames);
        out.stereo = (channels == 2);
        out.sourcePath = path;
        out.name = [[[url lastPathComponent] stringByDeletingPathExtension] UTF8String];

        constexpr UInt32 chunk = 4096;
        std::vector<double> left(chunk), right(chunk);
        while (true) {
            AudioBufferList abl = {};
            abl.mNumberBuffers = channels;
            abl.mBuffers[0].mNumberChannels = 1;
            abl.mBuffers[0].mDataByteSize = chunk * sizeof(double);
            abl.mBuffers[0].mData = left.data();
            // AudioBufferList has one inline buffer in its C declaration. Allocate
            // a larger object for stereo so accessing buffer[1] is valid.
            if (channels == 2) break;

            UInt32 frames = chunk;
            st = ExtAudioFileRead(file, &frames, &abl);
            if (st != noErr) { error = "Audio read failed: " + osStatusText(st); ExtAudioFileDispose(file); return false; }
            if (frames == 0) break;
            out.left.insert(out.left.end(), left.begin(), left.begin() + frames);
            out.right.insert(out.right.end(), left.begin(), left.begin() + frames);
        }

        if (channels == 2) {
            const std::size_t ablBytes = offsetof(AudioBufferList, mBuffers) + 2 * sizeof(AudioBuffer);
            std::vector<unsigned char> ablStorage(ablBytes, 0);
            auto* stereo = reinterpret_cast<AudioBufferList*>(ablStorage.data());
            stereo->mNumberBuffers = 2;
            stereo->mBuffers[0].mNumberChannels = 1;
            stereo->mBuffers[0].mDataByteSize = chunk * sizeof(double);
            stereo->mBuffers[0].mData = left.data();
            stereo->mBuffers[1].mNumberChannels = 1;
            stereo->mBuffers[1].mDataByteSize = chunk * sizeof(double);
            stereo->mBuffers[1].mData = right.data();
            while (true) {
                UInt32 frames = chunk;
                st = ExtAudioFileRead(file, &frames, stereo);
                if (st != noErr) { error = "Audio read failed: " + osStatusText(st); ExtAudioFileDispose(file); return false; }
                if (frames == 0) break;
                out.left.insert(out.left.end(), left.begin(), left.begin() + frames);
                out.right.insert(out.right.end(), right.begin(), right.begin() + frames);
            }
        }

        ExtAudioFileDispose(file);
        return !out.left.empty();
    }
}

} // namespace caudio
