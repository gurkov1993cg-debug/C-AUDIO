#pragma once

#include "../../engine/MixerEngine.h"
#include <string>

namespace caudio {
class AudioFileLoader {
public:
    static bool load(const std::string& path, double targetSampleRate, AudioClip& out, std::string& error);
};
}
