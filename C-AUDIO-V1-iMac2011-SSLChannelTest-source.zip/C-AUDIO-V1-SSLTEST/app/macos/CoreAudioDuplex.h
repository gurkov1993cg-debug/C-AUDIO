#pragma once

#include "../../engine/MixerEngine.h"

#import <CoreAudio/CoreAudio.h>
#import <AudioUnit/AudioUnit.h>

#include <array>
#include <cstdint>
#include <string>
#include <vector>

namespace caudio {

struct AudioDeviceInfo {
    AudioDeviceID id = kAudioObjectUnknown;
    std::string name;
    std::uint32_t inputChannels = 0;
    std::uint32_t outputChannels = 0;
};

class CoreAudioDuplex {
public:
    explicit CoreAudioDuplex(MixerEngine& engine) : engine_(engine) {}
    ~CoreAudioDuplex();

    static std::vector<AudioDeviceInfo> devices();
    static AudioDeviceID defaultOutputDevice();

    bool open(AudioDeviceID device, std::string& error);
    void close() noexcept;

    double sampleRate() const noexcept { return sampleRate_; }
    std::uint32_t inputChannels() const noexcept { return inputChannels_; }
    std::uint32_t outputChannels() const noexcept { return outputChannels_; }
    std::uint32_t bufferFrames() const noexcept { return bufferFrames_; }
    AudioDeviceID device() const noexcept { return device_; }

private:
    static OSStatus render(void* refCon, AudioUnitRenderActionFlags* flags,
                           const AudioTimeStamp* timeStamp, UInt32 bus,
                           UInt32 frames, AudioBufferList* ioData);
    bool configure(AudioDeviceID device, std::string& error);
    bool allocateInputABL(std::uint32_t channels, std::uint32_t maxFrames, std::string& error);

    MixerEngine& engine_;
    AudioUnit unit_ = nullptr;
    AudioDeviceID device_ = kAudioObjectUnknown;
    double sampleRate_ = 48000.0;
    std::uint32_t inputChannels_ = 0;
    std::uint32_t outputChannels_ = 0;
    std::uint32_t bufferFrames_ = 512;
    std::uint32_t maxFrames_ = 4096;

    std::vector<unsigned char> inputABLStorage_;
    AudioBufferList* inputABL_ = nullptr;
    std::vector<double> inputScratch_;
    std::array<const double*, MixerEngine::kMaxHardwareChannels> inputPtrs_{};
    std::array<double*, MixerEngine::kMaxHardwareChannels> outputPtrs_{};
};

} // namespace caudio
