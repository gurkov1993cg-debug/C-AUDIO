#pragma once

#include <atomic>
#include <cstdint>

namespace caudio {

// Circuit-informed SSL 4000 E line-channel model.
// Scope of this V1 test: 82E149 line path + channel-fader VCA path + routing pan buffers.
// Intentionally EXCLUDES EQ (82E02/82E242), dynamics (82E10) and mix/output amplifiers.
class SSLChannel {
public:
    void prepare(double sampleRate, std::uint64_t noiseSeed) noexcept;
    void reset() noexcept;

    void setInputTrimDb(double db) noexcept; // 82E149 LINE TRIM: -20 .. +20 dB
    void setFaderDb(double db) noexcept;     // console VCA fader: -inf .. +10 dB
    void setPan(double pan) noexcept;        // -1 L .. +1 R

    // One real mono console channel feeding the odd/even stereo routing pan buffers.
    void process(double input, double& outL, double& outR) noexcept;

    static double panGainLeft(double pan) noexcept;
    static double panGainRight(double pan) noexcept;

private:
    struct OnePoleHP {
        double b0 = 1.0, b1 = -1.0, a1 = 0.0;
        double x1 = 0.0, y1 = 0.0;
        void prepare(double fs, double rOhm, double cFarad) noexcept;
        void reset() noexcept { x1 = 0.0; y1 = 0.0; }
        double process(double x) noexcept;
    };

    struct OnePoleLP {
        double b0 = 1.0, b1 = 1.0, a1 = 0.0;
        double x1 = 0.0, y1 = 0.0;
        void prepareHz(double fs, double cutoffHz) noexcept;
        void reset() noexcept { x1 = 0.0; y1 = 0.0; }
        double process(double x) noexcept;
    };

    // Bounded large-signal model for the compensated NE5534 stages used on 82E149.
    // Small-signal shaping is derived from the visible RC feedback networks where present;
    // the active device model contributes slew/output-swing limits, not arbitrary saturation.
    struct NE5534Stage {
        OnePoleLP closedLoopPole;
        double fs = 48000.0;
        double prev = 0.0;
        double slewVPerSample = 1.0;
        double swingV = 15.0;
        void prepare(double sampleRate, double feedbackR, double feedbackC) noexcept;
        void prepareWideband(double sampleRate) noexcept;
        void reset() noexcept { closedLoopPole.reset(); prev = 0.0; }
        double process(double volts) noexcept;
    };

    // dbx 202C "gold can" VCA model. Control law is exact in dB (-50 mV/dB family),
    // while the audio non-linearity is constrained to published 202C THD/current data.
    // No generic tanh/console saturator is used.
    struct DBX202C {
        double fs = 48000.0;
        double envVolts = 1.0e-6;
        double noiseRmsVolts = 7.5e-6; // 3e-10 A * ~25k network, published noise-current scale
        std::uint64_t rng = 1;
        void prepare(double sampleRate, std::uint64_t seed) noexcept;
        void reset() noexcept { envVolts = 1.0e-6; }
        double process(double inVolts, double gainDb) noexcept;
    private:
        double whiteNoise() noexcept;
    };

    struct Path {
        OnePoleHP lineCoupling;       // 2u2 / 30k1 on Channel Line Input
        NE5534Stage lineAmp;          // T5/T6/T7 aggregate active line stage
        OnePoleHP inputSelectCoupling;// 10u / 10k around Channel Input Select
        NE5534Stage inputSelectAmp;   // T8
        OnePoleHP faderCoupling;      // 100u / 4k7 into Channel Fader Select
        DBX202C vca;                  // large-fader dbx 202 gold-can family behaviour
        NE5534Stage faderAmp;         // T10, 4k7 // 100pF
        OnePoleHP panInputCoupling;   // 10u / 24k9
        NE5534Stage panAmp;           // T11/T12, 24k9 // 33pF
        OnePoleHP panOutputCoupling;  // 100u / 4k7 output load path

        void prepare(double fs, std::uint64_t seed) noexcept;
        void reset() noexcept;
        double prePan(double digitalInput, double trimDb, double faderDb) noexcept;
        double postPan(double volts, bool odd) noexcept;
    } pathOdd_, pathEven_;

    static double dbToGain(double db) noexcept;
    static double clamp(double x, double lo, double hi) noexcept;
    static double digitalToVolts(double x) noexcept;
    static double voltsToDigital(double v) noexcept;
    double smoothedFaderDb() noexcept;
    double smoothedTrimDb() noexcept;
    double smoothedPan() noexcept;

    std::atomic<double> targetTrimDb_{0.0};
    std::atomic<double> targetFaderDb_{0.0};
    std::atomic<double> targetPan_{0.0};
    double trimDb_ = 0.0;
    double faderDb_ = 0.0;
    double pan_ = 0.0;
    double controlSlew_ = 0.0;
};

} // namespace caudio
