#include "SSLChannel.h"

#include <algorithm>
#include <cmath>

namespace caudio {
namespace {
constexpr double kPi = 3.14159265358979323846264338327950288;
constexpr double kSqrt2 = 1.4142135623730950488;
// +24 dBu = 12.283 Vrms. Treat digital full-scale sine as +24 dBu analogue reference.
constexpr double kFullScalePeakVolts = 0.775 * std::pow(10.0, 24.0 / 20.0) * kSqrt2;
constexpr double kPanExponent = 1.494867642699313; // -4.5 dB at centre
}

double SSLChannel::clamp(double x, double lo, double hi) noexcept {
    return std::max(lo, std::min(hi, x));
}

double SSLChannel::dbToGain(double db) noexcept {
    if (db <= -119.0) return 0.0;
    return std::pow(10.0, db / 20.0);
}

double SSLChannel::digitalToVolts(double x) noexcept { return x * kFullScalePeakVolts; }
double SSLChannel::voltsToDigital(double v) noexcept { return v / kFullScalePeakVolts; }

void SSLChannel::OnePoleHP::prepare(double fs, double rOhm, double cFarad) noexcept {
    const double fc = 1.0 / (2.0 * kPi * rOhm * cFarad);
    const double k = std::tan(kPi * fc / fs);
    const double norm = 1.0 / (1.0 + k);
    b0 = norm;
    b1 = -norm;
    a1 = (k - 1.0) * norm;
    reset();
}

double SSLChannel::OnePoleHP::process(double x) noexcept {
    const double y = b0 * x + b1 * x1 - a1 * y1;
    x1 = x; y1 = y;
    return y;
}

void SSLChannel::OnePoleLP::prepareHz(double fs, double cutoffHz) noexcept {
    const double k = std::tan(kPi * cutoffHz / fs);
    const double norm = 1.0 / (1.0 + k);
    b0 = k * norm;
    b1 = b0;
    a1 = (k - 1.0) * norm;
    reset();
}

double SSLChannel::OnePoleLP::process(double x) noexcept {
    const double y = b0 * x + b1 * x1 - a1 * y1;
    x1 = x; y1 = y;
    return y;
}

void SSLChannel::NE5534Stage::prepare(double sampleRate, double feedbackR, double feedbackC) noexcept {
    fs = sampleRate;
    const double rcPole = 1.0 / (2.0 * kPi * feedbackR * feedbackC);
    // 82E149's RC feedback poles are below the op-amp GBW and dominate the intended stage response.
    closedLoopPole.prepareHz(fs, std::min(rcPole, fs * 0.45));
    // 22 pF compensated 5534 implementations are conservatively bounded near 6 V/us.
    slewVPerSample = 6.0e6 / fs;
    swingV = 15.0; // bounded below +/-18 V rails; only reached at extreme console drive.
    prev = 0.0;
}

void SSLChannel::NE5534Stage::prepareWideband(double sampleRate) noexcept {
    fs = sampleRate;
    closedLoopPole.prepareHz(fs, std::min(500000.0, fs * 0.45));
    slewVPerSample = 6.0e6 / fs;
    swingV = 15.0;
    prev = 0.0;
}

double SSLChannel::NE5534Stage::process(double volts) noexcept {
    double y = closedLoopPole.process(volts);
    const double delta = clamp(y - prev, -slewVPerSample, slewVPerSample);
    y = prev + delta;
    // Hard electrical headroom boundary. This is not a creative saturator; normal SSL levels remain far below it.
    y = clamp(y, -swingV, swingV);
    prev = y;
    return y;
}

void SSLChannel::DBX202C::prepare(double sampleRate, std::uint64_t seed) noexcept {
    fs = sampleRate;
    rng = seed ? seed : 1;
    reset();
}

double SSLChannel::DBX202C::whiteNoise() noexcept {
    // xorshift64*, deterministic per channel and allocation-free.
    rng ^= rng >> 12; rng ^= rng << 25; rng ^= rng >> 27;
    const std::uint64_t z = rng * 2685821657736338717ULL;
    const double u = static_cast<double>((z >> 11) & 0x1fffffffffffffULL) / 9007199254740992.0;
    return (u * 2.0 - 1.0) * 1.7320508075688772; // approximately unit-RMS uniform noise
}

double SSLChannel::DBX202C::process(double inVolts, double gainDb) noexcept {
    const double g = SSLChannel::dbToGain(gainDb);
    const double linearOut = inVolts * g;

    // Estimate VCA signal current from the ~25k recommended 202C audio network.
    const double iSum = std::abs(inVolts / 24900.0) + std::abs(linearOut / 24900.0);
    const double currentUa = std::max(0.1, iSum * 1.0e6);

    // Published 202C data: ~0.01% THD at 10 uA and ~0.03% at 100 uA.
    // Interpolate in log-current. Above the published range, rise smoothly but remain bounded.
    double t = (std::log10(currentUa) - 1.0); // 10uA -> 0, 100uA -> 1
    t = SSLChannel::clamp(t, 0.0, 1.0);
    double thd = 0.00010 + t * 0.00020;
    if (currentUa > 100.0) {
        thd *= 1.0 + 0.35 * std::log10(currentUa / 100.0 + 1.0);
    }

    // Gain/attenuation stresses both input and output currents; the polynomial naturally creates IM products.
    const double attack = std::exp(-1.0 / (0.001 * fs));
    const double release = std::exp(-1.0 / (0.080 * fs));
    const double a = std::abs(linearOut);
    envVolts = (a > envVolts) ? (a + attack * (envVolts - a)) : (a + release * (envVolts - a));
    const double peak = std::max(envVolts, 1.0e-5);
    const double xn = SSLChannel::clamp(linearOut / peak, -1.0, 1.0);

    // Chebyshev T3 adds a controlled third-harmonic residual for a sine; because the function is nonlinear,
    // multitone material also creates the intermodulation expected from a real VCA. No tanh is used.
    const double t3 = 4.0 * xn * xn * xn - 3.0 * xn;
    double y = linearOut + (thd * peak * t3);

    // Published VCA noise-current scale, converted to a very low voltage residual.
    y += noiseRmsVolts * whiteNoise();
    return y;
}

void SSLChannel::Path::prepare(double fs, std::uint64_t seed) noexcept {
    // 82E149 component values visible on the original drawing.
    lineCoupling.prepare(fs, 30100.0, 2.2e-6);
    lineAmp.prepareWideband(fs); // T5/T6/T7, 22pF compensated 5534 family
    inputSelectCoupling.prepare(fs, 10000.0, 10.0e-6);
    inputSelectAmp.prepare(fs, 100000.0, 100.0e-12); // T8, R68/C42
    faderCoupling.prepare(fs, 4700.0, 100.0e-6);     // C51 / R79-R80 scale
    vca.prepare(fs, seed);
    faderAmp.prepare(fs, 4700.0, 100.0e-12);         // T10, R82/C52
    panInputCoupling.prepare(fs, 24900.0, 10.0e-6);  // C55/C58 + R85/R93
    panAmp.prepare(fs, 24900.0, 33.0e-12);           // T11/T12, R69/R96 + C65/C66
    panOutputCoupling.prepare(fs, 4700.0, 100.0e-6); // C57/C60 into 4k7 load leg
}

void SSLChannel::Path::reset() noexcept {
    lineCoupling.reset(); lineAmp.reset(); inputSelectCoupling.reset(); inputSelectAmp.reset();
    faderCoupling.reset(); vca.reset(); faderAmp.reset(); panInputCoupling.reset(); panAmp.reset(); panOutputCoupling.reset();
}

double SSLChannel::Path::prePan(double digitalInput, double trimDb, double faderDb) noexcept {
    double v = SSLChannel::digitalToVolts(digitalInput);
    v = lineCoupling.process(v);
    v *= SSLChannel::dbToGain(trimDb);
    v = lineAmp.process(v);
    v = inputSelectCoupling.process(v);
    v = inputSelectAmp.process(v);
    v = faderCoupling.process(v);
    v = vca.process(v, faderDb);
    v = faderAmp.process(v);
    return v;
}

double SSLChannel::Path::postPan(double volts, bool /*odd*/) noexcept {
    double v = panInputCoupling.process(volts);
    v = panAmp.process(v);
    v = panOutputCoupling.process(v);
    return v;
}

void SSLChannel::prepare(double sampleRate, std::uint64_t noiseSeed) noexcept {
    pathOdd_.prepare(sampleRate, noiseSeed ^ 0x9e3779b97f4a7c15ULL);
    pathEven_.prepare(sampleRate, noiseSeed ^ 0xd1b54a32d192ed03ULL);
    const double tau = 0.005;
    controlSlew_ = std::exp(-1.0 / (tau * sampleRate));
    trimDb_ = targetTrimDb_.load(std::memory_order_relaxed);
    faderDb_ = targetFaderDb_.load(std::memory_order_relaxed);
    pan_ = targetPan_.load(std::memory_order_relaxed);
}

void SSLChannel::reset() noexcept {
    pathOdd_.reset(); pathEven_.reset();
    trimDb_ = targetTrimDb_.load(std::memory_order_relaxed);
    faderDb_ = targetFaderDb_.load(std::memory_order_relaxed);
    pan_ = targetPan_.load(std::memory_order_relaxed);
}

void SSLChannel::setInputTrimDb(double db) noexcept { targetTrimDb_.store(clamp(db, -20.0, 20.0), std::memory_order_relaxed); }
void SSLChannel::setFaderDb(double db) noexcept { targetFaderDb_.store(clamp(db, -120.0, 10.0), std::memory_order_relaxed); }
void SSLChannel::setPan(double pan) noexcept { targetPan_.store(clamp(pan, -1.0, 1.0), std::memory_order_relaxed); }

double SSLChannel::smoothedTrimDb() noexcept {
    const double t = targetTrimDb_.load(std::memory_order_relaxed);
    trimDb_ = t + controlSlew_ * (trimDb_ - t); return trimDb_;
}
double SSLChannel::smoothedFaderDb() noexcept {
    const double t = targetFaderDb_.load(std::memory_order_relaxed);
    faderDb_ = t + controlSlew_ * (faderDb_ - t); return faderDb_;
}
double SSLChannel::smoothedPan() noexcept {
    const double t = targetPan_.load(std::memory_order_relaxed);
    pan_ = t + controlSlew_ * (pan_ - t); return pan_;
}

double SSLChannel::panGainLeft(double pan) noexcept {
    pan = clamp(pan, -1.0, 1.0);
    const double theta = (pan + 1.0) * (kPi * 0.25);
    return std::pow(std::cos(theta), kPanExponent);
}
double SSLChannel::panGainRight(double pan) noexcept {
    pan = clamp(pan, -1.0, 1.0);
    const double theta = (pan + 1.0) * (kPi * 0.25);
    return std::pow(std::sin(theta), kPanExponent);
}

void SSLChannel::process(double input, double& outL, double& outR) noexcept {
    const double trim = smoothedTrimDb();
    const double fader = smoothedFaderDb();
    const double pan = smoothedPan();

    // Each odd/even route has its own physical 82E149 buffer path; process independently rather than duplicating after DSP.
    const double baseOdd = pathOdd_.prePan(input, trim, fader);
    const double baseEven = pathEven_.prePan(input, trim, fader);
    const double lV = pathOdd_.postPan(baseOdd * panGainLeft(pan), true);
    const double rV = pathEven_.postPan(baseEven * panGainRight(pan), false);
    outL = voltsToDigital(lV);
    outR = voltsToDigital(rV);
}

} // namespace caudio
