#pragma once

#include <cstddef>

namespace caudio {

// SSL 4000 E master-path work in progress.
// 82E26 mix amplifier uses component values visible on the original 82E26 drawing:
// R50 15.04k summing input, R53 15k feedback, C28 100pF, T8 NE5534, R57 47R build-out.
// 82E195 programme output is currently an explicitly-marked EFFECTIVE MACROMODEL around
// the verified output-driver values (39.2k input network, 30.1k/301k feedback network,
// 75R build-outs, 100k cross-coupling and 220uF output capacitors). It is NOT yet claimed
// to be a complete node-for-node MNA of every 82E195 switch/insert/monitor path.
class SSLMixBus {
public:
    void prepare(double sampleRate) noexcept;
    void reset() noexcept;

    // Feed one post-pan channel contribution. Internally 82E26 sums CURRENT into the
    // virtual-earth bus instead of summing channel voltages directly.
    void beginSample() noexcept;
    void addChannel(double leftDigital, double rightDigital) noexcept;
    void endSample(double& leftDigital, double& rightDigital) noexcept;

    static constexpr double summingInputOhms() noexcept { return 15040.0; }
    static constexpr double feedbackOhms() noexcept { return 15000.0; }
    static constexpr double feedbackCapFarads() noexcept { return 100.0e-12; }
    static constexpr double mixBuildoutOhms() noexcept { return 47.0; }

    const char* programOutputModelType() const noexcept {
        return "82E195_EFFECTIVE_BALANCED_OUTPUT_MACROMODEL_VERIFIED_R_VALUES";
    }

private:
    struct OnePoleLP {
        double a = 1.0;
        double z = 0.0;
        void prepare(double fs, double cutoffHz) noexcept;
        void reset() noexcept { z = 0.0; }
        double process(double x) noexcept;
    };

    struct OnePoleHP {
        double a = 0.0;
        double x1 = 0.0;
        double y1 = 0.0;
        void prepare(double fs, double rOhm, double cFarad) noexcept;
        void reset() noexcept { x1 = y1 = 0.0; }
        double process(double x) noexcept;
    };

    struct NE5534Macro {
        OnePoleLP closedLoopPole;
        double prev = 0.0;
        double slewPerSample = 1.0;
        double swing = 15.0;
        void prepare(double fs, double feedbackR, double feedbackC, double railBound) noexcept;
        void reset() noexcept { closedLoopPole.reset(); prev = 0.0; }
        double process(double x) noexcept;
    };

    struct MixAmp82E26 {
        NE5534Macro op;
        double current = 0.0;
        void prepare(double fs) noexcept;
        void reset() noexcept { op.reset(); current = 0.0; }
        double processCurrent(double currentAmps) noexcept;
    } leftMix_, rightMix_;

    struct ProgramOut82E195 {
        // Verified visible values from the programme-output driver section.
        static double inputR() noexcept { return 39200.0; }
        static double feedbackR() noexcept { return 30100.0; }
        static double crossFeedbackR() noexcept { return 301000.0; }
        static double buildoutR() noexcept { return 75.0; }
        static double crossSenseR() noexcept { return 100000.0; }
        static double outputC() noexcept { return 220.0e-6; }
        static double nominalLoadR() noexcept { return 600.0; }

        NE5534Macro op;
        OnePoleHP outputCoupling;
        double normalise = 1.0;
        void prepare(double fs) noexcept;
        void reset() noexcept { op.reset(); outputCoupling.reset(); }
        double process(double volts) noexcept;
    } leftOut_, rightOut_;

    static double clamp(double x, double lo, double hi) noexcept;
    static double digitalToVolts(double x) noexcept;
    static double voltsToDigital(double v) noexcept;

    double sampleRate_ = 48000.0;
    double busCurrentL_ = 0.0;
    double busCurrentR_ = 0.0;
};

} // namespace caudio
