#include "ProjectFile.h"

#include <fstream>
#include <iomanip>
#include <limits>

namespace caudio {

ProjectState ProjectFile::capture(const MixerEngine& engine) {
    ProjectState s;
    s.playhead = engine.playhead();
    s.masterDb = engine.masterDb();
    s.sslEnabled = engine.sslEnabled();
    s.outputFormat = static_cast<int>(engine.outputFormat());
    s.outputA = engine.outputA();
    s.outputB = engine.outputB();
    for (std::size_t i = 0; i < MixerEngine::kTrackCount; ++i) {
        const auto& t = engine.track(i);
        auto& d = s.tracks[i];
        d.name = t.name;
        d.format = t.format.load(std::memory_order_relaxed);
        d.source = t.source.load(std::memory_order_relaxed);
        d.inputA = t.inputA.load(std::memory_order_relaxed);
        d.inputB = t.inputB.load(std::memory_order_relaxed);
        d.recordArm = t.recordArm.load(std::memory_order_relaxed);
        d.inputMonitor = t.inputMonitor.load(std::memory_order_relaxed);
        d.mute = t.mute.load(std::memory_order_relaxed);
        d.solo = t.solo.load(std::memory_order_relaxed);
        d.inputTrimDb = t.inputTrimDb.load(std::memory_order_relaxed);
        d.faderDb = t.faderDb.load(std::memory_order_relaxed);
        d.pan = t.pan.load(std::memory_order_relaxed);
        d.eventStartFrame = t.eventStartFrame.load(std::memory_order_relaxed);
        d.sourcePath = t.clip.sourcePath;
    }
    return s;
}

void ProjectFile::applyMetadata(MixerEngine& engine, const ProjectState& s) noexcept {
    engine.stop();
    engine.setMasterDb(s.masterDb);
    engine.setSSLEnabled(s.sslEnabled);
    engine.setOutputFormat(s.outputFormat == static_cast<int>(OutputFormat::Mono) ? OutputFormat::Mono : OutputFormat::Stereo);
    engine.setOutputA(s.outputA);
    engine.setOutputB(s.outputB);
    for (std::size_t i = 0; i < MixerEngine::kTrackCount; ++i) {
        auto& t = engine.track(i); const auto& d = s.tracks[i];
        t.name = d.name;
        t.format.store(d.format, std::memory_order_relaxed);
        t.source.store(d.source, std::memory_order_relaxed);
        t.inputA.store(d.inputA, std::memory_order_relaxed);
        t.inputB.store(d.inputB, std::memory_order_relaxed);
        t.recordArm.store(d.recordArm, std::memory_order_relaxed);
        t.inputMonitor.store(d.inputMonitor, std::memory_order_relaxed);
        t.mute.store(d.mute, std::memory_order_relaxed);
        t.solo.store(d.solo, std::memory_order_relaxed);
        t.inputTrimDb.store(d.inputTrimDb, std::memory_order_relaxed);
        t.faderDb.store(d.faderDb, std::memory_order_relaxed);
        t.pan.store(d.pan, std::memory_order_relaxed);
        t.eventStartFrame.store(d.eventStartFrame, std::memory_order_relaxed);
    }
    engine.setPlayhead(s.playhead);
}

bool ProjectFile::save(const std::string& path, const ProjectState& s, std::string& error) {
    std::ofstream out(path, std::ios::binary | std::ios::trunc);
    if (!out) { error = "Cannot create project file: " + path; return false; }
    out << "C-AUDIO-PROJECT " << ProjectState::kVersion << '\n';
    out << "TRANSPORT " << s.playhead << '\n';
    out << "MASTER " << std::setprecision(17) << s.masterDb << ' ' << (s.sslEnabled ? 1 : 0) << ' '
        << s.outputFormat << ' ' << s.outputA << ' ' << s.outputB << '\n';
    for (std::size_t i = 0; i < MixerEngine::kTrackCount; ++i) {
        const auto& t = s.tracks[i];
        out << "TRACK " << i << ' ' << std::quoted(t.name) << ' '
            << t.format << ' ' << t.source << ' ' << t.inputA << ' ' << t.inputB << ' '
            << (t.recordArm?1:0) << ' ' << (t.inputMonitor?1:0) << ' ' << (t.mute?1:0) << ' ' << (t.solo?1:0) << ' '
            << std::setprecision(17) << t.inputTrimDb << ' ' << t.faderDb << ' ' << t.pan << ' '
            << t.eventStartFrame << ' ' << std::quoted(t.sourcePath) << '\n';
    }
    if (!out.good()) { error = "Failed while writing project file: " + path; return false; }
    return true;
}

bool ProjectFile::load(const std::string& path, ProjectState& s, std::string& error) {
    std::ifstream in(path, std::ios::binary);
    if (!in) { error = "Cannot open project file: " + path; return false; }
    std::string magic; int version = 0;
    if (!(in >> magic >> version) || magic != "C-AUDIO-PROJECT" || version != ProjectState::kVersion) {
        error = "Unsupported or damaged C-AUDIO project file."; return false;
    }
    ProjectState parsed;
    std::string key;
    if (!(in >> key) || key != "TRANSPORT" || !(in >> parsed.playhead)) { error = "Missing TRANSPORT section."; return false; }
    int ssl = 0;
    if (!(in >> key) || key != "MASTER" || !(in >> parsed.masterDb >> ssl >> parsed.outputFormat >> parsed.outputA >> parsed.outputB)) { error = "Missing MASTER section."; return false; }
    parsed.sslEnabled = ssl != 0;
    for (std::size_t expected = 0; expected < MixerEngine::kTrackCount; ++expected) {
        std::size_t index = 0; int arm=0, mon=0, mute=0, solo=0;
        if (!(in >> key) || key != "TRACK" || !(in >> index) || index != expected) { error = "Missing or out-of-order TRACK section."; return false; }
        auto& t = parsed.tracks[index];
        if (!(in >> std::quoted(t.name) >> t.format >> t.source >> t.inputA >> t.inputB >> arm >> mon >> mute >> solo
                 >> t.inputTrimDb >> t.faderDb >> t.pan >> t.eventStartFrame >> std::quoted(t.sourcePath))) {
            error = "Damaged TRACK data."; return false;
        }
        t.recordArm = arm != 0; t.inputMonitor = mon != 0; t.mute = mute != 0; t.solo = solo != 0;
        if (t.format != static_cast<int>(TrackFormat::Mono) && t.format != static_cast<int>(TrackFormat::Stereo)) { error = "Invalid track format."; return false; }
        if (t.source != static_cast<int>(TrackSource::File) && t.source != static_cast<int>(TrackSource::HardwareInput)) { error = "Invalid track source."; return false; }
    }
    s = parsed;
    return true;
}

} // namespace caudio
