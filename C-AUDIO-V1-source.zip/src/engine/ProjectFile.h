#pragma once

#include "MixerEngine.h"

#include <array>
#include <cstdint>
#include <string>

namespace caudio {

struct ProjectTrackState {
    std::string name;
    int format = static_cast<int>(TrackFormat::Mono);
    int source = static_cast<int>(TrackSource::File);
    int inputA = 0;
    int inputB = 1;
    bool recordArm = false;
    bool inputMonitor = true;
    bool mute = false;
    bool solo = false;
    double inputTrimDb = 0.0;
    double faderDb = 0.0;
    double pan = 0.0;
    std::uint64_t eventStartFrame = 0;
    std::string sourcePath;
};

struct ProjectState {
    static constexpr int kVersion = 1;
    std::array<ProjectTrackState, MixerEngine::kTrackCount> tracks;
    std::uint64_t playhead = 0;
    double masterDb = 0.0;
    bool sslEnabled = true;
    int outputFormat = static_cast<int>(OutputFormat::Stereo);
    int outputA = 0;
    int outputB = 1;
};

class ProjectFile {
public:
    static ProjectState capture(const MixerEngine& engine);
    static void applyMetadata(MixerEngine& engine, const ProjectState& state) noexcept;
    static bool save(const std::string& path, const ProjectState& state, std::string& error);
    static bool load(const std::string& path, ProjectState& state, std::string& error);
};

} // namespace caudio
