#include "MixerEngine.h"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <sstream>
#include <thread>

namespace caudio {
namespace {
constexpr double kPi = 3.14159265358979323846264338327950288;

void writeU16LE(std::FILE* f, std::uint16_t v) {
    unsigned char b[2] = { static_cast<unsigned char>(v & 0xff), static_cast<unsigned char>((v >> 8) & 0xff) };
    std::fwrite(b, 1, 2, f);
}
void writeU32LE(std::FILE* f, std::uint32_t v) {
    unsigned char b[4] = { static_cast<unsigned char>(v & 0xff), static_cast<unsigned char>((v >> 8) & 0xff),
                           static_cast<unsigned char>((v >> 16) & 0xff), static_cast<unsigned char>((v >> 24) & 0xff) };
    std::fwrite(b, 1, 4, f);
}
}

MixerEngine::MixerEngine() = default;
MixerEngine::~MixerEngine() { stopRecording(); }

double MixerEngine::dbToGain(double db) noexcept {
    if (db <= -119.0) return 0.0;
    return std::pow(10.0, db / 20.0);
}

double MixerEngine::stereoBalanceLeft(double pan) noexcept {
    pan = std::max(-1.0, std::min(1.0, pan));
    if (pan <= 0.0) return 1.0;
    return std::cos(pan * kPi * 0.5);
}
double MixerEngine::stereoBalanceRight(double pan) noexcept {
    pan = std::max(-1.0, std::min(1.0, pan));
    if (pan >= 0.0) return 1.0;
    return std::cos((-pan) * kPi * 0.5);
}

void MixerEngine::RecordRing::prepare(std::size_t capacityPowerOfTwo) {
    std::size_t cap = 1;
    while (cap < capacityPowerOfTwo) cap <<= 1;
    data_.assign(cap, RecordFrame{});
    mask_ = cap - 1;
    reset();
}
void MixerEngine::RecordRing::reset() noexcept { write_.store(0, std::memory_order_relaxed); read_.store(0, std::memory_order_relaxed); }
bool MixerEngine::RecordRing::push(float l, float r) noexcept {
    const std::uint64_t w = write_.load(std::memory_order_relaxed);
    const std::uint64_t rd = read_.load(std::memory_order_acquire);
    if (w - rd >= data_.size()) return false;
    data_[static_cast<std::size_t>(w) & mask_] = {l, r};
    write_.store(w + 1, std::memory_order_release);
    return true;
}
std::size_t MixerEngine::RecordRing::pop(RecordFrame* dst, std::size_t maxFrames) noexcept {
    const std::uint64_t rd = read_.load(std::memory_order_relaxed);
    const std::uint64_t w = write_.load(std::memory_order_acquire);
    const std::size_t count = static_cast<std::size_t>(std::min<std::uint64_t>(w - rd, maxFrames));
    for (std::size_t i = 0; i < count; ++i) dst[i] = data_[static_cast<std::size_t>(rd + i) & mask_];
    read_.store(rd + count, std::memory_order_release);
    return count;
}
bool MixerEngine::RecordRing::empty() const noexcept {
    return read_.load(std::memory_order_acquire) == write_.load(std::memory_order_acquire);
}

bool MixerEngine::WaveWriter::open(const std::string& path, std::uint32_t sampleRate, int channels) {
    close();
    std::FILE* f = std::fopen(path.c_str(), "wb");
    if (!f) return false;
    path_ = path; file_ = f; sampleRate_ = sampleRate; channels_ = channels; framesWritten_ = 0; open_ = true;
    std::fwrite("RIFF", 1, 4, f); writeU32LE(f, 0); std::fwrite("WAVE", 1, 4, f);
    std::fwrite("fmt ", 1, 4, f); writeU32LE(f, 16); writeU16LE(f, 3); // IEEE float
    writeU16LE(f, static_cast<std::uint16_t>(channels)); writeU32LE(f, sampleRate);
    writeU32LE(f, sampleRate * static_cast<std::uint32_t>(channels) * 4U);
    writeU16LE(f, static_cast<std::uint16_t>(channels * 4)); writeU16LE(f, 32);
    std::fwrite("data", 1, 4, f); writeU32LE(f, 0);
    return true;
}
void MixerEngine::WaveWriter::write(const RecordFrame* frames, std::size_t count) {
    if (!open_ || !file_ || count == 0) return;
    std::FILE* f = static_cast<std::FILE*>(file_);
    if (channels_ == 1) {
        for (std::size_t i = 0; i < count; ++i) std::fwrite(&frames[i].l, sizeof(float), 1, f);
    } else {
        for (std::size_t i = 0; i < count; ++i) { std::fwrite(&frames[i].l, sizeof(float), 1, f); std::fwrite(&frames[i].r, sizeof(float), 1, f); }
    }
    framesWritten_ += count;
}
void MixerEngine::WaveWriter::close() {
    if (!open_ || !file_) { file_ = nullptr; open_ = false; return; }
    std::FILE* f = static_cast<std::FILE*>(file_);
    const std::uint64_t dataBytes64 = framesWritten_ * static_cast<std::uint64_t>(channels_) * 4ULL;
    const std::uint32_t dataBytes = static_cast<std::uint32_t>(std::min<std::uint64_t>(dataBytes64, 0xffffffffULL));
    std::fseek(f, 4, SEEK_SET); writeU32LE(f, 36U + dataBytes);
    std::fseek(f, 40, SEEK_SET); writeU32LE(f, dataBytes);
    std::fclose(f); file_ = nullptr; open_ = false;
}

void MixerEngine::prepare(double sampleRate, std::uint32_t maxBlockFrames) {
    stopRecording();
    sampleRate_ = sampleRate > 1.0 ? sampleRate : 48000.0;
    maxBlockFrames_ = std::max<std::uint32_t>(64, maxBlockFrames);
    sslMixBus_.prepare(sampleRate_);
    for (std::size_t i = 0; i < kTrackCount; ++i) {
        tracks_[i].sslL.prepare(sampleRate_, 0xC0A001ULL + i * 31ULL);
        tracks_[i].sslR.prepare(sampleRate_, 0xC0A101ULL + i * 37ULL);
        recordRings_[i].prepare(262144); // >5 s at 48k; disk writer never touches RT callback.
    }
    stop();
}

bool MixerEngine::setClip(std::size_t index, AudioClip&& clip) noexcept {
    if (index >= kTrackCount || isPlaying() || isRecording()) return false;
    editing_.store(true, std::memory_order_release);
    while (callbackDepth_.load(std::memory_order_acquire) != 0) std::this_thread::yield();
    tracks_[index].clip = std::move(clip);
    tracks_[index].format.store(static_cast<int>(tracks_[index].clip.stereo ? TrackFormat::Stereo : TrackFormat::Mono), std::memory_order_relaxed);
    tracks_[index].source.store(static_cast<int>(TrackSource::File), std::memory_order_relaxed);
    tracks_[index].sslL.reset(); tracks_[index].sslR.reset();
    editing_.store(false, std::memory_order_release);
    return true;
}
void MixerEngine::clearClip(std::size_t index) noexcept {
    if (index >= kTrackCount || isPlaying() || isRecording()) return;
    editing_.store(true, std::memory_order_release);
    while (callbackDepth_.load(std::memory_order_acquire) != 0) std::this_thread::yield();
    tracks_[index].clip = AudioClip{};
    editing_.store(false, std::memory_order_release);
}
bool MixerEngine::hasAnyClip() const noexcept {
    for (const auto& t : tracks_) if (!t.clip.left.empty()) return true;
    return false;
}

void MixerEngine::play() noexcept { playing_.store(true, std::memory_order_release); }
void MixerEngine::stop() noexcept {
    recording_.store(false, std::memory_order_release);
    playing_.store(false, std::memory_order_release);
    playhead_.store(0, std::memory_order_relaxed);
    peakL_.store(0.0, std::memory_order_relaxed); peakR_.store(0.0, std::memory_order_relaxed);
    for (auto& t : tracks_) { t.sslL.reset(); t.sslR.reset(); }
}
void MixerEngine::setMasterDb(double db) noexcept { masterDb_.store(std::max(-120.0, std::min(10.0, db)), std::memory_order_relaxed); }

bool MixerEngine::startRecording(const std::string& folder, std::string& error) {
    if (recording_.load(std::memory_order_acquire)) return true;
    bool any = false;
    for (std::size_t i = 0; i < kTrackCount; ++i) {
        recordRings_[i].reset(); recordFiles_[i].close(); recordChannels_[i] = 0;
        if (!tracks_[i].recordArm.load(std::memory_order_relaxed)) continue;
        if (tracks_[i].source.load(std::memory_order_relaxed) != static_cast<int>(TrackSource::HardwareInput)) {
            error = "Armed channel " + std::to_string(i + 1) + " must have SOURCE set to INPUT.";
            for (auto& f : recordFiles_) f.close();
            return false;
        }
        any = true;
        const int ch = tracks_[i].format.load(std::memory_order_relaxed) == static_cast<int>(TrackFormat::Stereo) ? 2 : 1;
        recordChannels_[i] = ch;
        std::ostringstream path;
        path << folder;
        if (!folder.empty() && folder.back() != '/') path << '/';
        path << "C-AUDIO_CH" << (i + 1) << (ch == 2 ? "_ST.wav" : "_MONO.wav");
        if (!recordFiles_[i].open(path.str(), static_cast<std::uint32_t>(std::llround(sampleRate_)), ch)) {
            error = "Cannot create recording file: " + path.str();
            for (auto& f : recordFiles_) f.close();
            return false;
        }
    }
    if (!any) { error = "Arm at least one channel before RECORD."; return false; }
    droppedRecordFrames_.store(0, std::memory_order_relaxed);
    writerRun_.store(true, std::memory_order_release);
    writerThread_ = std::thread(&MixerEngine::writerLoop, this);
    recording_.store(true, std::memory_order_release);
    playing_.store(true, std::memory_order_release);
    return true;
}

void MixerEngine::stopRecording() {
    recording_.store(false, std::memory_order_release);
    if (writerRun_.exchange(false, std::memory_order_acq_rel)) {
        if (writerThread_.joinable()) writerThread_.join();
    } else if (writerThread_.joinable()) {
        writerThread_.join();
    }
    for (auto& f : recordFiles_) f.close();
}

void MixerEngine::writerLoop() {
    std::array<RecordFrame, 2048> chunk{};
    while (writerRun_.load(std::memory_order_acquire)) {
        bool didWork = false;
        for (std::size_t i = 0; i < kTrackCount; ++i) {
            if (!recordFiles_[i].isOpen()) continue;
            const std::size_t n = recordRings_[i].pop(chunk.data(), chunk.size());
            if (n) { recordFiles_[i].write(chunk.data(), n); didWork = true; }
        }
        if (!didWork) std::this_thread::sleep_for(std::chrono::milliseconds(2));
    }
    // Drain all queues before closing the files.
    for (;;) {
        bool any = false;
        for (std::size_t i = 0; i < kTrackCount; ++i) {
            if (!recordFiles_[i].isOpen()) continue;
            const std::size_t n = recordRings_[i].pop(chunk.data(), chunk.size());
            if (n) { recordFiles_[i].write(chunk.data(), n); any = true; }
        }
        if (!any) break;
    }
}

void MixerEngine::configureChannelControls(Track& t) noexcept {
    const double trim = t.inputTrimDb.load(std::memory_order_relaxed);
    const double fader = t.faderDb.load(std::memory_order_relaxed);
    const double pan = t.pan.load(std::memory_order_relaxed);
    t.sslL.setInputTrimDb(trim); t.sslR.setInputTrimDb(trim);
    t.sslL.setFaderDb(fader); t.sslR.setFaderDb(fader);
    // Mono uses console pan. Stereo is a linked pair: hard L/R internally, then balance after the two channel paths.
    if (t.format.load(std::memory_order_relaxed) == static_cast<int>(TrackFormat::Mono)) {
        t.sslL.setPan(pan);
    } else {
        t.sslL.setPan(-1.0); t.sslR.setPan(1.0);
    }
}

void MixerEngine::process(const double* const* inputs, std::uint32_t inputChannels,
                          double* const* outputs, std::uint32_t outputChannels,
                          std::uint32_t frames) noexcept {
    for (std::uint32_t ch = 0; ch < outputChannels; ++ch) {
        if (outputs[ch]) std::fill(outputs[ch], outputs[ch] + frames, 0.0);
    }

    if (editing_.load(std::memory_order_acquire)) return;
    callbackDepth_.fetch_add(1, std::memory_order_acq_rel);
    if (editing_.load(std::memory_order_acquire)) {
        callbackDepth_.fetch_sub(1, std::memory_order_acq_rel);
        return;
    }

    bool anySolo = false;
    for (auto& t : tracks_) {
        anySolo = anySolo || t.solo.load(std::memory_order_relaxed);
        configureChannelControls(t);
    }

    const bool running = playing_.load(std::memory_order_acquire);
    const bool rec = recording_.load(std::memory_order_acquire);
    if (!running && !rec) { callbackDepth_.fetch_sub(1, std::memory_order_acq_rel); return; }

    std::uint64_t pos = playhead_.load(std::memory_order_relaxed);
    const double master = dbToGain(masterDb_.load(std::memory_order_relaxed));
    const int outA = outputA_.load(std::memory_order_relaxed);
    const int outB = outputB_.load(std::memory_order_relaxed);
    const bool stereoOut = outputFormat_.load(std::memory_order_relaxed) == static_cast<int>(OutputFormat::Stereo);
    double blockPeakL = 0.0, blockPeakR = 0.0;

    const bool sslOn = sslEnabled_.load(std::memory_order_relaxed);

    for (std::uint32_t n = 0; n < frames; ++n) {
        double cleanL = 0.0, cleanR = 0.0;
        double cleanCompL = 0.0, cleanCompR = 0.0;
        sslMixBus_.beginSample();

        for (std::size_t ti = 0; ti < kTrackCount; ++ti) {
            Track& t = tracks_[ti];
            const bool stereoTrack = t.format.load(std::memory_order_relaxed) == static_cast<int>(TrackFormat::Stereo);
            const bool live = t.source.load(std::memory_order_relaxed) == static_cast<int>(TrackSource::HardwareInput);
            const int ia = t.inputA.load(std::memory_order_relaxed);
            const int ib = t.inputB.load(std::memory_order_relaxed);

            double rawL = 0.0, rawR = 0.0;
            if (live) {
                if (ia >= 0 && static_cast<std::uint32_t>(ia) < inputChannels && inputs && inputs[ia]) rawL = inputs[ia][n];
                if (stereoTrack) {
                    if (ib >= 0 && static_cast<std::uint32_t>(ib) < inputChannels && inputs && inputs[ib]) rawR = inputs[ib][n];
                } else rawR = rawL;
            } else if (pos < t.clip.frames()) {
                rawL = t.clip.left[static_cast<std::size_t>(pos)];
                rawR = t.clip.stereo ? t.clip.right[static_cast<std::size_t>(pos)] : rawL;
            }

            if (rec && t.recordArm.load(std::memory_order_relaxed)) {
                const float a = static_cast<float>(rawL);
                const float b = static_cast<float>(stereoTrack ? rawR : rawL);
                if (!recordRings_[ti].push(a, b)) droppedRecordFrames_.fetch_add(1, std::memory_order_relaxed);
            }

            const bool shouldMonitor = !live || t.inputMonitor.load(std::memory_order_relaxed) || rec;
            if (!shouldMonitor) continue;
            if (t.mute.load(std::memory_order_relaxed)) continue;
            if (anySolo && !t.solo.load(std::memory_order_relaxed)) continue;

            // Clean comparison path: same user controls, but no SSL channel or SSL mix/output DSP.
            // This makes the single SSL ON/OFF button a meaningful A/B rather than changing fader/pan levels.
            const double trimGain = dbToGain(t.inputTrimDb.load(std::memory_order_relaxed));
            const double faderGain = dbToGain(t.faderDb.load(std::memory_order_relaxed));
            const double controlGain = trimGain * faderGain;
            double dryL = 0.0, dryR = 0.0;
            if (!stereoTrack) {
                const double pan = t.pan.load(std::memory_order_relaxed);
                const double base = rawL * controlGain;
                dryL = base * SSLChannel::panGainLeft(pan);
                dryR = base * SSLChannel::panGainRight(pan);
            } else {
                const double pan = t.pan.load(std::memory_order_relaxed);
                dryL = rawL * controlGain * stereoBalanceLeft(pan);
                dryR = rawR * controlGain * stereoBalanceRight(pan);
            }

            const double dryYL = dryL - cleanCompL; const double dryTmpL = cleanL + dryYL; cleanCompL = (dryTmpL - cleanL) - dryYL; cleanL = dryTmpL;
            const double dryYR = dryR - cleanCompR; const double dryTmpR = cleanR + dryYR; cleanCompR = (dryTmpR - cleanR) - dryYR; cleanR = dryTmpR;

            // Keep the SSL circuit state running so switching back ON does not produce stale-filter transients.
            double wetL = 0.0, wetR = 0.0;
            if (!stereoTrack) {
                t.sslL.process(rawL, wetL, wetR);
            } else {
                double l1=0.0, l2=0.0, r1=0.0, r2=0.0;
                t.sslL.process(rawL, l1, l2);
                t.sslR.process(rawR, r1, r2);
                const double pan = t.pan.load(std::memory_order_relaxed);
                wetL = l1 * stereoBalanceLeft(pan);
                wetR = r2 * stereoBalanceRight(pan);
            }
            sslMixBus_.addChannel(wetL, wetR);
        }

        double sslL = 0.0, sslR = 0.0;
        sslMixBus_.endSample(sslL, sslR);
        double sumL = sslOn ? sslL : cleanL;
        double sumR = sslOn ? sslR : cleanR;
        sumL *= master; sumR *= master;
        blockPeakL = std::max(blockPeakL, std::abs(sumL)); blockPeakR = std::max(blockPeakR, std::abs(sumR));

        if (stereoOut) {
            if (outA >= 0 && static_cast<std::uint32_t>(outA) < outputChannels && outputs[outA]) outputs[outA][n] += sumL;
            if (outB >= 0 && static_cast<std::uint32_t>(outB) < outputChannels && outputs[outB]) outputs[outB][n] += sumR;
        } else {
            const double mono = (sumL + sumR) * 0.5;
            if (outA >= 0 && static_cast<std::uint32_t>(outA) < outputChannels && outputs[outA]) outputs[outA][n] += mono;
        }
        ++pos;
    }

    peakL_.store(blockPeakL, std::memory_order_relaxed); peakR_.store(blockPeakR, std::memory_order_relaxed);
    playhead_.store(pos, std::memory_order_relaxed);
    callbackDepth_.fetch_sub(1, std::memory_order_acq_rel);
}

} // namespace caudio
