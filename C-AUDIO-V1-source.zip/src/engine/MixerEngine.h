#pragma once

#include "SSLChannel.h"
#include "SSLMixBus.h"

#include <array>
#include <atomic>
#include <cstdint>
#include <string>
#include <thread>
#include <vector>

namespace caudio {

struct AudioClip {
    std::vector<double> left;
    std::vector<double> right;
    bool stereo = false;
    std::string name;
    std::string sourcePath;
    std::size_t frames() const noexcept { return left.size(); }
};

enum class TrackFormat : int { Mono = 1, Stereo = 2 };
enum class TrackSource : int { File = 0, HardwareInput = 1 };
enum class OutputFormat : int { Mono = 1, Stereo = 2 };

class MixerEngine {
public:
    static constexpr std::size_t kTrackCount = 6;
    static constexpr std::size_t kMaxHardwareChannels = 64;

    struct Track {
        AudioClip clip;
        SSLChannel sslL;
        SSLChannel sslR; // stereo track = two real SSL channel paths linked by one fader/trim
        std::atomic<int> format{static_cast<int>(TrackFormat::Mono)};
        std::atomic<int> source{static_cast<int>(TrackSource::File)};
        std::atomic<int> inputA{0};
        std::atomic<int> inputB{1};
        std::atomic<bool> recordArm{false};
        std::atomic<bool> inputMonitor{true};
        std::atomic<bool> mute{false};
        std::atomic<bool> solo{false};
        std::atomic<double> inputTrimDb{0.0};
        std::atomic<double> faderDb{0.0};
        std::atomic<double> pan{0.0};
        // Project-window state. The event start is RT-readable and may be moved while stopped.
        std::atomic<std::uint64_t> eventStartFrame{0};
        std::string name;
    };

    MixerEngine();
    ~MixerEngine();

    void prepare(double sampleRate, std::uint32_t maxBlockFrames);
    double sampleRate() const noexcept { return sampleRate_; }

    Track& track(std::size_t i) noexcept { return tracks_[i]; }
    const Track& track(std::size_t i) const noexcept { return tracks_[i]; }

    bool setClip(std::size_t index, AudioClip&& clip) noexcept;
    void clearClip(std::size_t index) noexcept;
    bool hasAnyClip() const noexcept;

    void play() noexcept;
    void stop() noexcept;
    void returnToStart() noexcept;
    void setPlayhead(std::uint64_t frame) noexcept;
    bool setEventStartFrame(std::size_t index, std::uint64_t frame) noexcept;
    std::uint64_t eventStartFrame(std::size_t index) const noexcept;
    std::uint64_t projectEndFrame() const noexcept;
    bool isPlaying() const noexcept { return playing_.load(std::memory_order_acquire); }

    bool startRecording(const std::string& folder, std::string& error);
    void stopRecording();
    bool isRecording() const noexcept { return recording_.load(std::memory_order_acquire); }
    std::uint64_t droppedRecordFrames() const noexcept { return droppedRecordFrames_.load(std::memory_order_relaxed); }

    void setMasterDb(double db) noexcept;
    double masterDb() const noexcept { return masterDb_.load(std::memory_order_relaxed); }
    void setSSLEnabled(bool enabled) noexcept { sslEnabled_.store(enabled, std::memory_order_relaxed); }
    bool sslEnabled() const noexcept { return sslEnabled_.load(std::memory_order_relaxed); }
    void setOutputFormat(OutputFormat fmt) noexcept { outputFormat_.store(static_cast<int>(fmt), std::memory_order_relaxed); }
    OutputFormat outputFormat() const noexcept { return static_cast<OutputFormat>(outputFormat_.load(std::memory_order_relaxed)); }
    void setOutputA(int channel) noexcept { outputA_.store(channel, std::memory_order_relaxed); }
    void setOutputB(int channel) noexcept { outputB_.store(channel, std::memory_order_relaxed); }
    int outputA() const noexcept { return outputA_.load(std::memory_order_relaxed); }
    int outputB() const noexcept { return outputB_.load(std::memory_order_relaxed); }

    // Real-time callback. All buffers are non-interleaved 64-bit floating point.
    void process(const double* const* inputs, std::uint32_t inputChannels,
                 double* const* outputs, std::uint32_t outputChannels,
                 std::uint32_t frames) noexcept;

    double peakLeft() const noexcept { return peakL_.load(std::memory_order_relaxed); }
    double peakRight() const noexcept { return peakR_.load(std::memory_order_relaxed); }
    double trackPeak(std::size_t i) const noexcept { return i < kTrackCount ? trackPeak_[i].load(std::memory_order_relaxed) : 0.0; }
    std::uint64_t playhead() const noexcept { return playhead_.load(std::memory_order_relaxed); }

private:
    struct RecordFrame { float l = 0.0f, r = 0.0f; };

    class RecordRing {
    public:
        void prepare(std::size_t capacityPowerOfTwo);
        void reset() noexcept;
        bool push(float l, float r) noexcept;
        std::size_t pop(RecordFrame* dst, std::size_t maxFrames) noexcept;
        bool empty() const noexcept;
    private:
        std::vector<RecordFrame> data_;
        std::size_t mask_ = 0;
        std::atomic<std::uint64_t> write_{0};
        std::atomic<std::uint64_t> read_{0};
    };

    class WaveWriter {
    public:
        bool open(const std::string& path, std::uint32_t sampleRate, int channels);
        void write(const RecordFrame* frames, std::size_t count);
        void close();
        bool isOpen() const noexcept { return open_; }
    private:
        std::string path_;
        void* file_ = nullptr; // std::FILE*, kept opaque in header
        std::uint32_t sampleRate_ = 0;
        int channels_ = 0;
        std::uint64_t framesWritten_ = 0;
        bool open_ = false;
    };

    void writerLoop();
    void configureChannelControls(Track& t) noexcept;
    static double dbToGain(double db) noexcept;
    static double stereoBalanceLeft(double pan) noexcept;
    static double stereoBalanceRight(double pan) noexcept;

    std::array<Track, kTrackCount> tracks_;
    std::array<RecordRing, kTrackCount> recordRings_;
    std::array<WaveWriter, kTrackCount> recordFiles_;
    std::array<int, kTrackCount> recordChannels_{};
    std::thread writerThread_;
    std::atomic<bool> writerRun_{false};
    std::atomic<bool> recording_{false};
    std::atomic<std::uint64_t> droppedRecordFrames_{0};

    std::atomic<bool> editing_{false};
    std::atomic<unsigned> callbackDepth_{0};
    std::atomic<bool> playing_{false};
    std::atomic<std::uint64_t> playhead_{0};
    std::atomic<double> masterDb_{0.0};
    std::atomic<bool> sslEnabled_{true};
    std::atomic<int> outputFormat_{static_cast<int>(OutputFormat::Stereo)};
    std::atomic<int> outputA_{0};
    std::atomic<int> outputB_{1};
    std::atomic<double> peakL_{0.0};
    std::atomic<double> peakR_{0.0};
    std::array<std::atomic<double>, kTrackCount> trackPeak_{};
    double sampleRate_ = 48000.0;
    std::uint32_t maxBlockFrames_ = 2048;
    SSLMixBus sslMixBus_;
};

} // namespace caudio
