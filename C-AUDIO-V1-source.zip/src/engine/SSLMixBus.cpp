#include "SSLMixBus.h"

#include <algorithm>
#include <cmath>

namespace caudio {
namespace {
constexpr double kPi = 3.14159265358979323846264338327950288;
constexpr double kFullScalePeakVolts = 17.370675219607563; // +24 dBu sine peak reference
}

double SSLMixBus::clamp(double x, double lo, double hi) noexcept {
    return std::max(lo, std::min(hi, x));
}

double SSLMixBus::digitalToVolts(double x) noexcept { return x * kFullScalePeakVolts; }
double SSLMixBus::voltsToDigital(double v) noexcept { return v / kFullScalePeakVolts; }

void SSLMixBus::OnePoleLP::prepare(double fs, double cutoffHz) noexcept {
    const double fc = std::max(1.0, cutoffHz);
    // Exact sampled first-order decay. Do not clamp an analog pole to Nyquist: doing so
    // would move the 82E26/82E195 analogue pole when the project sample rate changes.
    a = 1.0 - std::exp(-2.0 * kPi * fc / fs);
    reset();
}

double SSLMixBus::OnePoleLP::process(double x) noexcept {
    z += a * (x - z);
    return z;
}

void SSLMixBus::OnePoleHP::prepare(double fs, double rOhm, double cFarad) noexcept {
    const double rc = rOhm * cFarad;
    const double dt = 1.0 / fs;
    a = rc / (rc + dt);
    reset();
}

double SSLMixBus::OnePoleHP::process(double x) noexcept {
    const double y = a * (y1 + x - x1);
    x1 = x;
    y1 = y;
    return y;
}

void SSLMixBus::NE5534Macro::prepare(double fs, double feedbackR, double feedbackC, double railBound) noexcept {
    const double pole = 1.0 / (2.0 * kPi * feedbackR * feedbackC);
    closedLoopPole.prepare(fs, pole);
    // Use published-family slew as a macro boundary. Exact loaded behaviour remains a measurement target.
    slewPerSample = 13.0e6 / fs;
    swing = railBound;
    prev = 0.0;
}

double SSLMixBus::NE5534Macro::process(double x) noexcept {
    double y = closedLoopPole.process(x);
    const double dy = clamp(y - prev, -slewPerSample, slewPerSample);
    y = clamp(prev + dy, -swing, swing);
    prev = y;
    return y;
}

void SSLMixBus::MixAmp82E26::prepare(double fs) noexcept {
    op.prepare(fs, SSLMixBus::feedbackOhms(), SSLMixBus::feedbackCapFarads(), 15.0);
    reset();
}

double SSLMixBus::MixAmp82E26::processCurrent(double currentAmps) noexcept {
    // 82E26 T8 virtual-earth transimpedance stage: Vout = -Ibus * R53.
    // R50=15.04k defines each channel's contribution current before this stage.
    const double ideal = -currentAmps * SSLMixBus::feedbackOhms();
    const double active = op.process(ideal);
    // R57 is a 47R series build-out immediately after T8; at the very high impedance
    // following patch/VCA input its level loss is negligible, so do not invent a load here.
    return active;
}

void SSLMixBus::ProgramOut82E195::prepare(double fs) noexcept {
    // Visible 82E195 output pair uses 30.1k feedback with 22pF compensation around the
    // programme-output driver and 75R output build-outs. Treat the cross-coupled network as
    // an effective differential stage until the complete card is solved node-for-node.
    op.prepare(fs, feedbackR(), 22.0e-12, 15.0);
    outputCoupling.prepare(fs, nominalLoadR() + buildoutR(), outputC());

    // Preserve nominal programme gain at a 600R load while retaining the verified 75R buildout loss.
    normalise = (nominalLoadR() + buildoutR()) / nominalLoadR();
    reset();
}

double SSLMixBus::ProgramOut82E195::process(double volts) noexcept {
    // Nominal loaded equivalent of one programme output. Cross-coupled common-mode/load
    // behaviour remains explicitly outside the current macro boundary.
    const double driven = op.process(volts);
    const double loaded = driven * (nominalLoadR() / (nominalLoadR() + buildoutR()));
    return outputCoupling.process(loaded) * normalise;
}

void SSLMixBus::prepare(double sampleRate) noexcept {
    sampleRate_ = sampleRate;
    leftMix_.prepare(sampleRate_);
    rightMix_.prepare(sampleRate_);
    leftOut_.prepare(sampleRate_);
    rightOut_.prepare(sampleRate_);
    reset();
}

void SSLMixBus::reset() noexcept {
    leftMix_.reset(); rightMix_.reset();
    leftOut_.reset(); rightOut_.reset();
    busCurrentL_ = busCurrentR_ = 0.0;
}

void SSLMixBus::beginSample() noexcept {
    busCurrentL_ = 0.0;
    busCurrentR_ = 0.0;
}

void SSLMixBus::addChannel(double leftDigital, double rightDigital) noexcept {
    // Current contribution into 82E26 virtual-earth summing node through R50 15.04k.
    busCurrentL_ += digitalToVolts(leftDigital) / summingInputOhms();
    busCurrentR_ += digitalToVolts(rightDigital) / summingInputOhms();
}

void SSLMixBus::endSample(double& leftDigital, double& rightDigital) noexcept {
    const double mixL = leftMix_.processCurrent(busCurrentL_);
    const double mixR = rightMix_.processCurrent(busCurrentR_);
    const double outL = leftOut_.process(mixL);
    const double outR = rightOut_.process(mixR);
    leftDigital = voltsToDigital(outL);
    rightDigital = voltsToDigital(outR);
}

} // namespace caudio
