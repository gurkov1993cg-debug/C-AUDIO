#include "SSLChannel.h"
#include "SSLMixBus.h"
#include "MixerEngine.h"

#include <algorithm>
#include <cmath>
#include <iostream>
#include <vector>

using namespace caudio;

namespace {
constexpr double kPi = 3.14159265358979323846264338327950288;

bool finiteValue(double x){ return std::isfinite(x); }
#define REQUIRE(x) do { if(!(x)){ std::cerr << "FAIL: " #x " at line " << __LINE__ << "\n"; return 1; } } while(0)

struct ToneMeasurement {
    double gain = 0.0;
    double phaseRad = 0.0;
    double peak = 0.0;
};

ToneMeasurement measureMixBus(double fs, double frequency, double amplitude, int channelCount = 1) {
    SSLMixBus bus;
    bus.prepare(fs);
    const int warmup = static_cast<int>(fs * 0.25);
    const int measure = static_cast<int>(fs * 0.5);
    double sinAcc = 0.0, cosAcc = 0.0, peak = 0.0;

    for (int n = 0; n < warmup + measure; ++n) {
        const double phase = 2.0 * kPi * frequency * static_cast<double>(n) / fs;
        const double x = amplitude * std::sin(phase);
        bus.beginSample();
        // Matched-level channel-count test: each channel is 1/N so total bus drive is constant.
        const double each = x / static_cast<double>(channelCount);
        for (int ch = 0; ch < channelCount; ++ch) bus.addChannel(each, each);
        double yL = 0.0, yR = 0.0;
        bus.endSample(yL, yR);
        if (n >= warmup) {
            sinAcc += yL * std::sin(phase);
            cosAcc += yL * std::cos(phase);
            peak = std::max(peak, std::abs(yL));
        }
    }

    const double scale = 2.0 / static_cast<double>(measure);
    const double inPhase = sinAcc * scale;
    const double quadrature = cosAcc * scale;
    const double outAmplitude = std::sqrt(inPhase * inPhase + quadrature * quadrature);
    ToneMeasurement m;
    m.gain = outAmplitude / amplitude;
    m.phaseRad = std::atan2(quadrature, inPhase);
    m.peak = peak;
    return m;
}

double db(double x) { return 20.0 * std::log10(std::max(x, 1.0e-20)); }
}

int main(){
    // Existing channel smoke test.
    SSLChannel ch; ch.prepare(48000.0, 12345); ch.setInputTrimDb(0); ch.setFaderDb(0); ch.setPan(0);
    double l=0,r=0; double peak=0;
    for(int n=0;n<48000;++n){ const double x=0.1*std::sin(2.0*kPi*1000.0*n/48000.0); ch.process(x,l,r); REQUIRE(finiteValue(l)&&finiteValue(r)); peak=std::max(peak,std::max(std::abs(l),std::abs(r))); }
    REQUIRE(peak>0.02 && peak<0.2);

    const double centre = SSLChannel::panGainLeft(0.0);
    const double centreDb = db(centre);
    REQUIRE(std::abs(centreDb + 4.5) < 0.02);
    REQUIRE(SSLChannel::panGainLeft(-1.0) > 0.999);
    REQUIRE(SSLChannel::panGainRight(-1.0) < 1e-8);

    // 82E26 verified transimpedance ratio: R53/R50 = 15k/15.04k ≈ -0.99734.
    // 82E195 effective output macro is normalised for nominal 600R loading, so the low-level
    // programme-path magnitude should remain close to this ratio.
    const ToneMeasurement m1k = measureMixBus(48000.0, 1000.0, 0.01, 1);
    const double expectedMixMagnitude = SSLMixBus::feedbackOhms() / SSLMixBus::summingInputOhms();
    REQUIRE(std::abs(m1k.gain - expectedMixMagnitude) < 0.025);
    REQUIRE(m1k.peak < 0.02);

    // Real frequency measurement, not a printed PASS. The verified 100pF feedback and 220uF
    // programme-output coupling must not create an audible-band shelf.
    const ToneMeasurement m20 = measureMixBus(48000.0, 20.0, 0.01, 1);
    const ToneMeasurement m20k = measureMixBus(48000.0, 20000.0, 0.01, 1);
    REQUIRE(std::abs(db(m20.gain / m1k.gain)) < 0.30);
    REQUIRE(std::abs(db(m20k.gain / m1k.gain)) < 0.30);

    // Sample-rate invariance of the analogue mix/output network at representative frequencies.
    const ToneMeasurement a44 = measureMixBus(44100.0, 10000.0, 0.01, 1);
    const ToneMeasurement a48 = measureMixBus(48000.0, 10000.0, 0.01, 1);
    const ToneMeasurement a96 = measureMixBus(96000.0, 10000.0, 0.01, 1);
    REQUIRE(std::abs(db(a44.gain / a48.gain)) < 0.08);
    REQUIRE(std::abs(db(a96.gain / a48.gain)) < 0.08);

    // 1/10/50/100 channel matched-output test on the 82E26 virtual-earth current sum.
    const double g1 = measureMixBus(48000.0, 1000.0, 0.01, 1).gain;
    const double g10 = measureMixBus(48000.0, 1000.0, 0.01, 10).gain;
    const double g50 = measureMixBus(48000.0, 1000.0, 0.01, 50).gain;
    const double g100 = measureMixBus(48000.0, 1000.0, 0.01, 100).gain;
    REQUIRE(std::abs(db(g10/g1)) < 0.001);
    REQUIRE(std::abs(db(g50/g1)) < 0.001);
    REQUIRE(std::abs(db(g100/g1)) < 0.001);

    // Headroom boundary must be finite and bounded; this is an electrical rail macro, not a waveshaper.
    const ToneMeasurement hot = measureMixBus(48000.0, 1000.0, 1.5, 1);
    REQUIRE(finiteValue(hot.peak));
    REQUIRE(hot.peak < 1.1);

    // Mixer integration with the new 82E26 -> 82E195 master path.
    MixerEngine e; e.prepare(48000,512);
    AudioClip clip; clip.left.resize(4096,0.05); clip.right=clip.left; clip.stereo=false; clip.name="test";
    REQUIRE(e.setClip(0,std::move(clip))); e.track(0).format.store((int)TrackFormat::Mono); e.track(0).source.store((int)TrackSource::File); e.play();
    std::vector<double> o0(512),o1(512); double* outs[2]={o0.data(),o1.data()};
    e.process(nullptr,0,outs,2,512);
    double sum=0; for(double v:o0){ REQUIRE(finiteValue(v)); sum+=std::abs(v); } REQUIRE(sum>0.01);

    // Single SSL ON/OFF A/B: OFF bypasses SSL channel + 82E26/82E195 DSP while preserving controls digitally.
    MixerEngine ab; ab.prepare(48000,512);
    AudioClip abClip; abClip.left.resize(4096,0.05); abClip.right=abClip.left; abClip.stereo=false; abClip.name="ab";
    REQUIRE(ab.setClip(0,std::move(abClip)));
    ab.track(0).format.store((int)TrackFormat::Mono); ab.track(0).source.store((int)TrackSource::File);
    ab.track(0).inputTrimDb.store(0.0); ab.track(0).faderDb.store(0.0); ab.track(0).pan.store(0.0);
    ab.setSSLEnabled(false); REQUIRE(!ab.sslEnabled()); ab.play();
    std::vector<double> ab0(512),ab1(512); double* abOut[2]={ab0.data(),ab1.data()};
    ab.process(nullptr,0,abOut,2,512);
    const double expectedDry = 0.05 * SSLChannel::panGainLeft(0.0);
    REQUIRE(std::abs(ab0[400] - expectedDry) < 1e-12);
    REQUIRE(std::abs(ab1[400] - expectedDry) < 1e-12);
    ab.setSSLEnabled(true); REQUIRE(ab.sslEnabled());
    std::fill(ab0.begin(),ab0.end(),0.0); std::fill(ab1.begin(),ab1.end(),0.0);
    ab.process(nullptr,0,abOut,2,512);
    REQUIRE(finiteValue(ab0[400]) && finiteValue(ab1[400]));

    // Mute: because the new 82E195 output has real coupling state, allow the analogue tail to decay,
    // then require silence rather than demanding an impossible instantaneous capacitor reset.
    for(std::size_t i=0;i<MixerEngine::kTrackCount;++i) e.track(i).mute.store(true);
    for(int b=0;b<1200;++b) {
        std::fill(o0.begin(),o0.end(),0.0); std::fill(o1.begin(),o1.end(),0.0);
        e.process(nullptr,0,outs,2,512);
    }
    double muted=0; for(double v:o0) muted+=std::abs(v); REQUIRE(muted<1e-7);


    std::cout << "82E26/82E195 metrics: "
              << "1kHz=" << db(m1k.gain) << " dB, "
              << "20Hz rel=" << db(m20.gain/m1k.gain) << " dB, "
              << "20kHz rel=" << db(m20k.gain/m1k.gain) << " dB\n";
    std::cout << "Sample-rate 10kHz delta: 44.1/48=" << db(a44.gain/a48.gain)
              << " dB, 96/48=" << db(a96.gain/a48.gain) << " dB\n";
    std::cout << "Matched channel-count delta: 10=" << db(g10/g1)
              << " dB, 50=" << db(g50/g1)
              << " dB, 100=" << db(g100/g1) << " dB\n";
    std::cout << "Hot-drive peak=" << hot.peak << " FS\n";
    std::cout << "C-AUDIO engine + 82E26/82E195 measured tests passed\n";
    std::cout << "82E195 status: " << SSLMixBus{}.programOutputModelType() << "\n";
    return 0;
}
