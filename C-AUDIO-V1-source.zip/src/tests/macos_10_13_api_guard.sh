#!/bin/bash
set -euo pipefail
root="${1:-.}"
# APIs known to break the High Sierra target at runtime.
if grep -R -n --include='*.mm' --include='*.m' --include='*.h' 'separatorColor' "$root/app/macos"; then
  echo 'FAIL: NSColor.separatorColor requires newer macOS and crashes on 10.13'
  exit 1
fi
echo 'PASS: macOS 10.13 AppKit guard'
