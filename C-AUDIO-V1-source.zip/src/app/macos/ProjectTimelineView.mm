#import "ProjectTimelineView.h"
#import "CAThemeControls.h"
#import "../../engine/MixerEngine.h"

#include <algorithm>
#include <cmath>

using namespace caudio;

namespace {
constexpr CGFloat kRulerHeight = 28.0;
constexpr CGFloat kLaneHeight = 64.0;
constexpr CGFloat kPixelsPerSecond = 105.0;
constexpr CGFloat kMinimumWidth = 1800.0;

void drawWaveform(const AudioClip& clip, bool right, NSRect rect, NSColor* color) {
    const std::vector<double>& data = (right && clip.stereo) ? clip.right : clip.left;
    if (data.empty() || rect.size.width <= 2.0 || rect.size.height <= 2.0) return;
    const CGFloat mid = NSMidY(rect);
    const CGFloat amp = NSHeight(rect) * 0.42;
    const std::size_t pixels = static_cast<std::size_t>(std::max<CGFloat>(1.0, NSWidth(rect)));
    const double framesPerPixel = static_cast<double>(data.size()) / static_cast<double>(pixels);
    NSBezierPath* p = [NSBezierPath bezierPath];
    p.lineWidth = 1.0;
    [color setStroke];
    for (std::size_t px = 0; px < pixels; ++px) {
        const std::size_t begin = std::min<std::size_t>(data.size(), static_cast<std::size_t>(std::floor(px * framesPerPixel)));
        const std::size_t end = std::min<std::size_t>(data.size(), std::max<std::size_t>(begin + 1, static_cast<std::size_t>(std::ceil((px + 1) * framesPerPixel))));
        double peak = 0.0;
        for (std::size_t i = begin; i < end; ++i) peak = std::max(peak, std::abs(data[i]));
        const CGFloat x = NSMinX(rect) + static_cast<CGFloat>(px);
        const CGFloat h = static_cast<CGFloat>(std::min(1.0, peak)) * amp;
        [p moveToPoint:NSMakePoint(x, mid - h)];
        [p lineToPoint:NSMakePoint(x, mid + h)];
    }
    [p stroke];
}
}

@implementation ProjectTimelineView {
    MixerEngine* _engine;
    NSUInteger _selectedTrack;
}

- (instancetype)initWithFrame:(NSRect)frame engine:(MixerEngine*)engine {
    self = [super initWithFrame:frame];
    if (self) { _engine = engine; _selectedTrack = 0; self.wantsLayer = YES; }
    return self;
}

- (BOOL)isFlipped { return YES; }

- (void)setSelectedTrackIndex:(NSUInteger)index {
    _selectedTrack = std::min<NSUInteger>(index, MixerEngine::kTrackCount - 1);
    [self setNeedsDisplay:YES];
}

- (void)refreshProjectExtent {
    if (!_engine) return;
    const double fs = std::max(1.0, _engine->sampleRate());
    const double endSeconds = static_cast<double>(_engine->projectEndFrame()) / fs;
    const CGFloat wanted = std::max(kMinimumWidth, static_cast<CGFloat>((endSeconds + 8.0) * kPixelsPerSecond));
    NSSize size = self.frame.size;
    size.width = wanted;
    size.height = kRulerHeight + kLaneHeight * MixerEngine::kTrackCount;
    [self setFrameSize:size];
    [self setNeedsDisplay:YES];
}

- (void)drawRect:(NSRect)dirtyRect {
    [super drawRect:dirtyRect];
    [CAInsetColor() setFill]; NSRectFill(dirtyRect);
    if (!_engine) return;

    const double fs = std::max(1.0, _engine->sampleRate());
    NSDictionary* rulerAttrs = @{NSFontAttributeName:[NSFont systemFontOfSize:9.0], NSForegroundColorAttributeName:CAMutedTextColor()};
    NSDictionary* titleAttrs = @{NSFontAttributeName:[NSFont boldSystemFontOfSize:9.0], NSForegroundColorAttributeName:CATextColor()};

    // Ruler/header.
    [CAColor(0.137255,0.137255,0.149020,1.0) setFill]; NSRectFill(NSMakeRect(0,0,self.bounds.size.width,kRulerHeight));
    [[CABorderColor() colorWithAlphaComponent:0.70] setStroke];
    const NSInteger maxSec = static_cast<NSInteger>(std::ceil(self.bounds.size.width / kPixelsPerSecond));
    for (NSInteger sec = 0; sec <= maxSec; ++sec) {
        const CGFloat x = static_cast<CGFloat>(sec) * kPixelsPerSecond;
        NSBezierPath* tick=[NSBezierPath bezierPath]; tick.lineWidth=0.7;
        [tick moveToPoint:NSMakePoint(x+0.5,12.0)]; [tick lineToPoint:NSMakePoint(x+0.5,self.bounds.size.height)]; [tick stroke];
        [[NSString stringWithFormat:@"%ld",(long)(sec+1)] drawAtPoint:NSMakePoint(x+5.0,4.0) withAttributes:rulerAttrs];
    }

    for (NSUInteger i=0;i<MixerEngine::kTrackCount;++i) {
        const CGFloat y=kRulerHeight+static_cast<CGFloat>(i)*kLaneHeight;
        NSColor* tc=CATrackColor(i);
        NSColor* laneFill=(i==_selectedTrack)?CAColor(0.196078,0.196078,0.215686,1.0):CAColor(0.117647,0.117647,0.125490,1.0);
        [laneFill setFill]; NSRectFill(NSMakeRect(0,y,self.bounds.size.width,kLaneHeight-1.0));
        [[CABorderColor() colorWithAlphaComponent:0.50] setStroke]; NSFrameRect(NSMakeRect(0,y,self.bounds.size.width,kLaneHeight));

        const MixerEngine::Track& t=_engine->track(i);
        if(t.clip.frames()==0) continue;
        const double startSec=static_cast<double>(_engine->eventStartFrame(i))/fs;
        const double lenSec=static_cast<double>(t.clip.frames())/fs;
        const CGFloat x=static_cast<CGFloat>(startSec*kPixelsPerSecond);
        const CGFloat w=std::max<CGFloat>(10.0,static_cast<CGFloat>(lenSec*kPixelsPerSecond));
        NSRect er=NSMakeRect(x+1.0,y+4.0,w-2.0,kLaneHeight-8.0);
        NSBezierPath* ep=[NSBezierPath bezierPathWithRoundedRect:er xRadius:2.0 yRadius:2.0];
        [[tc colorWithAlphaComponent:(i==_selectedTrack?0.28:0.17)] setFill]; [ep fill];
        [[tc colorWithAlphaComponent:0.85] setStroke]; ep.lineWidth=(i==_selectedTrack?1.2:0.7); [ep stroke];

        if (t.clip.stereo) {
            const CGFloat half=NSHeight(er)*0.5;
            drawWaveform(t.clip,false,NSMakeRect(NSMinX(er)+3,NSMinY(er)+1,NSWidth(er)-6,half-2),[tc colorWithAlphaComponent:0.95]);
            drawWaveform(t.clip,true,NSMakeRect(NSMinX(er)+3,NSMinY(er)+half+1,NSWidth(er)-6,half-2),[tc colorWithAlphaComponent:0.95]);
        } else {
            drawWaveform(t.clip,false,NSInsetRect(er,3.0,4.0),[tc colorWithAlphaComponent:0.95]);
        }
        NSString* title=t.clip.name.empty()?@"Audio Event":[NSString stringWithUTF8String:t.clip.name.c_str()];
        [title drawAtPoint:NSMakePoint(NSMinX(er)+6.0,NSMinY(er)+3.0) withAttributes:titleAttrs];
    }

    const double playSeconds=static_cast<double>(_engine->playhead())/fs;
    const CGFloat px=static_cast<CGFloat>(playSeconds*kPixelsPerSecond);
    [CATextColor() setStroke]; NSBezierPath* cursor=[NSBezierPath bezierPath]; cursor.lineWidth=1.0;
    [cursor moveToPoint:NSMakePoint(px,0)]; [cursor lineToPoint:NSMakePoint(px,self.bounds.size.height)]; [cursor stroke];
    [CATextColor() setFill]; NSBezierPath* tri=[NSBezierPath bezierPath];
    [tri moveToPoint:NSMakePoint(px-6,0)];[tri lineToPoint:NSMakePoint(px+6,0)];[tri lineToPoint:NSMakePoint(px,9)];[tri closePath];[tri fill];
}

- (void)mouseDown:(NSEvent*)event {
    if(!_engine||_engine->isRecording())return;
    const NSPoint p=[self convertPoint:event.locationInWindow fromView:nil]; if(p.x<0)return;
    const double seconds=static_cast<double>(p.x/kPixelsPerSecond);
    _engine->setPlayhead(static_cast<std::uint64_t>(std::llround(seconds*_engine->sampleRate())));
    [self setNeedsDisplay:YES];
}
@end
