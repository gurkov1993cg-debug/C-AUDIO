#import "AppDelegate.h"
#import "CoreAudioDuplex.h"
#import "AudioFileLoader.h"
#import "ProjectTimelineView.h"
#import "CAThemeControls.h"
#import "../../engine/MixerEngine.h"
#import "../../engine/ProjectFile.h"

#import <Cocoa/Cocoa.h>
#import <QuartzCore/QuartzCore.h>

#include <array>
#include <algorithm>
#include <cmath>
#include <memory>
#include <string>
#include <vector>

using namespace caudio;

@interface AppDelegate ()
@property(strong) NSWindow* window;
@property(strong) NSPopUpButton* devicePopup;
@property(strong) NSTextField* statusLabel;
@property(strong) NSTextField* positionLabel;
@property(strong) NSTextField* masterMeter;
@property(strong) CAFlatButton* sslButton;
@property(strong) NSPopUpButton* masterType;
@property(strong) NSPopUpButton* masterOutA;
@property(strong) NSPopUpButton* masterOutB;
@end

@implementation AppDelegate {
    MixerEngine _engine;
    std::unique_ptr<CoreAudioDuplex> _audio;
    std::vector<AudioDeviceInfo> _devices;
    NSInteger _selectedTrack;
    NSTimer* _meterTimer;

    ProjectTimelineView* _timeline;
    NSScrollView* _timelineScroll;

    std::array<CAFlatButton*, MixerEngine::kTrackCount> _trackSelect;
    std::array<CAFlatButton*, MixerEngine::kTrackCount> _trackArm;
    std::array<CAFlatButton*, MixerEngine::kTrackCount> _trackMute;
    std::array<CAFlatButton*, MixerEngine::kTrackCount> _trackSolo;

    NSTextField* _insName;
    NSTextField* _insFileLabel;
    NSPopUpButton* _insType;
    NSPopUpButton* _insSource;
    NSPopUpButton* _insInputA;
    NSPopUpButton* _insInputB;
    CAFlatButton* _insArm;
    CAFlatButton* _insMon;
    CAFlatButton* _insMute;
    CAFlatButton* _insSolo;
    CAKnob* _insTrim;
    CAFader* _insFader;
    CAKnob* _insPan;
    CAMeterView* _insMeter;

    std::array<NSTextField*, MixerEngine::kTrackCount> _mixNames;
    std::array<CAFader*, MixerEngine::kTrackCount> _mixFaders;
    std::array<CAFlatButton*, MixerEngine::kTrackCount> _mixMute;
    std::array<CAFlatButton*, MixerEngine::kTrackCount> _mixSolo;
    std::array<CAMeterView*, MixerEngine::kTrackCount> _mixMeters;
    std::array<CAKnob*, MixerEngine::kTrackCount> _mixPans;

    CAKnob* _masterKnob;
    CAKnob* _topMasterKnob;
    CAStereoMeterView* _masterStereoMeter;
    CAStereoMeterView* _topStereoMeter;
}

#pragma mark - Theme helpers

- (NSTextField*)label:(NSString*)text frame:(NSRect)frame bold:(BOOL)bold {
    NSTextField* l=[[NSTextField alloc] initWithFrame:frame];
    l.stringValue=text; l.editable=NO; l.selectable=NO; l.bordered=NO; l.drawsBackground=NO;
    l.textColor=bold?CATextColor():CAMutedTextColor();
    l.font=bold?[NSFont boldSystemFontOfSize:11.0]:[NSFont systemFontOfSize:10.0];
    l.lineBreakMode=NSLineBreakByTruncatingTail;
    return l;
}

- (NSTextField*)inputField:(NSRect)frame {
    NSTextField* f=[[NSTextField alloc] initWithFrame:frame];
    f.bordered=NO; f.bezeled=NO; f.drawsBackground=YES; f.backgroundColor=CAInsetColor(); f.textColor=CATextColor();
    f.font=[NSFont systemFontOfSize:11.0]; f.focusRingType=NSFocusRingTypeNone; f.wantsLayer=YES;
    f.layer.borderWidth=1.0; f.layer.borderColor=CABorderColor().CGColor; f.layer.cornerRadius=3.0;
    return f;
}

- (CAFlatButton*)button:(NSString*)text frame:(NSRect)frame action:(SEL)action {
    CAFlatButton* b=[[CAFlatButton alloc] initWithFrame:frame];
    b.title=text; b.target=self; b.action=action; b.buttonType=NSMomentaryPushInButton;
    return b;
}

- (CAFlatButton*)toggle:(NSString*)text frame:(NSRect)frame action:(SEL)action tag:(NSInteger)tag {
    CAFlatButton* b=[self button:text frame:frame action:action];
    b.buttonType=NSPushOnPushOffButton; b.tag=tag; return b;
}

- (NSPopUpButton*)popup:(NSRect)frame action:(SEL)action tag:(NSInteger)tag {
    NSPopUpButton* p=[[NSPopUpButton alloc] initWithFrame:frame pullsDown:NO];
    p.target=self; p.action=action; p.tag=tag; p.font=[NSFont systemFontOfSize:10.5];
    p.appearance=[NSAppearance appearanceNamed:NSAppearanceNameVibrantDark];
    p.controlSize=NSSmallControlSize; p.wantsLayer=YES; p.layer.cornerRadius=3.0;
    return p;
}

- (CAKnob*)knob:(NSRect)frame min:(double)min max:(double)max value:(double)value action:(SEL)action tag:(NSInteger)tag color:(NSColor*)color {
    CAKnob* k=[[CAKnob alloc] initWithFrame:frame]; k.minValue=min; k.maxValue=max; k.doubleValue=value; k.target=self; k.action=action; k.tag=tag; k.accentColor=color; return k;
}

- (CAFader*)fader:(NSRect)frame min:(double)min max:(double)max value:(double)value action:(SEL)action tag:(NSInteger)tag color:(NSColor*)color {
    CAFader* f=[[CAFader alloc] initWithFrame:frame]; f.minValue=min; f.maxValue=max; f.doubleValue=value; f.target=self; f.action=action; f.tag=tag; f.accentColor=color; return f;
}

- (CAPanelView*)panel:(NSRect)frame title:(NSString*)title {
    CAPanelView* p=[[CAPanelView alloc] initWithFrame:frame]; p.title=title; return p;
}

- (void)addSmallCaption:(NSString*)text to:(NSView*)view frame:(NSRect)frame {
    NSTextField* l=[self label:text frame:frame bold:NO]; l.alignment=NSTextAlignmentCenter; [view addSubview:l];
}

#pragma mark - App setup

- (void)applicationDidFinishLaunching:(NSNotification*)notification {
    (void)notification;
    _selectedTrack=0;
    _trackSelect.fill(nil); _trackArm.fill(nil); _trackMute.fill(nil); _trackSolo.fill(nil);
    _mixNames.fill(nil); _mixFaders.fill(nil); _mixMute.fill(nil); _mixSolo.fill(nil); _mixMeters.fill(nil); _mixPans.fill(nil);
    _audio.reset(new CoreAudioDuplex(_engine));

    const NSRect contentRect=NSMakeRect(0,0,1648,900);
    self.window=[[NSWindow alloc] initWithContentRect:contentRect
                                           styleMask:(NSWindowStyleMaskTitled|NSWindowStyleMaskClosable|NSWindowStyleMaskMiniaturizable|NSWindowStyleMaskResizable)
                                             backing:NSBackingStoreBuffered defer:NO];
    self.window.title=@"C-AUDIO V1 — Project Window";
    self.window.appearance=[NSAppearance appearanceNamed:NSAppearanceNameVibrantDark];
    self.window.backgroundColor=CABackgroundColor();
    self.window.minSize=NSMakeSize(1450,820);
    [self.window center];

    CAWorkspaceView* root=[[CAWorkspaceView alloc] initWithFrame:contentRect];
    root.autoresizingMask=NSViewWidthSizable|NSViewHeightSizable;
    self.window.contentView=root;

    // Top identity/menu line.
    NSTextField* brand=[self label:@"C-AUDIO" frame:NSMakeRect(20,866,130,24) bold:YES];
    brand.font=[NSFont boldSystemFontOfSize:18.0]; brand.textColor=CATextColor(); [root addSubview:brand];
    NSArray<NSString*>* menus=@[@"File",@"Edit",@"Project",@"Audio",@"MIDI",@"View",@"Help"];
    CGFloat mx=176.0;
    for(NSString* m in menus){ NSTextField* l=[self label:m frame:NSMakeRect(mx,869,58,18) bold:NO]; l.textColor=CATextColor(); [root addSubview:l]; mx+=63.0; }
    NSTextField* sys=[self label:@"64-bit engine" frame:NSMakeRect(1490,869,130,18) bold:NO]; sys.alignment=NSTextAlignmentRight; [root addSubview:sys];

    // Tool/transport bar.
    CAPanelView* toolbar=[self panel:NSMakeRect(8,796,1632,62) title:nil]; [root addSubview:toolbar];
    NSArray<NSString*>* toolGlyphs=@[@"↖",@"✎",@"✂",@"⌁",@"□"];
    CGFloat tx=12.0;
    for(NSUInteger i=0;i<toolGlyphs.count;++i){ CAFlatButton* b=[self button:toolGlyphs[i] frame:NSMakeRect(tx,12,48,38) action:NULL]; b.font=[NSFont systemFontOfSize:16.0]; b.enabled=(i==0); if(i==0)b.state=NSControlStateValueOn; [toolbar addSubview:b]; tx+=52.0; }

    CAFlatButton* toStart=[self button:@"◀|" frame:NSMakeRect(320,12,48,38) action:@selector(returnToStart:)]; [toolbar addSubview:toStart];
    CAFlatButton* play=[self button:@"▶" frame:NSMakeRect(372,12,48,38) action:@selector(play:)]; play.accentColor=CAGreenColor(); [toolbar addSubview:play];
    CAFlatButton* stop=[self button:@"■" frame:NSMakeRect(424,12,48,38) action:@selector(stop:)]; [toolbar addSubview:stop];
    CAFlatButton* rec=[self button:@"●" frame:NSMakeRect(476,12,48,38) action:@selector(record:)]; rec.dangerStyle=YES; [toolbar addSubview:rec];
    CAFlatButton* loop=[self button:@"↻" frame:NSMakeRect(528,12,48,38) action:NULL]; loop.enabled=NO; [toolbar addSubview:loop];

    self.positionLabel=[self label:@"00:00.000" frame:NSMakeRect(610,13,190,36) bold:YES];
    self.positionLabel.font=[NSFont systemFontOfSize:24.0]; self.positionLabel.textColor=CATextColor(); self.positionLabel.alignment=NSTextAlignmentCenter; [toolbar addSubview:self.positionLabel];
    NSTextField* fmt=[self label:@"BAR  |  BEAT  |  TICK" frame:NSMakeRect(628,4,155,12) bold:NO]; fmt.alignment=NSTextAlignmentCenter; fmt.font=[NSFont systemFontOfSize:8.0]; [toolbar addSubview:fmt];

    CAFlatButton* open=[self button:@"OPEN" frame:NSMakeRect(825,12,66,38) action:@selector(openProject:)]; [toolbar addSubview:open];
    CAFlatButton* save=[self button:@"SAVE" frame:NSMakeRect(895,12,66,38) action:@selector(saveProject:)]; [toolbar addSubview:save];
    NSTextField* snap=[self label:@"SNAP" frame:NSMakeRect(988,32,40,14) bold:NO]; [toolbar addSubview:snap];
    NSPopUpButton* snapPopup=[self popup:NSMakeRect(1030,16,80,28) action:NULL tag:0]; [snapPopup addItemsWithTitles:@[@"1/8",@"1/16",@"1/4"]]; snapPopup.enabled=NO; [toolbar addSubview:snapPopup];
    self->_topStereoMeter=[[CAStereoMeterView alloc] initWithFrame:NSMakeRect(1260,15,220,32)]; [toolbar addSubview:self->_topStereoMeter];
    NSTextField* meterScale=[self label:@"-36         -24          -12            0" frame:NSMakeRect(1258,3,225,10) bold:NO]; meterScale.font=[NSFont systemFontOfSize:7.5]; [toolbar addSubview:meterScale];
    _topMasterKnob=[self knob:NSMakeRect(1510,6,55,48) min:-60 max:10 value:0 action:@selector(masterChanged:) tag:0 color:CAAccentColor()]; [toolbar addSubview:_topMasterKnob];
    [self addSmallCaption:@"MAIN" to:toolbar frame:NSMakeRect(1508,2,58,10)];

    // Inspector.
    CAPanelView* inspector=[self panel:NSMakeRect(8,36,242,752) title:@"INSPECTOR"]; [root addSubview:inspector];
    _insName=[self inputField:NSMakeRect(12,698,218,28)]; _insName.target=self; _insName.action=@selector(renameTrack:); [inspector addSubview:_insName];
    _insMute=[self toggle:@"M" frame:NSMakeRect(12,660,48,28) action:@selector(inspectorMuteChanged:) tag:0]; [inspector addSubview:_insMute];
    _insSolo=[self toggle:@"S" frame:NSMakeRect(64,660,48,28) action:@selector(inspectorSoloChanged:) tag:0]; _insSolo.accentColor=CAYellowColor(); [inspector addSubview:_insSolo];
    _insArm=[self toggle:@"R" frame:NSMakeRect(116,660,48,28) action:@selector(inspectorArmChanged:) tag:0]; _insArm.dangerStyle=YES; [inspector addSubview:_insArm];
    _insMon=[self toggle:@"MON" frame:NSMakeRect(168,660,62,28) action:@selector(inspectorMonitorChanged:) tag:0]; [inspector addSubview:_insMon];

    _insTrim=[self knob:NSMakeRect(16,574,72,72) min:-20 max:20 value:0 action:@selector(inspectorTrimChanged:) tag:0 color:CAAccentColor()]; [inspector addSubview:_insTrim];
    [self addSmallCaption:@"TRIM" to:inspector frame:NSMakeRect(18,560,68,14)];
    _insPan=[self knob:NSMakeRect(98,574,72,72) min:-1 max:1 value:0 action:@selector(inspectorPanChanged:) tag:0 color:CAAccentColor()]; [inspector addSubview:_insPan];
    [self addSmallCaption:@"PAN" to:inspector frame:NSMakeRect(100,560,68,14)];
    _insMeter=[[CAMeterView alloc] initWithFrame:NSMakeRect(190,566,20,82)]; [inspector addSubview:_insMeter];
    [self addSmallCaption:@"dB" to:inspector frame:NSMakeRect(180,552,40,12)];

    NSTextField* routing=[self label:@"ROUTING" frame:NSMakeRect(12,525,100,16) bold:NO]; routing.textColor=CATextColor(); [inspector addSubview:routing];
    _insType=[self popup:NSMakeRect(12,493,104,26) action:@selector(inspectorTypeChanged:) tag:0]; [_insType addItemsWithTitles:@[@"MONO",@"STEREO"]]; [inspector addSubview:_insType];
    _insSource=[self popup:NSMakeRect(122,493,108,26) action:@selector(inspectorSourceChanged:) tag:0]; [_insSource addItemsWithTitles:@[@"FILE",@"INPUT"]]; [inspector addSubview:_insSource];
    _insInputA=[self popup:NSMakeRect(12,459,104,26) action:@selector(inspectorInputAChanged:) tag:0]; [inspector addSubview:_insInputA];
    _insInputB=[self popup:NSMakeRect(122,459,108,26) action:@selector(inspectorInputBChanged:) tag:0]; [inspector addSubview:_insInputB];
    NSPopUpButton* route=[self popup:NSMakeRect(12,425,218,26) action:NULL tag:0]; [route addItemWithTitle:@"Stereo Out"]; route.enabled=NO; [inspector addSubview:route];

    NSTextField* insertHead=[self label:@"CHANNEL PATH" frame:NSMakeRect(12,393,120,16) bold:NO]; insertHead.textColor=CATextColor(); [inspector addSubview:insertHead];
    CAFlatButton* sslPath=[self button:@"C-AUDIO SSL CHANNEL" frame:NSMakeRect(12,358,218,28) action:NULL]; sslPath.enabled=NO; sslPath.accentColor=CAAccentColor(); [inspector addSubview:sslPath];
    NSTextField* frozen=[self label:@"Frozen HF-fix stage • EQ/Dynamics OFF" frame:NSMakeRect(14,337,212,16) bold:NO]; [inspector addSubview:frozen];

    NSTextField* clipHead=[self label:@"AUDIO EVENT" frame:NSMakeRect(12,305,110,16) bold:NO]; clipHead.textColor=CATextColor(); [inspector addSubview:clipHead];
    CAFlatButton* imp=[self button:@"IMPORT AUDIO" frame:NSMakeRect(12,270,218,28) action:@selector(importAudio:)]; [inspector addSubview:imp];
    _insFileLabel=[self label:@"No event" frame:NSMakeRect(14,248,212,16) bold:NO]; _insFileLabel.lineBreakMode=NSLineBreakByTruncatingMiddle; [inspector addSubview:_insFileLabel];

    NSTextField* fadHead=[self label:@"FADER" frame:NSMakeRect(12,214,80,16) bold:NO]; fadHead.textColor=CATextColor(); [inspector addSubview:fadHead];
    _insFader=[self fader:NSMakeRect(22,40,72,164) min:-60 max:10 value:0 action:@selector(inspectorFaderChanged:) tag:0 color:CAAccentColor()]; [inspector addSubview:_insFader];
    [self addSmallCaption:@"0.0 dB" to:inspector frame:NSMakeRect(12,20,94,16)];

    // Track list.
    CAPanelView* trackList=[self panel:NSMakeRect(258,380,286,408) title:@"TRACKS"]; [root addSubview:trackList];
    CAFlatButton* addTrack=[self button:@"+" frame:NSMakeRect(244,370,30,26) action:NULL]; addTrack.enabled=NO; [trackList addSubview:addTrack];
    for(NSUInteger i=0;i<MixerEngine::kTrackCount;++i){
        const CGFloat y=322.0-static_cast<CGFloat>(i)*53.0;
        NSView* row=[[NSView alloc] initWithFrame:NSMakeRect(10,y,266,48)]; row.wantsLayer=YES; row.layer.backgroundColor=CAInsetColor().CGColor; row.layer.borderColor=[CABorderColor() colorWithAlphaComponent:0.6].CGColor; row.layer.borderWidth=1.0; [trackList addSubview:row];
        NSView* stripe=[[NSView alloc] initWithFrame:NSMakeRect(0,0,28,48)]; stripe.wantsLayer=YES; stripe.layer.backgroundColor=[CATrackColor(i) colorWithAlphaComponent:0.75].CGColor; [row addSubview:stripe];
        NSTextField* num=[self label:[NSString stringWithFormat:@"%lu",(unsigned long)(i+1)] frame:NSMakeRect(0,14,28,18) bold:YES]; num.alignment=NSTextAlignmentCenter; num.textColor=CATextColor(); [row addSubview:num];
        _trackSelect[i]=[self button:[NSString stringWithFormat:@"Audio %lu",(unsigned long)(i+1)] frame:NSMakeRect(32,16,132,28) action:@selector(selectTrack:)]; _trackSelect[i].tag=(NSInteger)i; _trackSelect[i].accentColor=CATrackColor(i); [row addSubview:_trackSelect[i]];
        _trackArm[i]=[self toggle:@"R" frame:NSMakeRect(168,19,28,24) action:@selector(trackListArmChanged:) tag:(NSInteger)i]; _trackArm[i].dangerStyle=YES; [row addSubview:_trackArm[i]];
        _trackMute[i]=[self toggle:@"M" frame:NSMakeRect(198,19,28,24) action:@selector(trackListMuteChanged:) tag:(NSInteger)i]; [row addSubview:_trackMute[i]];
        _trackSolo[i]=[self toggle:@"S" frame:NSMakeRect(228,19,28,24) action:@selector(trackListSoloChanged:) tag:(NSInteger)i]; _trackSolo[i].accentColor=CAYellowColor(); [row addSubview:_trackSolo[i]];
    }

    // Project timeline.
    CAPanelView* project=[self panel:NSMakeRect(552,380,1088,408) title:@"PROJECT"]; [root addSubview:project];
    _timelineScroll=[[NSScrollView alloc] initWithFrame:NSMakeRect(10,10,1068,362)]; _timelineScroll.hasHorizontalScroller=YES; _timelineScroll.hasVerticalScroller=YES; _timelineScroll.autohidesScrollers=YES; _timelineScroll.drawsBackground=YES; _timelineScroll.backgroundColor=CAInsetColor();
    _timeline=[[ProjectTimelineView alloc] initWithFrame:NSMakeRect(0,0,1500,318) engine:&_engine]; _timelineScroll.documentView=_timeline; [project addSubview:_timelineScroll];

    // Lower MixConsole.
    CAPanelView* mixer=[self panel:NSMakeRect(258,36,1070,336) title:@"MIXCONSOLE"]; [root addSubview:mixer];
    const CGFloat stripW=166.0, gap=7.0, startX=10.0;
    for(NSUInteger i=0;i<MixerEngine::kTrackCount;++i){
        const CGFloat x=startX+static_cast<CGFloat>(i)*(stripW+gap);
        CAPanelView* strip=[self panel:NSMakeRect(x,12,stripW,290) title:nil]; strip.topAccentColor=CATrackColor(i); [mixer addSubview:strip];
        _mixNames[i]=[self label:[NSString stringWithFormat:@"Audio %lu",(unsigned long)(i+1)] frame:NSMakeRect(8,254,150,20) bold:YES]; _mixNames[i].alignment=NSTextAlignmentCenter; _mixNames[i].textColor=CATextColor(); [strip addSubview:_mixNames[i]];
        NSTextField* bus=[self label:@"Stereo Out" frame:NSMakeRect(8,235,150,14) bold:NO]; bus.alignment=NSTextAlignmentCenter; bus.font=[NSFont systemFontOfSize:8.5]; [strip addSubview:bus];
        _mixPans[i]=[self knob:NSMakeRect(53,182,60,52) min:-1 max:1 value:0 action:@selector(mixPanChanged:) tag:(NSInteger)i color:CATrackColor(i)]; [strip addSubview:_mixPans[i]];
        [self addSmallCaption:@"PAN" to:strip frame:NSMakeRect(56,174,54,12)];
        _mixFaders[i]=[self fader:NSMakeRect(32,40,60,132) min:-60 max:10 value:0 action:@selector(mixFaderChanged:) tag:(NSInteger)i color:CATrackColor(i)]; [strip addSubview:_mixFaders[i]];
        _mixMeters[i]=[[CAMeterView alloc] initWithFrame:NSMakeRect(105,48,20,120)]; [strip addSubview:_mixMeters[i]];
        NSTextField* db=[self label:@"0.0 dB" frame:NSMakeRect(20,22,116,16) bold:NO]; db.alignment=NSTextAlignmentCenter; db.tag=100+(NSInteger)i; [strip addSubview:db];
        _mixMute[i]=[self toggle:@"M" frame:NSMakeRect(32,4,46,24) action:@selector(mixMuteChanged:) tag:(NSInteger)i]; [strip addSubview:_mixMute[i]];
        _mixSolo[i]=[self toggle:@"S" frame:NSMakeRect(88,4,46,24) action:@selector(mixSoloChanged:) tag:(NSInteger)i]; _mixSolo[i].accentColor=CAYellowColor(); [strip addSubview:_mixSolo[i]];
    }

    // Output/control section.
    CAPanelView* outPanel=[self panel:NSMakeRect(1336,36,304,336) title:@"OUTPUT"]; outPanel.topAccentColor=CAAccentColor(); [root addSubview:outPanel];
    self.masterType=[self popup:NSMakeRect(14,266,134,27) action:@selector(masterTypeChanged:) tag:0]; [self.masterType addItemsWithTitles:@[@"STEREO",@"MONO"]]; [outPanel addSubview:self.masterType];
    self.masterOutA=[self popup:NSMakeRect(14,232,134,27) action:@selector(masterOutChanged:) tag:0]; [outPanel addSubview:self.masterOutA];
    self.masterOutB=[self popup:NSMakeRect(154,232,134,27) action:@selector(masterOutChanged:) tag:1]; [outPanel addSubview:self.masterOutB];
    _masterKnob=[self knob:NSMakeRect(48,126,92,92) min:-60 max:10 value:0 action:@selector(masterChanged:) tag:0 color:CAAccentColor()]; [outPanel addSubview:_masterKnob];
    [self addSmallCaption:@"MAIN" to:outPanel frame:NSMakeRect(58,112,72,14)];
    _masterStereoMeter=[[CAStereoMeterView alloc] initWithFrame:NSMakeRect(204,88,42,132)]; [outPanel addSubview:_masterStereoMeter];
    self.masterMeter=[self label:@"L -∞   R -∞" frame:NSMakeRect(22,84,160,18) bold:YES]; self.masterMeter.alignment=NSTextAlignmentCenter; [outPanel addSubview:self.masterMeter];
    NSTextField* outInfo=[self label:@"C-AUDIO engine → SSL path → hardware output" frame:NSMakeRect(18,52,268,22) bold:NO]; outInfo.alignment=NSTextAlignmentCenter; [outPanel addSubview:outInfo];

    // Status strip.
    CAPanelView* status=[self panel:NSMakeRect(8,4,1632,28) title:nil]; [root addSubview:status];
    NSTextField* audio=[self label:@"AUDIO" frame:NSMakeRect(12,6,42,16) bold:YES]; [status addSubview:audio];
    self.devicePopup=[self popup:NSMakeRect(58,2,330,24) action:@selector(deviceChanged:) tag:0]; [status addSubview:self.devicePopup];
    self.statusLabel=[self label:@"Opening CoreAudio..." frame:NSMakeRect(410,6,580,16) bold:NO]; [status addSubview:self.statusLabel];
    NSTextField* sslText=[self label:@"SSL PATH" frame:NSMakeRect(1020,6,60,16) bold:NO]; [status addSubview:sslText];
    self.sslButton=[self toggle:@"ON" frame:NSMakeRect(1082,2,54,24) action:@selector(toggleSSL:) tag:0]; self.sslButton.accentColor=CAGreenColor(); self.sslButton.state=NSControlStateValueOn; [status addSubview:self.sslButton];
    NSTextField* projectStatus=[self label:@"PROJECT  |  64-bit ENGINE" frame:NSMakeRect(1190,6,300,16) bold:NO]; [status addSubview:projectStatus];

    [self refreshDevices]; [self openSelectedDevice]; [self syncInspector]; [self syncAllTrackControls]; [_timeline refreshProjectExtent];
    _meterTimer=[NSTimer scheduledTimerWithTimeInterval:0.05 target:self selector:@selector(updateMeters:) userInfo:nil repeats:YES];
    [self.window makeKeyAndOrderFront:nil];
}

- (BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication*)sender { (void)sender; return YES; }
- (void)applicationWillTerminate:(NSNotification*)notification { (void)notification; [_meterTimer invalidate]; _engine.stopRecording(); if(_audio) _audio->close(); }

#pragma mark - Device / sync

- (void)refreshDevices {
    _devices=CoreAudioDuplex::devices(); [self.devicePopup removeAllItems]; AudioDeviceID def=CoreAudioDuplex::defaultOutputDevice(); NSInteger sel=0;
    for(NSUInteger i=0;i<_devices.size();++i){ NSString* t=[NSString stringWithFormat:@"%s  [%u in / %u out]",_devices[i].name.c_str(),_devices[i].inputChannels,_devices[i].outputChannels]; [self.devicePopup addItemWithTitle:t]; if(_devices[i].id==def) sel=(NSInteger)i; }
    if(!_devices.empty()) [self.devicePopup selectItemAtIndex:sel];
}

- (void)rebuildIOPopups {
    const NSUInteger ins=_audio?(NSUInteger)_audio->inputChannels():0, outs=_audio?(NSUInteger)_audio->outputChannels():0;
    [_insInputA removeAllItems]; [_insInputB removeAllItems];
    for(NSUInteger i=0;i<ins;++i){ NSString* s=[NSString stringWithFormat:@"Input %lu",(unsigned long)(i+1)]; [_insInputA addItemWithTitle:s]; [_insInputB addItemWithTitle:s]; }
    [self.masterOutA removeAllItems]; [self.masterOutB removeAllItems];
    for(NSUInteger i=0;i<outs;++i){ NSString* s=[NSString stringWithFormat:@"Output %lu",(unsigned long)(i+1)]; [self.masterOutA addItemWithTitle:s]; [self.masterOutB addItemWithTitle:s]; }
    if(outs){ [self.masterOutA selectItemAtIndex:0]; [self.masterOutB selectItemAtIndex:MIN((NSUInteger)1,outs-1)]; _engine.setOutputA(0); _engine.setOutputB((int)MIN((NSUInteger)1,outs-1)); }
    [self syncInspector];
}

- (void)openSelectedDevice {
    NSInteger idx=self.devicePopup.indexOfSelectedItem;
    if(idx<0||(NSUInteger)idx>=_devices.size()){self.statusLabel.stringValue=@"No CoreAudio device";return;}
    std::string err;
    if(_audio->open(_devices[(NSUInteger)idx].id,err)){
        self.statusLabel.stringValue=[NSString stringWithFormat:@"%.0f Hz  |  %u frames  |  %u in / %u out",_audio->sampleRate(),_audio->bufferFrames(),_audio->inputChannels(),_audio->outputChannels()];
        [self rebuildIOPopups]; [_timeline refreshProjectExtent];
    } else self.statusLabel.stringValue=[NSString stringWithUTF8String:err.c_str()];
}

- (void)syncInspector {
    const std::size_t i=(std::size_t)_selectedTrack; const MixerEngine::Track& t=_engine.track(i);
    _insName.stringValue=[NSString stringWithUTF8String:t.name.c_str()];
    [_insType selectItemAtIndex:t.format.load()==(int)TrackFormat::Stereo?1:0];
    [_insSource selectItemAtIndex:t.source.load()==(int)TrackSource::HardwareInput?1:0];
    const NSInteger ia=t.inputA.load(),ib=t.inputB.load();
    if(_insInputA.numberOfItems>0)[_insInputA selectItemAtIndex:MIN(MAX((NSInteger)0,ia),_insInputA.numberOfItems-1)];
    if(_insInputB.numberOfItems>0)[_insInputB selectItemAtIndex:MIN(MAX((NSInteger)0,ib),_insInputB.numberOfItems-1)];
    _insInputB.enabled=(t.format.load()==(int)TrackFormat::Stereo);
    _insArm.state=t.recordArm.load()?NSControlStateValueOn:NSControlStateValueOff;
    _insMon.state=t.inputMonitor.load()?NSControlStateValueOn:NSControlStateValueOff;
    _insMute.state=t.mute.load()?NSControlStateValueOn:NSControlStateValueOff;
    _insSolo.state=t.solo.load()?NSControlStateValueOn:NSControlStateValueOff;
    _insTrim.doubleValue=t.inputTrimDb.load(); _insFader.doubleValue=t.faderDb.load(); _insPan.doubleValue=t.pan.load();
    _insFileLabel.stringValue=t.clip.name.empty()?@"No event":[NSString stringWithUTF8String:t.clip.name.c_str()];
}

- (void)syncTrackControls:(NSUInteger)i {
    const MixerEngine::Track& t=_engine.track((std::size_t)i); NSString* name=[NSString stringWithUTF8String:t.name.c_str()];
    _trackSelect[i].title=name; _trackSelect[i].state=((NSInteger)i==_selectedTrack)?NSControlStateValueOn:NSControlStateValueOff;
    _trackArm[i].state=t.recordArm.load()?NSControlStateValueOn:NSControlStateValueOff; _trackMute[i].state=t.mute.load()?NSControlStateValueOn:NSControlStateValueOff; _trackSolo[i].state=t.solo.load()?NSControlStateValueOn:NSControlStateValueOff;
    _mixNames[i].stringValue=name; _mixFaders[i].doubleValue=t.faderDb.load(); _mixPans[i].doubleValue=t.pan.load();
    _mixMute[i].state=t.mute.load()?NSControlStateValueOn:NSControlStateValueOff; _mixSolo[i].state=t.solo.load()?NSControlStateValueOn:NSControlStateValueOff;
    NSTextField* dbLabel=(NSTextField*)[_mixFaders[i].superview viewWithTag:100+(NSInteger)i]; if(dbLabel)dbLabel.stringValue=[NSString stringWithFormat:@"%.1f dB",t.faderDb.load()];
}
- (void)syncAllTrackControls { for(NSUInteger i=0;i<MixerEngine::kTrackCount;++i)[self syncTrackControls:i]; }

#pragma mark - Transport / project

- (void)selectTrack:(CAFlatButton*)sender { _selectedTrack=sender.tag; [_timeline setSelectedTrackIndex:(NSUInteger)_selectedTrack]; [self syncAllTrackControls]; [self syncInspector]; }
- (void)renameTrack:(NSTextField*)sender { if(_engine.isPlaying()||_engine.isRecording())return; _engine.track((std::size_t)_selectedTrack).name=sender.stringValue.UTF8String; [self syncTrackControls:(NSUInteger)_selectedTrack]; }
- (void)deviceChanged:(id)sender { (void)sender; _engine.stopRecording(); _engine.stop(); _audio->close(); [self openSelectedDevice]; }
- (void)returnToStart:(id)sender { (void)sender; _engine.returnToStart(); [_timeline setNeedsDisplay:YES]; }
- (void)play:(id)sender { (void)sender; _engine.play(); }
- (void)stop:(id)sender { (void)sender; _engine.stopRecording(); _engine.stop(); self.statusLabel.stringValue=[NSString stringWithFormat:@"Stopped  |  dropped record frames: %llu",(unsigned long long)_engine.droppedRecordFrames()]; }

- (void)record:(id)sender {
    (void)sender;
    if(!_audio||!_audio->inputChannels()){self.statusLabel.stringValue=@"Selected device has no CoreAudio inputs.";return;}
    NSOpenPanel* p=[NSOpenPanel openPanel]; p.canChooseFiles=NO; p.canChooseDirectories=YES; p.canCreateDirectories=YES; p.allowsMultipleSelection=NO; p.prompt=@"Record Here";
    if([p runModal]!=NSModalResponseOK)return;
    std::string err;
    if(!_engine.startRecording(p.URL.path.UTF8String,err)){NSAlert*a=[[NSAlert alloc]init];a.messageText=@"Record failed";a.informativeText=[NSString stringWithUTF8String:err.c_str()];[a runModal];return;}
    self.statusLabel.stringValue=@"RECORDING — dry hardware inputs to WAV";
}

- (void)toggleSSL:(id)sender { (void)sender; const bool enabled=!_engine.sslEnabled(); _engine.setSSLEnabled(enabled); self.sslButton.title=enabled?@"ON":@"OFF"; self.sslButton.state=enabled?NSControlStateValueOn:NSControlStateValueOff; }

- (void)saveProject:(id)sender {
    (void)sender; if(_engine.isRecording()){self.statusLabel.stringValue=@"Stop recording before saving the project.";return;}
    NSSavePanel* p=[NSSavePanel savePanel]; p.allowedFileTypes=@[@"caudio"]; p.nameFieldStringValue=@"C-AUDIO Project.caudio"; if([p runModal]!=NSModalResponseOK)return;
    std::string error; const ProjectState state=ProjectFile::capture(_engine);
    if(!ProjectFile::save(p.URL.path.UTF8String,state,error)){NSAlert*a=[[NSAlert alloc]init];a.messageText=@"Save failed";a.informativeText=[NSString stringWithUTF8String:error.c_str()];[a runModal];return;} self.statusLabel.stringValue=@"Project saved.";
}

- (void)openProject:(id)sender {
    (void)sender; _engine.stopRecording(); _engine.stop(); NSOpenPanel* p=[NSOpenPanel openPanel]; p.canChooseDirectories=NO; p.allowsMultipleSelection=NO; p.allowedFileTypes=@[@"caudio"]; if([p runModal]!=NSModalResponseOK)return;
    ProjectState state; std::string error; if(!ProjectFile::load(p.URL.path.UTF8String,state,error)){NSAlert*a=[[NSAlert alloc]init];a.messageText=@"Open failed";a.informativeText=[NSString stringWithUTF8String:error.c_str()];[a runModal];return;}
    for(std::size_t i=0;i<MixerEngine::kTrackCount;++i)_engine.clearClip(i);
    std::string missing;
    for(std::size_t i=0;i<MixerEngine::kTrackCount;++i){ const std::string& path=state.tracks[i].sourcePath;if(path.empty())continue;AudioClip clip;std::string loadError;if(AudioFileLoader::load(path,_engine.sampleRate(),clip,loadError))_engine.setClip(i,std::move(clip));else{if(!missing.empty())missing+="\n";missing+=path;} }
    ProjectFile::applyMetadata(_engine,state); self.sslButton.title=_engine.sslEnabled()?@"ON":@"OFF"; self.sslButton.state=_engine.sslEnabled()?NSControlStateValueOn:NSControlStateValueOff;
    [self.masterType selectItemAtIndex:_engine.outputFormat()==OutputFormat::Mono?1:0]; self.masterOutB.enabled=_engine.outputFormat()!=OutputFormat::Mono; _masterKnob.doubleValue=_engine.masterDb(); _topMasterKnob.doubleValue=_engine.masterDb();
    if(self.masterOutA.numberOfItems>0)[self.masterOutA selectItemAtIndex:MIN(MAX((NSInteger)0,_engine.outputA()),self.masterOutA.numberOfItems-1)];
    if(self.masterOutB.numberOfItems>0)[self.masterOutB selectItemAtIndex:MIN(MAX((NSInteger)0,_engine.outputB()),self.masterOutB.numberOfItems-1)];
    [self syncAllTrackControls];[self syncInspector];[_timeline refreshProjectExtent]; self.statusLabel.stringValue=missing.empty()?@"Project opened.":@"Project opened; source audio missing.";
}

#pragma mark - Channel controls

- (void)inspectorTypeChanged:(NSPopUpButton*)s { auto&t=_engine.track((std::size_t)_selectedTrack);t.format.store(s.indexOfSelectedItem==1?(int)TrackFormat::Stereo:(int)TrackFormat::Mono);_insInputB.enabled=(s.indexOfSelectedItem==1); }
- (void)inspectorSourceChanged:(NSPopUpButton*)s { _engine.track((std::size_t)_selectedTrack).source.store(s.indexOfSelectedItem==1?(int)TrackSource::HardwareInput:(int)TrackSource::File); }
- (void)inspectorInputAChanged:(NSPopUpButton*)s { _engine.track((std::size_t)_selectedTrack).inputA.store((int)s.indexOfSelectedItem); }
- (void)inspectorInputBChanged:(NSPopUpButton*)s { _engine.track((std::size_t)_selectedTrack).inputB.store((int)s.indexOfSelectedItem); }
- (void)inspectorArmChanged:(CAFlatButton*)s { auto&t=_engine.track((std::size_t)_selectedTrack);t.recordArm.store(s.state==NSControlStateValueOn);[self syncTrackControls:(NSUInteger)_selectedTrack]; }
- (void)inspectorMonitorChanged:(CAFlatButton*)s { _engine.track((std::size_t)_selectedTrack).inputMonitor.store(s.state==NSControlStateValueOn); }
- (void)inspectorMuteChanged:(CAFlatButton*)s { auto&t=_engine.track((std::size_t)_selectedTrack);t.mute.store(s.state==NSControlStateValueOn);[self syncTrackControls:(NSUInteger)_selectedTrack]; }
- (void)inspectorSoloChanged:(CAFlatButton*)s { auto&t=_engine.track((std::size_t)_selectedTrack);t.solo.store(s.state==NSControlStateValueOn);[self syncTrackControls:(NSUInteger)_selectedTrack]; }
- (void)inspectorTrimChanged:(CAKnob*)s { _engine.track((std::size_t)_selectedTrack).inputTrimDb.store(s.doubleValue); }
- (void)inspectorFaderChanged:(CAFader*)s { _engine.track((std::size_t)_selectedTrack).faderDb.store(s.doubleValue);[self syncTrackControls:(NSUInteger)_selectedTrack]; }
- (void)inspectorPanChanged:(CAKnob*)s { _engine.track((std::size_t)_selectedTrack).pan.store(s.doubleValue);[self syncTrackControls:(NSUInteger)_selectedTrack]; }
- (void)trackListArmChanged:(CAFlatButton*)s { _engine.track((std::size_t)s.tag).recordArm.store(s.state==NSControlStateValueOn);if(s.tag==_selectedTrack)[self syncInspector]; }
- (void)trackListMuteChanged:(CAFlatButton*)s { _engine.track((std::size_t)s.tag).mute.store(s.state==NSControlStateValueOn);[self syncTrackControls:(NSUInteger)s.tag];if(s.tag==_selectedTrack)[self syncInspector]; }
- (void)trackListSoloChanged:(CAFlatButton*)s { _engine.track((std::size_t)s.tag).solo.store(s.state==NSControlStateValueOn);[self syncTrackControls:(NSUInteger)s.tag];if(s.tag==_selectedTrack)[self syncInspector]; }
- (void)mixMuteChanged:(CAFlatButton*)s { _engine.track((std::size_t)s.tag).mute.store(s.state==NSControlStateValueOn);[self syncTrackControls:(NSUInteger)s.tag];if(s.tag==_selectedTrack)[self syncInspector]; }
- (void)mixSoloChanged:(CAFlatButton*)s { _engine.track((std::size_t)s.tag).solo.store(s.state==NSControlStateValueOn);[self syncTrackControls:(NSUInteger)s.tag];if(s.tag==_selectedTrack)[self syncInspector]; }
- (void)mixFaderChanged:(CAFader*)s { _engine.track((std::size_t)s.tag).faderDb.store(s.doubleValue);[self syncTrackControls:(NSUInteger)s.tag];if(s.tag==_selectedTrack)[self syncInspector]; }
- (void)mixPanChanged:(CAKnob*)s { _engine.track((std::size_t)s.tag).pan.store(s.doubleValue);[self syncTrackControls:(NSUInteger)s.tag];if(s.tag==_selectedTrack)[self syncInspector]; }
- (void)masterChanged:(id)s { const double v=[s doubleValue]; _engine.setMasterDb(v); _masterKnob.doubleValue=v; _topMasterKnob.doubleValue=v; }
- (void)masterTypeChanged:(NSPopUpButton*)s { const bool mono=s.indexOfSelectedItem==1;_engine.setOutputFormat(mono?OutputFormat::Mono:OutputFormat::Stereo);self.masterOutB.enabled=!mono; }
- (void)masterOutChanged:(NSPopUpButton*)s { if(s.tag==0)_engine.setOutputA((int)s.indexOfSelectedItem);else _engine.setOutputB((int)s.indexOfSelectedItem); }

- (void)importAudio:(id)sender {
    (void)sender; if(_engine.isPlaying()||_engine.isRecording()){self.statusLabel.stringValue=@"Stop transport before importing audio.";return;}
    NSOpenPanel*p=[NSOpenPanel openPanel];p.canChooseDirectories=NO;p.allowsMultipleSelection=NO;p.allowedFileTypes=@[@"wav",@"aif",@"aiff",@"caf"];if([p runModal]!=NSModalResponseOK)return;
    AudioClip clip;std::string err;if(!AudioFileLoader::load(p.URL.path.UTF8String,_engine.sampleRate(),clip,err)){NSAlert*a=[[NSAlert alloc]init];a.messageText=@"Import failed";a.informativeText=[NSString stringWithUTF8String:err.c_str()];[a runModal];return;}
    const std::size_t i=(std::size_t)_selectedTrack;const bool stereo=clip.stereo;if(_engine.setClip(i,std::move(clip))){_engine.track(i).format.store(stereo?(int)TrackFormat::Stereo:(int)TrackFormat::Mono);_engine.track(i).source.store((int)TrackSource::File);[self syncInspector];[self syncTrackControls:(NSUInteger)i];[_timeline refreshProjectExtent];self.statusLabel.stringValue=@"Audio event imported at project cursor.";}
}

#pragma mark - Meter / repaint

- (void)updateMeters:(NSTimer*)timer {
    (void)timer; auto meterDb=[](double p){return p>1e-12?20.0*std::log10(p):-120.0;};
    const double l=_engine.peakLeft(),r=_engine.peakRight(); [_masterStereoMeter setLeftLinear:l rightLinear:r]; [_topStereoMeter setLeftLinear:l rightLinear:r];
    self.masterMeter.stringValue=[NSString stringWithFormat:@"L %.1f   R %.1f dBFS",meterDb(l),meterDb(r)];
    for(NSUInteger i=0;i<MixerEngine::kTrackCount;++i)[_mixMeters[i] setLinearLevel:_engine.trackPeak(i)]; [_insMeter setLinearLevel:_engine.trackPeak((std::size_t)_selectedTrack)];
    const double seconds=static_cast<double>(_engine.playhead())/std::max(1.0,_engine.sampleRate());const NSInteger mins=(NSInteger)(seconds/60.0);const double secs=seconds-(double)mins*60.0;self.positionLabel.stringValue=[NSString stringWithFormat:@"%02ld:%06.3f",(long)mins,secs];
    [_timeline setNeedsDisplay:YES]; if(_engine.isRecording()&&_engine.droppedRecordFrames()>0)self.statusLabel.stringValue=[NSString stringWithFormat:@"RECORDING — WARNING: %llu dropped frames",(unsigned long long)_engine.droppedRecordFrames()];
}

@end
