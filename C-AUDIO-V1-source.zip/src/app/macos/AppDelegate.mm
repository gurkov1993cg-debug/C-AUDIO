#import "AppDelegate.h"
#import "CoreAudioDuplex.h"
#import "AudioFileLoader.h"
#import "ProjectTimelineView.h"
#import "CAThemeControls.h"
#import "../../engine/MixerEngine.h"
#import "../../engine/ProjectFile.h"

#import <Cocoa/Cocoa.h>
#import <QuartzCore/QuartzCore.h>

#include <array>
#include <algorithm>
#include <cmath>
#include <memory>
#include <string>
#include <vector>

using namespace caudio;

@interface AppDelegate ()
@property(strong) NSWindow* window;
@property(strong) NSPopUpButton* devicePopup;
@property(strong) NSTextField* statusLabel;
@property(strong) NSTextField* positionLabel;
@property(strong) NSTextField* masterMeter;
@property(strong) CAFlatButton* sslButton;
@property(strong) NSPopUpButton* masterType;
@property(strong) NSPopUpButton* masterOutA;
@property(strong) NSPopUpButton* masterOutB;
@end

@implementation AppDelegate {
    MixerEngine _engine;
    std::unique_ptr<CoreAudioDuplex> _audio;
    std::vector<AudioDeviceInfo> _devices;
    NSInteger _selectedTrack;
    NSTimer* _meterTimer;

    ProjectTimelineView* _timeline;
    NSScrollView* _timelineScroll;

    std::array<CAFlatButton*, MixerEngine::kTrackCount> _trackSelect;
    std::array<CAFlatButton*, MixerEngine::kTrackCount> _trackArm;
    std::array<CAFlatButton*, MixerEngine::kTrackCount> _trackMute;
    std::array<CAFlatButton*, MixerEngine::kTrackCount> _trackSolo;

    NSTextField* _insName;
    NSTextField* _insFileLabel;
    NSPopUpButton* _insType;
    NSPopUpButton* _insSource;
    NSPopUpButton* _insInputA;
    NSPopUpButton* _insInputB;
    CAFlatButton* _insArm;
    CAFlatButton* _insMon;
    CAFlatButton* _insMute;
    CAFlatButton* _insSolo;
    CAKnob* _insTrim;
    CAFader* _insFader;
    CAKnob* _insPan;
    CAMeterView* _insMeter;

    std::array<NSTextField*, MixerEngine::kTrackCount> _mixNames;
    std::array<CAFader*, MixerEngine::kTrackCount> _mixFaders;
    std::array<CAFlatButton*, MixerEngine::kTrackCount> _mixMute;
    std::array<CAFlatButton*, MixerEngine::kTrackCount> _mixSolo;
    std::array<CAMeterView*, MixerEngine::kTrackCount> _mixMeters;
    std::array<CAKnob*, MixerEngine::kTrackCount> _mixPans;
    std::array<CAPanelView*, MixerEngine::kTrackCount> _mixStrips;
    std::array<NSView*, MixerEngine::kTrackCount> _trackRows;

    CAKnob* _masterKnob;
    CAKnob* _topMasterKnob;
    CAStereoMeterView* _masterStereoMeter;
    CAStereoMeterView* _topStereoMeter;
}

#pragma mark - Theme helpers

- (NSTextField*)label:(NSString*)text frame:(NSRect)frame bold:(BOOL)bold {
    NSTextField* l=[[NSTextField alloc] initWithFrame:frame];
    l.stringValue=text; l.editable=NO; l.selectable=NO; l.bordered=NO; l.drawsBackground=NO;
    l.textColor=bold?CATextColor():CAMutedTextColor();
    l.font=bold?[NSFont boldSystemFontOfSize:11.0]:[NSFont systemFontOfSize:10.0];
    l.lineBreakMode=NSLineBreakByTruncatingTail;
    return l;
}

- (NSTextField*)inputField:(NSRect)frame {
    NSTextField* f=[[NSTextField alloc] initWithFrame:frame];
    f.bordered=NO; f.bezeled=NO; f.drawsBackground=YES; f.backgroundColor=CAInsetColor(); f.textColor=CATextColor();
    f.font=[NSFont systemFontOfSize:11.0]; f.focusRingType=NSFocusRingTypeNone; f.wantsLayer=YES;
    f.layer.borderWidth=1.0; f.layer.borderColor=CABorderColor().CGColor; f.layer.cornerRadius=3.0;
    return f;
}

- (CAFlatButton*)button:(NSString*)text frame:(NSRect)frame action:(SEL)action {
    CAFlatButton* b=[[CAFlatButton alloc] initWithFrame:frame];
    b.title=text; b.target=self; b.action=action; b.buttonType=NSMomentaryPushInButton;
    return b;
}

- (CAFlatButton*)toggle:(NSString*)text frame:(NSRect)frame action:(SEL)action tag:(NSInteger)tag {
    CAFlatButton* b=[self button:text frame:frame action:action];
    b.buttonType=NSPushOnPushOffButton; b.tag=tag; return b;
}

- (NSPopUpButton*)popup:(NSRect)frame action:(SEL)action tag:(NSInteger)tag {
    NSPopUpButton* p=[[NSPopUpButton alloc] initWithFrame:frame pullsDown:NO];
    p.target=self; p.action=action; p.tag=tag; p.font=[NSFont systemFontOfSize:10.5];
    p.appearance=[NSAppearance appearanceNamed:NSAppearanceNameVibrantDark];
    p.controlSize=NSControlSizeSmall; p.wantsLayer=YES; p.layer.cornerRadius=3.0;
    return p;
}

- (CAKnob*)knob:(NSRect)frame min:(double)min max:(double)max value:(double)value action:(SEL)action tag:(NSInteger)tag color:(NSColor*)color {
    CAKnob* k=[[CAKnob alloc] initWithFrame:frame]; k.minValue=min; k.maxValue=max; k.doubleValue=value; k.target=self; k.action=action; k.tag=tag; k.accentColor=color; return k;
}

- (CAFader*)fader:(NSRect)frame min:(double)min max:(double)max value:(double)value action:(SEL)action tag:(NSInteger)tag color:(NSColor*)color {
    CAFader* f=[[CAFader alloc] initWithFrame:frame]; f.minValue=min; f.maxValue=max; f.doubleValue=value; f.target=self; f.action=action; f.tag=tag; f.accentColor=color; return f;
}

- (CAPanelView*)panel:(NSRect)frame title:(NSString*)title {
    CAPanelView* p=[[CAPanelView alloc] initWithFrame:frame]; p.title=title; return p;
}

- (void)addSmallCaption:(NSString*)text to:(NSView*)view frame:(NSRect)frame {
    NSTextField* l=[self label:text frame:frame bold:NO]; l.alignment=NSTextAlignmentCenter; [view addSubview:l];
}

#pragma mark - App setup

- (void)applicationDidFinishLaunching:(NSNotification*)notification {
    (void)notification;
    _selectedTrack=0;
    _trackSelect.fill(nil); _trackArm.fill(nil); _trackMute.fill(nil); _trackSolo.fill(nil); _trackRows.fill(nil);
    _mixNames.fill(nil); _mixFaders.fill(nil); _mixMute.fill(nil); _mixSolo.fill(nil); _mixMeters.fill(nil); _mixPans.fill(nil); _mixStrips.fill(nil);
    _audio.reset(new CoreAudioDuplex(_engine));

    // C-AUDIO V1 workspace follows the approved dense German-console workflow:
    // 24 px menu, 58 px transport, 300 px Inspector, 220 px track headers,
    // central Project window, 220 px Right Rack and a 300 px MixConsole.
    const NSRect contentRect=NSMakeRect(0,0,1648,900);
    self.window=[[NSWindow alloc] initWithContentRect:contentRect
                                           styleMask:(NSWindowStyleMaskTitled|NSWindowStyleMaskClosable|NSWindowStyleMaskMiniaturizable|NSWindowStyleMaskResizable)
                                             backing:NSBackingStoreBuffered defer:NO];
    self.window.title=@"C-AUDIO V1 — Project Window";
    self.window.appearance=[NSAppearance appearanceNamed:NSAppearanceNameVibrantDark];
    self.window.backgroundColor=CABackgroundColor();
    self.window.minSize=NSMakeSize(1450,820);
    [self.window center];

    CAWorkspaceView* root=[[CAWorkspaceView alloc] initWithFrame:contentRect];
    root.autoresizingMask=NSViewWidthSizable|NSViewHeightSizable;
    self.window.contentView=root;

    // ----- 24 px menu bar -----
    NSView* menuBar=[[NSView alloc] initWithFrame:NSMakeRect(0,876,1648,24)];
    menuBar.wantsLayer=YES; menuBar.layer.backgroundColor=CAColor(0.101961,0.101961,0.113725,1.0).CGColor;
    [root addSubview:menuBar];
    NSTextField* brand=[self label:@"C-AUDIO" frame:NSMakeRect(12,3,110,18) bold:YES];
    brand.font=[NSFont boldSystemFontOfSize:13.0]; brand.textColor=CATextColor(); [menuBar addSubview:brand];
    NSArray<NSString*>* menus=@[@"File",@"Edit",@"Project",@"Audio",@"MIDI",@"Media",@"Transport",@"Window",@"Help"];
    CGFloat mx=132.0;
    for(NSString* m in menus){ NSTextField* l=[self label:m frame:NSMakeRect(mx,4,68,16) bold:NO]; l.textColor=CATextColor(); l.font=[NSFont systemFontOfSize:11.0]; [menuBar addSubview:l]; mx+=67.0; }
    NSTextField* format=[self label:@"44.1 kHz   24 bit   64-bit" frame:NSMakeRect(1410,4,220,16) bold:NO]; format.alignment=NSTextAlignmentRight; [menuBar addSubview:format];

    // ----- 58 px transport -----
    NSView* transport=[[NSView alloc] initWithFrame:NSMakeRect(0,818,1648,58)];
    transport.wantsLayer=YES; transport.layer.backgroundColor=CAColor(0.137255,0.137255,0.149020,1.0).CGColor;
    transport.layer.borderWidth=1.0; transport.layer.borderColor=CABorderColor().CGColor; [root addSubview:transport];

    CAFlatButton* rew=[self button:@"◀◀" frame:NSMakeRect(12,12,42,34) action:@selector(returnToStart:)]; [transport addSubview:rew];
    CAFlatButton* play=[self button:@"▶" frame:NSMakeRect(58,12,42,34) action:@selector(play:)]; play.accentColor=CAGreenColor(); [transport addSubview:play];
    CAFlatButton* stop=[self button:@"■" frame:NSMakeRect(104,12,42,34) action:@selector(stop:)]; [transport addSubview:stop];
    CAFlatButton* rec=[self button:@"●" frame:NSMakeRect(150,12,42,34) action:@selector(record:)]; rec.dangerStyle=YES; [transport addSubview:rec];
    CAFlatButton* cycle=[self toggle:@"↻" frame:NSMakeRect(196,12,42,34) action:NULL tag:0]; cycle.enabled=NO; [transport addSubview:cycle];
    CAFlatButton* fwd=[self button:@"▶▶" frame:NSMakeRect(242,12,42,34) action:NULL]; fwd.enabled=NO; [transport addSubview:fwd];

    self.positionLabel=[self inputField:NSMakeRect(324,10,180,38)]; self.positionLabel.editable=NO; self.positionLabel.selectable=NO;
    self.positionLabel.stringValue=@"1. 1. 1. 000"; NSFont* timeFont=[NSFont fontWithName:@"Menlo" size:20.0]; if(!timeFont) timeFont=[NSFont systemFontOfSize:20.0]; self.positionLabel.font=timeFont; self.positionLabel.alignment=NSTextAlignmentCenter; [transport addSubview:self.positionLabel];
    NSTextField* tempo=[self inputField:NSMakeRect(516,10,86,38)]; tempo.editable=NO; tempo.stringValue=@"120.00"; tempo.font=[NSFont fontWithName:@"Menlo" size:14.0]; tempo.alignment=NSTextAlignmentCenter; [transport addSubview:tempo];
    NSTextField* tempoCap=[self label:@"TEMPO" frame:NSMakeRect(516,1,86,10) bold:NO]; tempoCap.font=[NSFont systemFontOfSize:8.0]; tempoCap.alignment=NSTextAlignmentCenter; [transport addSubview:tempoCap];
    NSTextField* sig=[self inputField:NSMakeRect(608,10,58,38)]; sig.editable=NO; sig.stringValue=@"4/4"; sig.font=[NSFont fontWithName:@"Menlo" size:14.0]; sig.alignment=NSTextAlignmentCenter; [transport addSubview:sig];

    NSTextField* snap=[self label:@"SNAP" frame:NSMakeRect(704,31,42,12) bold:NO]; [transport addSubview:snap];
    NSPopUpButton* snapPopup=[self popup:NSMakeRect(748,15,78,26) action:NULL tag:0]; [snapPopup addItemsWithTitles:@[@"1/16",@"1/8",@"1/4"]]; snapPopup.enabled=NO; [transport addSubview:snapPopup];
    CAFlatButton* open=[self button:@"OPEN" frame:NSMakeRect(844,14,58,28) action:@selector(openProject:)]; [transport addSubview:open];
    CAFlatButton* save=[self button:@"SAVE" frame:NSMakeRect(906,14,58,28) action:@selector(saveProject:)]; [transport addSubview:save];
    CAFlatButton* metro=[self toggle:@"MET" frame:NSMakeRect(1000,14,50,28) action:NULL tag:0]; metro.enabled=NO; [transport addSubview:metro];

    _topStereoMeter=[[CAStereoMeterView alloc] initWithFrame:NSMakeRect(1304,15,220,28)]; [transport addSubview:_topStereoMeter];
    NSTextField* cpu=[self label:@"CPU  18%" frame:NSMakeRect(1188,21,92,16) bold:NO]; cpu.alignment=NSTextAlignmentRight; [transport addSubview:cpu];
    _topMasterKnob=[self knob:NSMakeRect(1562,7,50,46) min:-60 max:10 value:0 action:@selector(masterChanged:) tag:0 color:CAAccentColor()]; [transport addSubview:_topMasterKnob];
    [self addSmallCaption:@"MAIN" to:transport frame:NSMakeRect(1558,1,58,10)];

    // ----- Inspector, exact 300 px -----
    CAPanelView* inspector=[self panel:NSMakeRect(0,324,300,494) title:@"INSPECTOR"]; [root addSubview:inspector];
    NSArray<NSString*>* tabs=@[@"TRACK",@"INSERTS",@"SENDS",@"EQ",@"STRIP"];
    for(NSUInteger i=0;i<tabs.count;++i){
        NSTextField* t=[self label:tabs[i] frame:NSMakeRect(10+(CGFloat)i*57.0,454,54,18) bold:(i==0)]; t.alignment=NSTextAlignmentCenter; t.textColor=(i==0)?CATextColor():CAMutedTextColor(); [inspector addSubview:t];
        if(i==0){ NSView* line=[[NSView alloc] initWithFrame:NSMakeRect(14,451,46,2)]; line.wantsLayer=YES; line.layer.backgroundColor=CATextColor().CGColor; [inspector addSubview:line]; }
    }
    _insName=[self inputField:NSMakeRect(12,414,276,28)]; _insName.target=self; _insName.action=@selector(renameTrack:); [inspector addSubview:_insName];
    _insMute=[self toggle:@"M" frame:NSMakeRect(12,378,42,26) action:@selector(inspectorMuteChanged:) tag:0]; [inspector addSubview:_insMute];
    _insSolo=[self toggle:@"S" frame:NSMakeRect(58,378,42,26) action:@selector(inspectorSoloChanged:) tag:0]; _insSolo.accentColor=CAYellowColor(); [inspector addSubview:_insSolo];
    _insArm=[self toggle:@"R" frame:NSMakeRect(104,378,42,26) action:@selector(inspectorArmChanged:) tag:0]; _insArm.dangerStyle=YES; [inspector addSubview:_insArm];
    _insMon=[self toggle:@"MON" frame:NSMakeRect(150,378,54,26) action:@selector(inspectorMonitorChanged:) tag:0]; [inspector addSubview:_insMon];

    _insTrim=[self knob:NSMakeRect(16,310,54,54) min:-20 max:20 value:0 action:@selector(inspectorTrimChanged:) tag:0 color:CAAccentColor()]; [inspector addSubview:_insTrim];
    [self addSmallCaption:@"TRIM" to:inspector frame:NSMakeRect(16,296,54,12)];
    _insPan=[self knob:NSMakeRect(86,310,54,54) min:-1 max:1 value:0 action:@selector(inspectorPanChanged:) tag:0 color:CAAccentColor()]; [inspector addSubview:_insPan];
    [self addSmallCaption:@"PAN" to:inspector frame:NSMakeRect(86,296,54,12)];
    _insMeter=[[CAMeterView alloc] initWithFrame:NSMakeRect(160,306,12,60)]; [inspector addSubview:_insMeter];

    NSTextField* routing=[self label:@"ROUTING" frame:NSMakeRect(12,274,100,14) bold:NO]; [inspector addSubview:routing];
    _insType=[self popup:NSMakeRect(12,244,86,26) action:@selector(inspectorTypeChanged:) tag:0]; [_insType addItemsWithTitles:@[@"MONO",@"STEREO"]]; [inspector addSubview:_insType];
    _insSource=[self popup:NSMakeRect(102,244,88,26) action:@selector(inspectorSourceChanged:) tag:0]; [_insSource addItemsWithTitles:@[@"FILE",@"INPUT"]]; [inspector addSubview:_insSource];
    _insInputA=[self popup:NSMakeRect(12,214,86,26) action:@selector(inspectorInputAChanged:) tag:0]; [inspector addSubview:_insInputA];
    _insInputB=[self popup:NSMakeRect(102,214,88,26) action:@selector(inspectorInputBChanged:) tag:0]; [inspector addSubview:_insInputB];
    NSPopUpButton* route=[self popup:NSMakeRect(194,214,94,26) action:NULL tag:0]; [route addItemWithTitle:@"Stereo Out"]; route.enabled=NO; [inspector addSubview:route];

    NSTextField* insertHead=[self label:@"INSERTS" frame:NSMakeRect(12,190,90,14) bold:NO]; [inspector addSubview:insertHead];
    for(NSUInteger i=0;i<3;++i){ CAFlatButton* slot=[self button:(i==0?@"C-AUDIO SSL PATH":@"No Effect") frame:NSMakeRect(12,158-(CGFloat)i*28,180,24) action:NULL]; slot.enabled=NO; [inspector addSubview:slot]; }
    CAFlatButton* imp=[self button:@"IMPORT AUDIO" frame:NSMakeRect(198,158,90,24) action:@selector(importAudio:)]; [inspector addSubview:imp];
    _insFileLabel=[self label:@"No event" frame:NSMakeRect(198,134,90,18) bold:NO]; _insFileLabel.lineBreakMode=NSLineBreakByTruncatingMiddle; [inspector addSubview:_insFileLabel];

    _insFader=[self fader:NSMakeRect(22,12,58,112) min:-60 max:10 value:0 action:@selector(inspectorFaderChanged:) tag:0 color:CAAccentColor()]; [inspector addSubview:_insFader];
    [self addSmallCaption:@"FADER" to:inspector frame:NSMakeRect(18,2,66,12)];
    NSTextField* eqOff=[self label:@"EQ / STRIP OFF — algorithms not implemented yet" frame:NSMakeRect(96,56,192,32) bold:NO]; eqOff.lineBreakMode=NSLineBreakByWordWrapping; [inspector addSubview:eqOff];

    // ----- Center: 220 px track headers + Project -----
    CAPanelView* trackList=[self panel:NSMakeRect(300,324,220,494) title:@"TRACKS"]; [root addSubview:trackList];
    for(NSUInteger i=0;i<MixerEngine::kTrackCount;++i){
        const CGFloat y=404.0-static_cast<CGFloat>(i)*64.0;
        NSView* row=[[NSView alloc] initWithFrame:NSMakeRect(0,y,220,64)]; row.wantsLayer=YES; row.layer.backgroundColor=CAPanelColor().CGColor; row.layer.borderColor=CABorderColor().CGColor; row.layer.borderWidth=1.0; [trackList addSubview:row]; _trackRows[i]=row;
        NSView* stripe=[[NSView alloc] initWithFrame:NSMakeRect(0,0,4,64)]; stripe.wantsLayer=YES; stripe.layer.backgroundColor=CATrackColor(i).CGColor; [row addSubview:stripe];
        NSTextField* num=[self label:[NSString stringWithFormat:@"%lu",(unsigned long)(i+1)] frame:NSMakeRect(10,37,20,16) bold:NO]; [row addSubview:num];
        _trackSelect[i]=[self button:[NSString stringWithFormat:@"Audio %lu",(unsigned long)(i+1)] frame:NSMakeRect(34,32,112,24) action:@selector(selectTrack:)]; _trackSelect[i].tag=(NSInteger)i; _trackSelect[i].accentColor=CATrackColor(i); [row addSubview:_trackSelect[i]];
        _trackMute[i]=[self toggle:@"M" frame:NSMakeRect(34,6,24,22) action:@selector(trackListMuteChanged:) tag:(NSInteger)i]; [row addSubview:_trackMute[i]];
        _trackSolo[i]=[self toggle:@"S" frame:NSMakeRect(62,6,24,22) action:@selector(trackListSoloChanged:) tag:(NSInteger)i]; _trackSolo[i].accentColor=CAYellowColor(); [row addSubview:_trackSolo[i]];
        _trackArm[i]=[self toggle:@"R" frame:NSMakeRect(90,6,24,22) action:@selector(trackListArmChanged:) tag:(NSInteger)i]; _trackArm[i].dangerStyle=YES; [row addSubview:_trackArm[i]];
        CAFlatButton* mon=[self button:@"●" frame:NSMakeRect(118,6,24,22) action:NULL]; mon.enabled=NO; [row addSubview:mon];
    }

    CAPanelView* project=[self panel:NSMakeRect(520,324,908,494) title:@"PROJECT WINDOW"]; [root addSubview:project];
    _timelineScroll=[[NSScrollView alloc] initWithFrame:NSMakeRect(0,0,908,462)]; _timelineScroll.hasHorizontalScroller=YES; _timelineScroll.hasVerticalScroller=YES; _timelineScroll.autohidesScrollers=YES; _timelineScroll.drawsBackground=YES; _timelineScroll.backgroundColor=CABackgroundColor();
    _timeline=[[ProjectTimelineView alloc] initWithFrame:NSMakeRect(0,0,1800,412) engine:&_engine]; _timelineScroll.documentView=_timeline; [project addSubview:_timelineScroll];

    // ----- Right Rack, exact 220 px -----
    CAPanelView* rightRack=[self panel:NSMakeRect(1428,324,220,494) title:@"RIGHT RACK"]; [root addSubview:rightRack];
    NSTextField* mediaHead=[self label:@"AUDIO DEVICE" frame:NSMakeRect(12,444,120,16) bold:NO]; [rightRack addSubview:mediaHead];
    self.devicePopup=[self popup:NSMakeRect(12,412,196,28) action:@selector(deviceChanged:) tag:0]; [rightRack addSubview:self.devicePopup];
    self.statusLabel=[self label:@"Opening CoreAudio..." frame:NSMakeRect(12,370,196,38) bold:NO]; self.statusLabel.lineBreakMode=NSLineBreakByWordWrapping; [rightRack addSubview:self.statusLabel];
    NSTextField* outHead=[self label:@"CONTROL ROOM / OUTPUT" frame:NSMakeRect(12,342,180,16) bold:NO]; [rightRack addSubview:outHead];
    self.masterType=[self popup:NSMakeRect(12,310,94,27) action:@selector(masterTypeChanged:) tag:0]; [self.masterType addItemsWithTitles:@[@"STEREO",@"MONO"]]; [rightRack addSubview:self.masterType];
    self.masterOutA=[self popup:NSMakeRect(12,278,94,27) action:@selector(masterOutChanged:) tag:0]; [rightRack addSubview:self.masterOutA];
    self.masterOutB=[self popup:NSMakeRect(112,278,96,27) action:@selector(masterOutChanged:) tag:1]; [rightRack addSubview:self.masterOutB];
    _masterKnob=[self knob:NSMakeRect(28,176,82,82) min:-60 max:10 value:0 action:@selector(masterChanged:) tag:0 color:CAAccentColor()]; [rightRack addSubview:_masterKnob];
    [self addSmallCaption:@"MAIN" to:rightRack frame:NSMakeRect(38,160,62,14)];
    _masterStereoMeter=[[CAStereoMeterView alloc] initWithFrame:NSMakeRect(150,166,24,96)]; [rightRack addSubview:_masterStereoMeter];
    self.masterMeter=[self label:@"L -∞  R -∞" frame:NSMakeRect(14,140,190,18) bold:YES]; self.masterMeter.alignment=NSTextAlignmentCenter; [rightRack addSubview:self.masterMeter];
    NSTextField* sslText=[self label:@"SSL PATH" frame:NSMakeRect(12,104,72,16) bold:NO]; [rightRack addSubview:sslText];
    self.sslButton=[self toggle:@"ON" frame:NSMakeRect(90,98,54,26) action:@selector(toggleSSL:) tag:0]; self.sslButton.accentColor=CAGreenColor(); self.sslButton.state=NSControlStateValueOn; [rightRack addSubview:self.sslButton];
    NSTextField* frozen=[self label:@"Frozen approved HF-fix model" frame:NSMakeRect(12,72,196,24) bold:NO]; [rightRack addSubview:frozen];
    NSTextField* perf=[self label:@"44.1 / 48 / 96 kHz\n64-bit floating engine" frame:NSMakeRect(12,26,196,38) bold:NO]; perf.lineBreakMode=NSLineBreakByWordWrapping; [rightRack addSubview:perf];

    // ----- Bottom MixConsole, exact 300 px -----
    CAPanelView* mixer=[self panel:NSMakeRect(0,24,1648,300) title:@"MIXCONSOLE"]; [root addSubview:mixer];
    const CGFloat stripW=72.0, gap=4.0, startX=12.0;
    for(NSUInteger i=0;i<MixerEngine::kTrackCount;++i){
        const CGFloat x=startX+static_cast<CGFloat>(i)*(stripW+gap);
        CAPanelView* strip=[self panel:NSMakeRect(x,10,stripW,258) title:nil]; strip.topAccentColor=CATrackColor(i); [mixer addSubview:strip]; _mixStrips[i]=strip;
        _mixNames[i]=[self label:[NSString stringWithFormat:@"Audio %lu",(unsigned long)(i+1)] frame:NSMakeRect(4,226,64,16) bold:YES]; _mixNames[i].alignment=NSTextAlignmentCenter; _mixNames[i].font=[NSFont systemFontOfSize:9.0]; [strip addSubview:_mixNames[i]];
        NSTextField* ins=[self label:@"INSERTS" frame:NSMakeRect(4,210,64,12) bold:NO]; ins.alignment=NSTextAlignmentCenter; ins.font=[NSFont systemFontOfSize:7.5]; [strip addSubview:ins];
        CAFlatButton* slot=[self button:@"No FX" frame:NSMakeRect(5,190,62,18) action:NULL]; slot.enabled=NO; slot.font=[NSFont systemFontOfSize:8.0]; [strip addSubview:slot];
        NSTextField* eq=[self label:@"EQ OFF" frame:NSMakeRect(4,174,64,12) bold:NO]; eq.alignment=NSTextAlignmentCenter; eq.font=[NSFont systemFontOfSize:7.5]; [strip addSubview:eq];
        for(NSUInteger k=0;k<4;++k){ CAKnob* q=[self knob:NSMakeRect(7+(CGFloat)(k%2)*30,143-(CGFloat)(k/2)*28,24,24) min:-12 max:12 value:0 action:NULL tag:0 color:CATrackColor(i)]; q.enabled=NO; [strip addSubview:q]; }
        _mixPans[i]=[self knob:NSMakeRect(24,84,26,26) min:-1 max:1 value:0 action:@selector(mixPanChanged:) tag:(NSInteger)i color:CATrackColor(i)]; [strip addSubview:_mixPans[i]];
        NSTextField* panCap=[self label:@"PAN" frame:NSMakeRect(4,72,64,10) bold:NO]; panCap.alignment=NSTextAlignmentCenter; panCap.font=[NSFont systemFontOfSize:7.5]; [strip addSubview:panCap];
        _mixFaders[i]=[self fader:NSMakeRect(8,22,36,54) min:-60 max:10 value:0 action:@selector(mixFaderChanged:) tag:(NSInteger)i color:CATrackColor(i)]; [strip addSubview:_mixFaders[i]];
        _mixMeters[i]=[[CAMeterView alloc] initWithFrame:NSMakeRect(50,24,5,50)]; [strip addSubview:_mixMeters[i]];
        NSTextField* db=[self label:@"0.0" frame:NSMakeRect(2,8,56,12) bold:NO]; db.alignment=NSTextAlignmentCenter; db.tag=100+(NSInteger)i; db.font=[NSFont systemFontOfSize:8.0]; [strip addSubview:db];
        _mixMute[i]=[self toggle:@"M" frame:NSMakeRect(4,0,20,18) action:@selector(mixMuteChanged:) tag:(NSInteger)i]; _mixMute[i].font=[NSFont systemFontOfSize:8.0]; [strip addSubview:_mixMute[i]];
        _mixSolo[i]=[self toggle:@"S" frame:NSMakeRect(27,0,20,18) action:@selector(mixSoloChanged:) tag:(NSInteger)i]; _mixSolo[i].accentColor=CAYellowColor(); _mixSolo[i].font=[NSFont systemFontOfSize:8.0]; [strip addSubview:_mixSolo[i]];
        CAFlatButton* listen=[self button:@"L" frame:NSMakeRect(50,0,18,18) action:NULL]; listen.enabled=NO; listen.font=[NSFont systemFontOfSize:8.0]; [strip addSubview:listen];
    }
    NSTextField* mixInfo=[self label:@"C-AUDIO MIXCONSOLE  •  64-bit summing  •  current SSL path unchanged" frame:NSMakeRect(510,238,640,16) bold:NO]; [mixer addSubview:mixInfo];

    // ----- 24 px status bar -----
    NSView* status=[[NSView alloc] initWithFrame:NSMakeRect(0,0,1648,24)]; status.wantsLayer=YES; status.layer.backgroundColor=CAColor(0.101961,0.101961,0.113725,1.0).CGColor; [root addSubview:status];
    NSTextField* statusAudio=[self label:@"AUDIO ENGINE   64-bit   |   PROJECT PAN LAW   Equal Power   |   SSL PATH" frame:NSMakeRect(12,4,620,16) bold:NO]; [status addSubview:statusAudio];
    NSTextField* version=[self label:@"C-AUDIO V1" frame:NSMakeRect(1510,4,120,16) bold:YES]; version.alignment=NSTextAlignmentRight; [status addSubview:version];

    [self refreshDevices]; [self openSelectedDevice]; [self syncInspector]; [self syncAllTrackControls]; [_timeline refreshProjectExtent];
    _meterTimer=[NSTimer scheduledTimerWithTimeInterval:0.05 target:self selector:@selector(updateMeters:) userInfo:nil repeats:YES];
    [self.window makeKeyAndOrderFront:nil];
}

- (BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication*)sender { (void)sender; return YES; }
- (void)applicationWillTerminate:(NSNotification*)notification { (void)notification; [_meterTimer invalidate]; _engine.stopRecording(); if(_audio) _audio->close(); }

#pragma mark - Device / sync

- (void)refreshDevices {
    _devices=CoreAudioDuplex::devices(); [self.devicePopup removeAllItems]; AudioDeviceID def=CoreAudioDuplex::defaultOutputDevice(); NSInteger sel=0;
    for(NSUInteger i=0;i<_devices.size();++i){ NSString* t=[NSString stringWithFormat:@"%s  [%u in / %u out]",_devices[i].name.c_str(),_devices[i].inputChannels,_devices[i].outputChannels]; [self.devicePopup addItemWithTitle:t]; if(_devices[i].id==def) sel=(NSInteger)i; }
    if(!_devices.empty()) [self.devicePopup selectItemAtIndex:sel];
}

- (void)rebuildIOPopups {
    const NSUInteger ins=_audio?(NSUInteger)_audio->inputChannels():0, outs=_audio?(NSUInteger)_audio->outputChannels():0;
    [_insInputA removeAllItems]; [_insInputB removeAllItems];
    for(NSUInteger i=0;i<ins;++i){ NSString* s=[NSString stringWithFormat:@"Input %lu",(unsigned long)(i+1)]; [_insInputA addItemWithTitle:s]; [_insInputB addItemWithTitle:s]; }
    [self.masterOutA removeAllItems]; [self.masterOutB removeAllItems];
    for(NSUInteger i=0;i<outs;++i){ NSString* s=[NSString stringWithFormat:@"Output %lu",(unsigned long)(i+1)]; [self.masterOutA addItemWithTitle:s]; [self.masterOutB addItemWithTitle:s]; }
    if(outs){ [self.masterOutA selectItemAtIndex:0]; [self.masterOutB selectItemAtIndex:MIN((NSUInteger)1,outs-1)]; _engine.setOutputA(0); _engine.setOutputB((int)MIN((NSUInteger)1,outs-1)); }
    [self syncInspector];
}

- (void)openSelectedDevice {
    NSInteger idx=self.devicePopup.indexOfSelectedItem;
    if(idx<0||(NSUInteger)idx>=_devices.size()){self.statusLabel.stringValue=@"No CoreAudio device";return;}
    std::string err;
    if(_audio->open(_devices[(NSUInteger)idx].id,err)){
        self.statusLabel.stringValue=[NSString stringWithFormat:@"%.0f Hz  |  %u frames  |  %u in / %u out",_audio->sampleRate(),_audio->bufferFrames(),_audio->inputChannels(),_audio->outputChannels()];
        [self rebuildIOPopups]; [_timeline refreshProjectExtent];
    } else self.statusLabel.stringValue=[NSString stringWithUTF8String:err.c_str()];
}

- (void)syncInspector {
    const std::size_t i=(std::size_t)_selectedTrack; const MixerEngine::Track& t=_engine.track(i);
    _insName.stringValue=[NSString stringWithUTF8String:t.name.c_str()];
    [_insType selectItemAtIndex:t.format.load()==(int)TrackFormat::Stereo?1:0];
    [_insSource selectItemAtIndex:t.source.load()==(int)TrackSource::HardwareInput?1:0];
    const NSInteger ia=t.inputA.load(),ib=t.inputB.load();
    if(_insInputA.numberOfItems>0)[_insInputA selectItemAtIndex:MIN(MAX((NSInteger)0,ia),_insInputA.numberOfItems-1)];
    if(_insInputB.numberOfItems>0)[_insInputB selectItemAtIndex:MIN(MAX((NSInteger)0,ib),_insInputB.numberOfItems-1)];
    _insInputB.enabled=(t.format.load()==(int)TrackFormat::Stereo);
    _insArm.state=t.recordArm.load()?NSControlStateValueOn:NSControlStateValueOff;
    _insMon.state=t.inputMonitor.load()?NSControlStateValueOn:NSControlStateValueOff;
    _insMute.state=t.mute.load()?NSControlStateValueOn:NSControlStateValueOff;
    _insSolo.state=t.solo.load()?NSControlStateValueOn:NSControlStateValueOff;
    _insTrim.doubleValue=t.inputTrimDb.load(); _insFader.doubleValue=t.faderDb.load(); _insPan.doubleValue=t.pan.load();
    _insFileLabel.stringValue=t.clip.name.empty()?@"No event":[NSString stringWithUTF8String:t.clip.name.c_str()];
}

- (void)syncTrackControls:(NSUInteger)i {
    const MixerEngine::Track& t=_engine.track((std::size_t)i); NSString* name=[NSString stringWithUTF8String:t.name.c_str()];
    _trackSelect[i].title=name; _trackSelect[i].state=((NSInteger)i==_selectedTrack)?NSControlStateValueOn:NSControlStateValueOff;
    if(_trackRows[i]) _trackRows[i].layer.backgroundColor=(((NSInteger)i==_selectedTrack)?CAColor(0.196078,0.196078,0.215686,1.0):CAPanelColor()).CGColor;
    _trackArm[i].state=t.recordArm.load()?NSControlStateValueOn:NSControlStateValueOff; _trackMute[i].state=t.mute.load()?NSControlStateValueOn:NSControlStateValueOff; _trackSolo[i].state=t.solo.load()?NSControlStateValueOn:NSControlStateValueOff;
    _mixNames[i].stringValue=name; _mixFaders[i].doubleValue=t.faderDb.load(); _mixPans[i].doubleValue=t.pan.load();
    if(_mixStrips[i]) _mixStrips[i].topAccentColor=(((NSInteger)i==_selectedTrack)?CATextColor():CATrackColor(i));
    _mixMute[i].state=t.mute.load()?NSControlStateValueOn:NSControlStateValueOff; _mixSolo[i].state=t.solo.load()?NSControlStateValueOn:NSControlStateValueOff;
    NSTextField* dbLabel=(NSTextField*)[_mixFaders[i].superview viewWithTag:100+(NSInteger)i]; if(dbLabel)dbLabel.stringValue=[NSString stringWithFormat:@"%.1f dB",t.faderDb.load()];
}
- (void)syncAllTrackControls { for(NSUInteger i=0;i<MixerEngine::kTrackCount;++i)[self syncTrackControls:i]; }

#pragma mark - Transport / project

- (void)selectTrack:(CAFlatButton*)sender { _selectedTrack=sender.tag; [_timeline setSelectedTrackIndex:(NSUInteger)_selectedTrack]; [self syncAllTrackControls]; [self syncInspector]; }
- (void)renameTrack:(NSTextField*)sender { if(_engine.isPlaying()||_engine.isRecording())return; _engine.track((std::size_t)_selectedTrack).name=sender.stringValue.UTF8String; [self syncTrackControls:(NSUInteger)_selectedTrack]; }
- (void)deviceChanged:(id)sender { (void)sender; _engine.stopRecording(); _engine.stop(); _audio->close(); [self openSelectedDevice]; }
- (void)returnToStart:(id)sender { (void)sender; _engine.returnToStart(); [_timeline setNeedsDisplay:YES]; }
- (void)play:(id)sender { (void)sender; _engine.play(); }
- (void)stop:(id)sender { (void)sender; _engine.stopRecording(); _engine.stop(); self.statusLabel.stringValue=[NSString stringWithFormat:@"Stopped  |  dropped record frames: %llu",(unsigned long long)_engine.droppedRecordFrames()]; }

- (void)record:(id)sender {
    (void)sender;
    if(!_audio||!_audio->inputChannels()){self.statusLabel.stringValue=@"Selected device has no CoreAudio inputs.";return;}
    NSOpenPanel* p=[NSOpenPanel openPanel]; p.canChooseFiles=NO; p.canChooseDirectories=YES; p.canCreateDirectories=YES; p.allowsMultipleSelection=NO; p.prompt=@"Record Here";
    if([p runModal]!=NSModalResponseOK)return;
    std::string err;
    if(!_engine.startRecording(p.URL.path.UTF8String,err)){NSAlert*a=[[NSAlert alloc]init];a.messageText=@"Record failed";a.informativeText=[NSString stringWithUTF8String:err.c_str()];[a runModal];return;}
    self.statusLabel.stringValue=@"RECORDING — dry hardware inputs to WAV";
}

- (void)toggleSSL:(id)sender { (void)sender; const bool enabled=!_engine.sslEnabled(); _engine.setSSLEnabled(enabled); self.sslButton.title=enabled?@"ON":@"OFF"; self.sslButton.state=enabled?NSControlStateValueOn:NSControlStateValueOff; }

- (void)saveProject:(id)sender {
    (void)sender; if(_engine.isRecording()){self.statusLabel.stringValue=@"Stop recording before saving the project.";return;}
    NSSavePanel* p=[NSSavePanel savePanel]; p.allowedFileTypes=@[@"caudio"]; p.nameFieldStringValue=@"C-AUDIO Project.caudio"; if([p runModal]!=NSModalResponseOK)return;
    std::string error; const ProjectState state=ProjectFile::capture(_engine);
    if(!ProjectFile::save(p.URL.path.UTF8String,state,error)){NSAlert*a=[[NSAlert alloc]init];a.messageText=@"Save failed";a.informativeText=[NSString stringWithUTF8String:error.c_str()];[a runModal];return;} self.statusLabel.stringValue=@"Project saved.";
}

- (void)openProject:(id)sender {
    (void)sender; _engine.stopRecording(); _engine.stop(); NSOpenPanel* p=[NSOpenPanel openPanel]; p.canChooseDirectories=NO; p.allowsMultipleSelection=NO; p.allowedFileTypes=@[@"caudio"]; if([p runModal]!=NSModalResponseOK)return;
    ProjectState state; std::string error; if(!ProjectFile::load(p.URL.path.UTF8String,state,error)){NSAlert*a=[[NSAlert alloc]init];a.messageText=@"Open failed";a.informativeText=[NSString stringWithUTF8String:error.c_str()];[a runModal];return;}
    for(std::size_t i=0;i<MixerEngine::kTrackCount;++i)_engine.clearClip(i);
    std::string missing;
    for(std::size_t i=0;i<MixerEngine::kTrackCount;++i){ const std::string& path=state.tracks[i].sourcePath;if(path.empty())continue;AudioClip clip;std::string loadError;if(AudioFileLoader::load(path,_engine.sampleRate(),clip,loadError))_engine.setClip(i,std::move(clip));else{if(!missing.empty())missing+="\n";missing+=path;} }
    ProjectFile::applyMetadata(_engine,state); self.sslButton.title=_engine.sslEnabled()?@"ON":@"OFF"; self.sslButton.state=_engine.sslEnabled()?NSControlStateValueOn:NSControlStateValueOff;
    [self.masterType selectItemAtIndex:_engine.outputFormat()==OutputFormat::Mono?1:0]; self.masterOutB.enabled=_engine.outputFormat()!=OutputFormat::Mono; _masterKnob.doubleValue=_engine.masterDb(); _topMasterKnob.doubleValue=_engine.masterDb();
    if(self.masterOutA.numberOfItems>0)[self.masterOutA selectItemAtIndex:MIN(MAX((NSInteger)0,_engine.outputA()),self.masterOutA.numberOfItems-1)];
    if(self.masterOutB.numberOfItems>0)[self.masterOutB selectItemAtIndex:MIN(MAX((NSInteger)0,_engine.outputB()),self.masterOutB.numberOfItems-1)];
    [self syncAllTrackControls];[self syncInspector];[_timeline refreshProjectExtent]; self.statusLabel.stringValue=missing.empty()?@"Project opened.":@"Project opened; source audio missing.";
}

#pragma mark - Channel controls

- (void)inspectorTypeChanged:(NSPopUpButton*)s { auto&t=_engine.track((std::size_t)_selectedTrack);t.format.store(s.indexOfSelectedItem==1?(int)TrackFormat::Stereo:(int)TrackFormat::Mono);_insInputB.enabled=(s.indexOfSelectedItem==1); }
- (void)inspectorSourceChanged:(NSPopUpButton*)s { _engine.track((std::size_t)_selectedTrack).source.store(s.indexOfSelectedItem==1?(int)TrackSource::HardwareInput:(int)TrackSource::File); }
- (void)inspectorInputAChanged:(NSPopUpButton*)s { _engine.track((std::size_t)_selectedTrack).inputA.store((int)s.indexOfSelectedItem); }
- (void)inspectorInputBChanged:(NSPopUpButton*)s { _engine.track((std::size_t)_selectedTrack).inputB.store((int)s.indexOfSelectedItem); }
- (void)inspectorArmChanged:(CAFlatButton*)s { auto&t=_engine.track((std::size_t)_selectedTrack);t.recordArm.store(s.state==NSControlStateValueOn);[self syncTrackControls:(NSUInteger)_selectedTrack]; }
- (void)inspectorMonitorChanged:(CAFlatButton*)s { _engine.track((std::size_t)_selectedTrack).inputMonitor.store(s.state==NSControlStateValueOn); }
- (void)inspectorMuteChanged:(CAFlatButton*)s { auto&t=_engine.track((std::size_t)_selectedTrack);t.mute.store(s.state==NSControlStateValueOn);[self syncTrackControls:(NSUInteger)_selectedTrack]; }
- (void)inspectorSoloChanged:(CAFlatButton*)s { auto&t=_engine.track((std::size_t)_selectedTrack);t.solo.store(s.state==NSControlStateValueOn);[self syncTrackControls:(NSUInteger)_selectedTrack]; }
- (void)inspectorTrimChanged:(CAKnob*)s { _engine.track((std::size_t)_selectedTrack).inputTrimDb.store(s.doubleValue); }
- (void)inspectorFaderChanged:(CAFader*)s { _engine.track((std::size_t)_selectedTrack).faderDb.store(s.doubleValue);[self syncTrackControls:(NSUInteger)_selectedTrack]; }
- (void)inspectorPanChanged:(CAKnob*)s { _engine.track((std::size_t)_selectedTrack).pan.store(s.doubleValue);[self syncTrackControls:(NSUInteger)_selectedTrack]; }
- (void)trackListArmChanged:(CAFlatButton*)s { _engine.track((std::size_t)s.tag).recordArm.store(s.state==NSControlStateValueOn);if(s.tag==_selectedTrack)[self syncInspector]; }
- (void)trackListMuteChanged:(CAFlatButton*)s { _engine.track((std::size_t)s.tag).mute.store(s.state==NSControlStateValueOn);[self syncTrackControls:(NSUInteger)s.tag];if(s.tag==_selectedTrack)[self syncInspector]; }
- (void)trackListSoloChanged:(CAFlatButton*)s { _engine.track((std::size_t)s.tag).solo.store(s.state==NSControlStateValueOn);[self syncTrackControls:(NSUInteger)s.tag];if(s.tag==_selectedTrack)[self syncInspector]; }
- (void)mixMuteChanged:(CAFlatButton*)s { _engine.track((std::size_t)s.tag).mute.store(s.state==NSControlStateValueOn);[self syncTrackControls:(NSUInteger)s.tag];if(s.tag==_selectedTrack)[self syncInspector]; }
- (void)mixSoloChanged:(CAFlatButton*)s { _engine.track((std::size_t)s.tag).solo.store(s.state==NSControlStateValueOn);[self syncTrackControls:(NSUInteger)s.tag];if(s.tag==_selectedTrack)[self syncInspector]; }
- (void)mixFaderChanged:(CAFader*)s { _engine.track((std::size_t)s.tag).faderDb.store(s.doubleValue);[self syncTrackControls:(NSUInteger)s.tag];if(s.tag==_selectedTrack)[self syncInspector]; }
- (void)mixPanChanged:(CAKnob*)s { _engine.track((std::size_t)s.tag).pan.store(s.doubleValue);[self syncTrackControls:(NSUInteger)s.tag];if(s.tag==_selectedTrack)[self syncInspector]; }
- (void)masterChanged:(id)s { const double v=[s doubleValue]; _engine.setMasterDb(v); _masterKnob.doubleValue=v; _topMasterKnob.doubleValue=v; }
- (void)masterTypeChanged:(NSPopUpButton*)s { const bool mono=s.indexOfSelectedItem==1;_engine.setOutputFormat(mono?OutputFormat::Mono:OutputFormat::Stereo);self.masterOutB.enabled=!mono; }
- (void)masterOutChanged:(NSPopUpButton*)s { if(s.tag==0)_engine.setOutputA((int)s.indexOfSelectedItem);else _engine.setOutputB((int)s.indexOfSelectedItem); }

- (void)importAudio:(id)sender {
    (void)sender; if(_engine.isPlaying()||_engine.isRecording()){self.statusLabel.stringValue=@"Stop transport before importing audio.";return;}
    NSOpenPanel*p=[NSOpenPanel openPanel];p.canChooseDirectories=NO;p.allowsMultipleSelection=NO;p.allowedFileTypes=@[@"wav",@"aif",@"aiff",@"caf"];if([p runModal]!=NSModalResponseOK)return;
    AudioClip clip;std::string err;if(!AudioFileLoader::load(p.URL.path.UTF8String,_engine.sampleRate(),clip,err)){NSAlert*a=[[NSAlert alloc]init];a.messageText=@"Import failed";a.informativeText=[NSString stringWithUTF8String:err.c_str()];[a runModal];return;}
    const std::size_t i=(std::size_t)_selectedTrack;const bool stereo=clip.stereo;if(_engine.setClip(i,std::move(clip))){_engine.track(i).format.store(stereo?(int)TrackFormat::Stereo:(int)TrackFormat::Mono);_engine.track(i).source.store((int)TrackSource::File);[self syncInspector];[self syncTrackControls:(NSUInteger)i];[_timeline refreshProjectExtent];self.statusLabel.stringValue=@"Audio event imported at project cursor.";}
}

#pragma mark - Meter / repaint

- (void)updateMeters:(NSTimer*)timer {
    (void)timer; auto meterDb=[](double p){return p>1e-12?20.0*std::log10(p):-120.0;};
    const double l=_engine.peakLeft(),r=_engine.peakRight(); [_masterStereoMeter setLeftLinear:l rightLinear:r]; [_topStereoMeter setLeftLinear:l rightLinear:r];
    self.masterMeter.stringValue=[NSString stringWithFormat:@"L %.1f   R %.1f dBFS",meterDb(l),meterDb(r)];
    for(NSUInteger i=0;i<MixerEngine::kTrackCount;++i)[_mixMeters[i] setLinearLevel:_engine.trackPeak(i)]; [_insMeter setLinearLevel:_engine.trackPeak((std::size_t)_selectedTrack)];
    const double seconds=static_cast<double>(_engine.playhead())/std::max(1.0,_engine.sampleRate());
    const double beats=seconds*2.0; const NSInteger bar=(NSInteger)(beats/4.0)+1; const double inBar=beats-std::floor(beats/4.0)*4.0; const NSInteger beat=(NSInteger)std::floor(inBar)+1; const NSInteger tick=(NSInteger)std::floor((inBar-std::floor(inBar))*1000.0);
    self.positionLabel.stringValue=[NSString stringWithFormat:@"%ld. %ld. 1. %03ld",(long)bar,(long)beat,(long)tick];
    [_timeline setNeedsDisplay:YES]; if(_engine.isRecording()&&_engine.droppedRecordFrames()>0)self.statusLabel.stringValue=[NSString stringWithFormat:@"RECORDING — WARNING: %llu dropped frames",(unsigned long long)_engine.droppedRecordFrames()];
}

@end
