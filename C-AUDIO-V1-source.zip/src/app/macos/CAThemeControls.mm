#import "CAThemeControls.h"
#import <QuartzCore/QuartzCore.h>

#include <algorithm>
#include <cmath>

NSColor* CAColor(CGFloat r, CGFloat g, CGFloat b, CGFloat a) { return [NSColor colorWithCalibratedRed:r green:g blue:b alpha:a]; }
NSColor* CABackgroundColor(void) { return CAColor(0.117647, 0.117647, 0.125490, 1.0); }
NSColor* CAPanelColor(void) { return CAColor(0.145098, 0.145098, 0.160784, 1.0); }
NSColor* CAInsetColor(void) { return CAColor(0.101961, 0.101961, 0.113725, 1.0); }
NSColor* CABorderColor(void) { return CAColor(0.239216, 0.239216, 0.258824, 1.0); }
NSColor* CATextColor(void) { return CAColor(0.898039, 0.898039, 0.905882, 1.0); }
NSColor* CAMutedTextColor(void) { return CAColor(0.541176, 0.541176, 0.556863, 1.0); }
NSColor* CAAccentColor(void) { return CAColor(0.419608, 0.494118, 0.560784, 1.0); }
NSColor* CAGreenColor(void) { return CAColor(0.478431, 0.560784, 0.470588, 1.0); }
NSColor* CAYellowColor(void) { return CAColor(0.831373, 0.631373, 0.364706, 1.0); }
NSColor* CARedColor(void) { return CAColor(1.000000, 0.231373, 0.239216, 1.0); }
NSColor* CATrackColor(NSUInteger index) {
    static NSArray<NSColor*>* colors = nil;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        colors = @[
            CAColor(0.419608,0.494118,0.560784,1.0), // blue-gray #6B7E8F
            CAColor(0.478431,0.560784,0.470588,1.0), // sage #7A8F78
            CAColor(0.545098,0.490196,0.407843,1.0), // taupe #8B7D68
            CAColor(0.541176,0.478431,0.560784,1.0), // mauve #8A7A8F
            CAColor(0.607843,0.545098,0.419608,1.0), // ochre #9B8B6B
            CAColor(0.458824,0.501961,0.529412,1.0), // slate
            CAColor(0.419608,0.494118,0.560784,1.0),
            CAColor(0.478431,0.560784,0.470588,1.0)
        ];
    });
    return colors[index % colors.count];
}

static void CADrawRounded(NSRect rect, CGFloat radius, NSColor* fill, NSColor* stroke) {
    NSBezierPath* path = [NSBezierPath bezierPathWithRoundedRect:rect xRadius:radius yRadius:radius];
    [fill setFill]; [path fill];
    if (stroke) { [stroke setStroke]; path.lineWidth = 1.0; [path stroke]; }
}

@implementation CAWorkspaceView
- (BOOL)isFlipped { return NO; }
- (void)drawRect:(NSRect)dirtyRect {
    [super drawRect:dirtyRect];
    [CABackgroundColor() setFill]; NSRectFill(dirtyRect);
}
@end

@implementation CAPanelView
- (instancetype)initWithFrame:(NSRect)frame {
    self = [super initWithFrame:frame];
    if (self) { self.wantsLayer = YES; }
    return self;
}
- (void)setTitle:(NSString*)title { _title = [title copy]; [self setNeedsDisplay:YES]; }
- (void)setTopAccentColor:(NSColor*)c { _topAccentColor = c; [self setNeedsDisplay:YES]; }
- (void)drawRect:(NSRect)dirtyRect {
    [super drawRect:dirtyRect];
    (void)dirtyRect;
    NSRect b = NSInsetRect(self.bounds, 0.5, 0.5);
    CADrawRounded(b, 2.0, CAPanelColor(), CABorderColor());
    if (_topAccentColor) {
        [_topAccentColor setFill];
        NSRectFill(NSMakeRect(5.0, NSMaxY(b)-4.0, NSWidth(b)-10.0, 2.0));
    }
    if (_title.length) {
        NSDictionary* a=@{NSFontAttributeName:[NSFont boldSystemFontOfSize:10.0], NSForegroundColorAttributeName:CATextColor()};
        [_title drawAtPoint:NSMakePoint(10.0, NSMaxY(b)-22.0) withAttributes:a];
    }
}
@end

@implementation CAFlatButton
- (instancetype)initWithFrame:(NSRect)frame {
    self=[super initWithFrame:frame];
    if(self){
        self.bordered=NO; self.font=[NSFont systemFontOfSize:11.0]; self.accentColor=CAAccentColor();
        self.strongFillWhenOn=YES; self.wantsLayer=YES;
    }
    return self;
}
- (void)setState:(NSControlStateValue)state { [super setState:state]; [self setNeedsDisplay:YES]; }
- (void)setHighlighted:(BOOL)flag { [super setHighlighted:flag]; [self setNeedsDisplay:YES]; }
- (void)drawRect:(NSRect)dirtyRect {
    (void)dirtyRect;
    const BOOL on = self.state == NSControlStateValueOn;
    NSColor* accent = self.dangerStyle ? CARedColor() : (self.accentColor ? self.accentColor : CAAccentColor());
    NSColor* fill = CAInsetColor();
    NSColor* stroke = CABorderColor();
    if (self.highlighted) fill = [accent colorWithAlphaComponent:0.25];
    else if (on && self.strongFillWhenOn) fill = [accent colorWithAlphaComponent:0.30];
    if (on) stroke = [accent colorWithAlphaComponent:0.85];
    CADrawRounded(NSInsetRect(self.bounds,0.5,0.5),2.0,fill,stroke);
    NSColor* tc = !self.enabled ? CAColor(0.32,0.36,0.38,1.0) : (on ? CATextColor() : CAColor(0.78,0.81,0.82,1.0));
    NSDictionary* a=@{NSFontAttributeName:(self.font ? self.font : [NSFont systemFontOfSize:11]), NSForegroundColorAttributeName:tc};
    NSSize sz=[self.title sizeWithAttributes:a];
    [self.title drawAtPoint:NSMakePoint((NSWidth(self.bounds)-sz.width)/2.0,(NSHeight(self.bounds)-sz.height)/2.0+0.5) withAttributes:a];
}
@end

@implementation CAKnob
- (instancetype)initWithFrame:(NSRect)frame {
    self=[super initWithFrame:frame];
    if(self){_minValue=-1.0;_maxValue=1.0;_caDoubleValue=0.0;_accentColor=CAAccentColor();}
    return self;
}
- (void)setDoubleValue:(double)v { _caDoubleValue=std::max(_minValue,std::min(_maxValue,v)); [self setNeedsDisplay:YES]; }
- (double)doubleValue { return _caDoubleValue; }
- (double)normalized { const double d=_maxValue-_minValue; return d>0.0?(_caDoubleValue-_minValue)/d:0.0; }
- (void)drawRect:(NSRect)dirtyRect {
    [super drawRect:dirtyRect]; (void)dirtyRect;
    const CGFloat side=std::min(NSWidth(self.bounds),NSHeight(self.bounds));
    const NSPoint c=NSMakePoint(NSMidX(self.bounds),NSMidY(self.bounds));
    const CGFloat r=side*0.36;
    NSBezierPath* outer=[NSBezierPath bezierPathWithOvalInRect:NSMakeRect(c.x-r,c.y-r,r*2,r*2)];
    [CAInsetColor() setFill]; [outer fill]; [CABorderColor() setStroke]; outer.lineWidth=1.2; [outer stroke];
    const double n=[self normalized];
    const CGFloat deg=(CGFloat)(225.0-270.0*n);
    NSBezierPath* arc=[NSBezierPath bezierPath]; arc.lineWidth=3.0;
    [_accentColor setStroke];
    [arc appendBezierPathWithArcWithCenter:c radius:r+4 startAngle:225 endAngle:deg clockwise:YES]; [arc stroke];
    const CGFloat rad=deg*(CGFloat)3.14159265358979323846/180.0;
    NSBezierPath* mark=[NSBezierPath bezierPath]; mark.lineWidth=2.0; [CATextColor() setStroke];
    [mark moveToPoint:NSMakePoint(c.x,c.y)]; [mark lineToPoint:NSMakePoint(c.x+std::cos(rad)*(r-5),c.y+std::sin(rad)*(r-5))]; [mark stroke];
    NSBezierPath* hub=[NSBezierPath bezierPathWithOvalInRect:NSMakeRect(c.x-2,c.y-2,4,4)]; [CABorderColor() setFill]; [hub fill];
}
- (void)mouseDown:(NSEvent*)event {
    _dragging=YES; _lastY=[self convertPoint:event.locationInWindow fromView:nil].y;
    while(_dragging){
        NSEvent* e=[[self window] nextEventMatchingMask:(NSEventMaskLeftMouseDragged|NSEventMaskLeftMouseUp)];
        if(e.type==NSEventTypeLeftMouseUp){_dragging=NO;break;}
        const CGFloat y=[self convertPoint:e.locationInWindow fromView:nil].y;
        const double delta=(double)(y-_lastY)*(self.maxValue-self.minValue)/120.0; _lastY=y;
        self.doubleValue=self.doubleValue+delta; [self sendAction:self.action to:self.target];
    }
}
@end

@implementation CAFader
- (instancetype)initWithFrame:(NSRect)frame {
    self=[super initWithFrame:frame];
    if(self){_minValue=-60.0;_maxValue=10.0;_caDoubleValue=0.0;_accentColor=CAAccentColor();}
    return self;
}
- (void)setDoubleValue:(double)v { _caDoubleValue=std::max(_minValue,std::min(_maxValue,v)); [self setNeedsDisplay:YES]; }
- (double)doubleValue { return _caDoubleValue; }
- (double)normalized { const double d=_maxValue-_minValue; return d>0.0?(_caDoubleValue-_minValue)/d:0.0; }
- (void)drawRect:(NSRect)dirtyRect {
    [super drawRect:dirtyRect]; (void)dirtyRect;
    const CGFloat cx=NSMidX(self.bounds); const CGFloat lo=10.0, hi=NSHeight(self.bounds)-10.0;
    [CAInsetColor() setStroke]; NSBezierPath* bg=[NSBezierPath bezierPath]; bg.lineWidth=6.0; [bg moveToPoint:NSMakePoint(cx,lo)];[bg lineToPoint:NSMakePoint(cx,hi)];[bg stroke];
    [CABorderColor() setStroke]; NSBezierPath* tr=[NSBezierPath bezierPath]; tr.lineWidth=1.0; [tr moveToPoint:NSMakePoint(cx,lo)];[tr lineToPoint:NSMakePoint(cx,hi)];[tr stroke];
    const CGFloat y=lo+(hi-lo)*(CGFloat)[self normalized];
    [_accentColor setStroke]; NSBezierPath* active=[NSBezierPath bezierPath]; active.lineWidth=2.0; [active moveToPoint:NSMakePoint(cx,lo)]; [active lineToPoint:NSMakePoint(cx,y)]; [active stroke];
    NSRect handle=NSMakeRect(cx-10.0,y-7.0,20.0,14.0); CADrawRounded(handle,2.0,CAColor(0.72,0.74,0.74,1.0),CAColor(0.9,0.9,0.9,0.8));
    [CAColor(0.25,0.27,0.28,1.0) setStroke]; NSBezierPath* h=[NSBezierPath bezierPath]; [h moveToPoint:NSMakePoint(cx-7,y)];[h lineToPoint:NSMakePoint(cx+7,y)];[h stroke];
}
- (void)updateFromEvent:(NSEvent*)event {
    const NSPoint p=[self convertPoint:event.locationInWindow fromView:nil]; const CGFloat lo=10.0, hi=NSHeight(self.bounds)-10.0;
    double n=(p.y-lo)/std::max<CGFloat>(1.0,hi-lo); n=std::max(0.0,std::min(1.0,n));
    self.doubleValue=self.minValue+n*(self.maxValue-self.minValue); [self sendAction:self.action to:self.target];
}
- (void)mouseDown:(NSEvent*)event {
    _dragging=YES; [self updateFromEvent:event];
    while(_dragging){ NSEvent* e=[[self window] nextEventMatchingMask:(NSEventMaskLeftMouseDragged|NSEventMaskLeftMouseUp)]; if(e.type==NSEventTypeLeftMouseUp){_dragging=NO;break;} [self updateFromEvent:e]; }
}
@end

@implementation CAMeterView
- (instancetype)initWithFrame:(NSRect)frame { self=[super initWithFrame:frame]; if(self){_level=0.0;_horizontal=NO;} return self; }
- (void)setLinearLevel:(double)linear { self.level=std::max(0.0,linear); [self setNeedsDisplay:YES]; }
- (void)drawRect:(NSRect)dirtyRect {
    [super drawRect:dirtyRect]; (void)dirtyRect; [CAInsetColor() setFill]; NSRectFill(self.bounds);
    const double db=_level>1e-12?20.0*std::log10(_level):-120.0; const double norm=std::max(0.0,std::min(1.0,(db+60.0)/60.0));
    const NSInteger segs=_horizontal?28:22; const CGFloat gap=1.0;
    for(NSInteger i=0;i<segs;++i){
        const double p=(double)(i+1)/(double)segs; NSColor* c=p>0.93?CARedColor():(p>0.78?CAYellowColor():CAGreenColor());
        if(p>norm)c=[c colorWithAlphaComponent:0.10]; [c setFill];
        if(_horizontal){ const CGFloat w=(NSWidth(self.bounds)-gap*(segs-1))/segs; NSRectFill(NSMakeRect(i*(w+gap),0,w,NSHeight(self.bounds))); }
        else { const CGFloat h=(NSHeight(self.bounds)-gap*(segs-1))/segs; NSRectFill(NSMakeRect(0,i*(h+gap),NSWidth(self.bounds),h)); }
    }
    [CABorderColor() setStroke]; NSFrameRect(self.bounds);
}
@end

@implementation CAStereoMeterView
- (void)setLeftLinear:(double)left rightLinear:(double)right { self.leftLevel=std::max(0.0,left);self.rightLevel=std::max(0.0,right);[self setNeedsDisplay:YES]; }
- (void)drawChannel:(double)level rect:(NSRect)r {
    [CAInsetColor() setFill]; NSRectFill(r); const double db=level>1e-12?20.0*std::log10(level):-120.0; const double n=std::max(0.0,std::min(1.0,(db+60.0)/60.0));
    const NSInteger segs=22; const CGFloat gap=1.0; const CGFloat h=(NSHeight(r)-gap*(segs-1))/segs;
    for(NSInteger i=0;i<segs;++i){ const double p=(double)(i+1)/(double)segs; NSColor*c=p>0.93?CARedColor():(p>0.78?CAYellowColor():CAGreenColor()); if(p>n)c=[c colorWithAlphaComponent:0.10];[c setFill];NSRectFill(NSMakeRect(NSMinX(r),NSMinY(r)+i*(h+gap),NSWidth(r),h)); }
}
- (void)drawRect:(NSRect)dirtyRect { [super drawRect:dirtyRect];(void)dirtyRect;const CGFloat gap=3.0;const CGFloat w=(NSWidth(self.bounds)-gap)/2.0;[self drawChannel:_leftLevel rect:NSMakeRect(0,0,w,NSHeight(self.bounds))];[self drawChannel:_rightLevel rect:NSMakeRect(w+gap,0,w,NSHeight(self.bounds))]; }
@end
