#import <Cocoa/Cocoa.h>

namespace caudio { class MixerEngine; }

@interface ProjectTimelineView : NSView
- (instancetype)initWithFrame:(NSRect)frame engine:(caudio::MixerEngine*)engine;
- (void)setSelectedTrackIndex:(NSUInteger)index;
- (void)refreshProjectExtent;
@end
