#import <Cocoa/Cocoa.h>

NS_ASSUME_NONNULL_BEGIN

NSColor* CAColor(CGFloat r, CGFloat g, CGFloat b, CGFloat a);
NSColor* CABackgroundColor(void);
NSColor* CAPanelColor(void);
NSColor* CAInsetColor(void);
NSColor* CABorderColor(void);
NSColor* CATextColor(void);
NSColor* CAMutedTextColor(void);
NSColor* CAAccentColor(void);
NSColor* CAGreenColor(void);
NSColor* CAYellowColor(void);
NSColor* CARedColor(void);
NSColor* CATrackColor(NSUInteger index);

@interface CAWorkspaceView : NSView
@end

@interface CAPanelView : NSView
@property(nonatomic, copy, nullable) NSString* title;
@property(nonatomic, strong, nullable) NSColor* topAccentColor;
@end

@interface CAFlatButton : NSButton
@property(nonatomic, strong) NSColor* accentColor;
@property(nonatomic) BOOL dangerStyle;
@property(nonatomic) BOOL strongFillWhenOn;
@end

@interface CAKnob : NSControl {
@private
    double _caDoubleValue;
    BOOL _dragging;
    CGFloat _lastY;
}
@property(nonatomic) double minValue;
@property(nonatomic) double maxValue;
@property(nonatomic, strong) NSColor* accentColor;
@end

@interface CAFader : NSControl {
@private
    double _caDoubleValue;
    BOOL _dragging;
}
@property(nonatomic) double minValue;
@property(nonatomic) double maxValue;
@property(nonatomic, strong) NSColor* accentColor;
@end

@interface CAMeterView : NSView
@property(nonatomic) double level;
@property(nonatomic) BOOL horizontal;
- (void)setLinearLevel:(double)linear;
@end

@interface CAStereoMeterView : NSView
@property(nonatomic) double leftLevel;
@property(nonatomic) double rightLevel;
- (void)setLeftLinear:(double)left rightLinear:(double)right;
@end

NS_ASSUME_NONNULL_END
