#import <Cocoa/Cocoa.h>

NS_ASSUME_NONNULL_BEGIN

NSColor* CAColor(CGFloat r, CGFloat g, CGFloat b, CGFloat a);
NSColor* CABackgroundColor(void);
NSColor* CAPanelColor(void);
NSColor* CAInsetColor(void);
NSColor* CABorderColor(void);
NSColor* CATextColor(void);
NSColor* CAMutedTextColor(void);
NSColor* CAAccentColor(void);
NSColor* CAGreenColor(void);
NSColor* CAYellowColor(void);
NSColor* CARedColor(void);
NSColor* CATrackColor(NSUInteger index);

@interface CAWorkspaceView : NSView
@end

@interface CAPanelView : NSView
@property(copy, nullable) NSString* title;
@property(strong, nullable) NSColor* topAccentColor;
@end

@interface CAFlatButton : NSButton
@property(strong) NSColor* accentColor;
@property BOOL dangerStyle;
@property BOOL strongFillWhenOn;
@end

@interface CAKnob : NSControl
@property double doubleValue;
@property double minValue;
@property double maxValue;
@property(strong) NSColor* accentColor;
@end

@interface CAFader : NSControl
@property double doubleValue;
@property double minValue;
@property double maxValue;
@property(strong) NSColor* accentColor;
@end

@interface CAMeterView : NSView
@property double level;
@property BOOL horizontal;
- (void)setLinearLevel:(double)linear;
@end

@interface CAStereoMeterView : NSView
@property double leftLevel;
@property double rightLevel;
- (void)setLeftLinear:(double)left rightLinear:(double)right;
@end

NS_ASSUME_NONNULL_END
