# C-AUDIO V1 — SSL Channel Test (iMac 2011)

Purpose: a listening/recording test of six SSL 4000 E **line-channel** paths plus the first verified 82E26 mix-amp integration and an explicitly bounded 82E195 programme-output macromodel.

## Exactly what is in this build
- 6 tracks, each selectable MONO or STEREO.
- Stereo track = two independent linked SSL channel paths (L/R), not one generic stereo effect.
- FILE or hardware INPUT source.
- Import WAV/AIFF/CAF.
- CoreAudio device selection and visible physical input/output channel counts.
- Per track: input A/B, Record Arm, Input Monitor, Mute, Solo, SSL line trim, VCA fader, Pan/Balance.
- Record armed hardware inputs to 32-bit float WAV via a lock-free ring buffer + disk writer thread.
- Master can route to MONO or STEREO physical outputs.
- 64-bit compensated summing.
- No JUCE or external DSP framework.

## SSL channel scope
The channel model follows the original 82E149 line-channel drawing:
- 2.2 uF / 30.1 k input coupling network.
- line/input-select active stages using the 5534 family and their visible RC poles.
- Channel Fader Select path.
- dbx 202C/gold-can family VCA control in dB, with nonlinear residual bounded to published 202C THD/current data rather than a generic tanh saturator.
- compensated 5534 slew/output limits.
- separate odd/even 82E149 routing-pan buffer paths with their 10 uF/24.9 k and 100 uF/4.7 k coupling networks.
- SSL-style -4.5 dB centre pan law for mono tracks.

EQ and dynamics are **OFF by design**, because this test is specifically the clean console channel/fader/pan path requested before adding those modules.
The master is no longer transparent: the six post-pan channel contributions are converted to virtual-earth bus current through the verified 82E26 15.04 kΩ summing input, processed by the 15 kΩ / 100 pF NE5534 transimpedance stage, then passed through an explicitly-marked 82E195 effective programme-output macromodel using verified visible output-driver values. The full 82E195 card is **not yet claimed node-for-node complete**.

## Important engineering note
This is a circuit-informed test model, not a claim that the private component model used by SSL/UAD has been reverse engineered. The dbx 202C data constrains gain law, noise and total distortion, but a final spectral fingerprint still needs measurement against a known physical 4000 E channel.

## Build
Requires macOS/Xcode with CMake:

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release -DCMAKE_OSX_DEPLOYMENT_TARGET=10.13 -DCMAKE_OSX_ARCHITECTURES=x86_64
cmake --build build --config Release
ctest --test-dir build --output-on-failure
```


## 82E26 / 82E195 status in this revision
- 82E26: current summing, R50 15.04 kΩ per channel, R53 15 kΩ feedback, C28 100 pF, T8 NE5534 macro boundary, R57 47 Ω build-out.
- 82E195: programme-output effective balanced-driver macromodel with visible 39.2 kΩ input network, 30.1 kΩ / 301 kΩ feedback network, 75 Ω build-outs, 100 kΩ cross-sense/coupling and 220 µF output capacitors.
- The 82E195 model is deliberately labeled MACROMODEL until its complete switch/insert/monitor/output network is solved node-by-node.
- No EQ or dynamics have been added.
- Automated tests now measure frequency response, sample-rate invariance, headroom and matched 1/10/50/100-channel summing instead of printing unconditional PASS messages.
