# C-AUDIO V1 — Project Window stage

Native C++/AppKit/CoreAudio DAW prototype for Intel macOS 10.13+.

Current workflow foundation:
- Project Window organisation: global transport, Inspector, Track List, timeline/events, Lower Zone MixConsole.
- Six mono/stereo audio tracks.
- Imported WAV/AIFF/CAF audio is placed as an event at the current project cursor.
- Project locator / seek, STOP preserves position, return-to-start control.
- Per-track input routing, arm, input monitor, mute, solo, line trim, fader and pan/balance.
- CoreAudio hardware output routing and master control.
- `.caudio` project save/open for track settings, event positions, source paths, transport and master state.
- Recording uses a preallocated lock-free ring and a separate disk-writer thread.

Sound engine:
- 64-bit floating-point mixer core.
- Existing SSL channel + 82E26/82E195 path is frozen at the approved HF-fix listening stage.
- Single SSL ON/OFF A/B remains available.
- EQ and dynamics are intentionally not added at this stage.
- No JUCE.

The UI/workflow organisation is inspired by professional DAW project/inspector/mix-console conventions. C-AUDIO DSP, summing, effects and sound algorithms are its own implementation.

## V1 custom C-AUDIO workspace redesign
The macOS AppKit shell now uses a custom-drawn C-AUDIO visual system based on the approved dark mockup: compact top toolbar/transport, inspector, track headers, real waveform timeline, lower MixConsole, custom faders/knobs/meters and output section. No bitmap skin is used; controls are drawn natively so the UI scales cleanly and remains compatible with the High Sierra target.

The approved SSLChannel / SSLMixBus DSP files remain frozen byte-for-byte. MixerEngine changes in this UI stage only add read-only per-track peak metering for the interface.
